'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bell-school-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f5d6';
var svgPathData = ['M64 208c0 114.9 93.1 208 208 208 22.4 0 43.9-3.5 64.1-10.1l-262-262C67.5 164.1 64 185.6 64 208zm64 211.7l0 28.3c0 35.3 28.7 64 64 64l224 0c8.2 0 16.1-.8 23.8-2.4l-66.5-66.5c-31.1 13.4-65.3 20.8-101.3 20.8-53.4 0-103-16.3-144-44.3z', 'M7-24.9c9.4-9.4 24.6-9.4 33.9 0L125.8 60c37.6-37.1 89.2-60 146.2-60 114.9 0 208 93.1 208 208 0 57-22.9 108.6-60 146.2l63.4 63.4c2.8-7.5 4.5-15.5 4.6-23.9-14.3-8.3-24-23.8-24-41.6 0-26.5 21.5-48 48-48s48 21.5 48 48c0 17.8-9.7 33.3-24 41.6-.3 21.8-6.4 42.2-16.8 59.7L569 503.1c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0L7 9.1C-2.3-.3-2.3-15.5 7-24.9zM250.3 184.5c5.7-5.3 13.3-8.5 21.7-8.5 17.7 0 32 14.3 32 32 0 8.4-3.2 16-8.5 21.7l34 34c13.9-14.4 22.5-34 22.5-55.6 0-44.2-35.8-80-80-80-21.6 0-41.2 8.6-55.6 22.5l34 34z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellSchoolSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;