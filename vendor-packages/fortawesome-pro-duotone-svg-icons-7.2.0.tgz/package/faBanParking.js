'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'ban-parking';
var width = 512;
var height = 512;
var aliases = ["parking-circle-slash"];
var unicode = 'f616';
var svgPathData = ['M168 213.3l106.7 106.7-42.7 0 0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-138.7zm14.5-76c6.9-5.8 15.8-9.2 25.5-9.2l72 0c53 0 96 43 96 96 0 29.2-13.1 55.4-33.7 73l-45.7-45.7c9.2-5.6 15.4-15.8 15.4-27.4 0-17.7-14.3-32-32-32l-42.7 0-54.8-54.8z', 'M367.2 412.5L99.5 144.8c-22.4 31.4-35.5 69.8-35.5 111.2 0 106 86 192 192 192 41.5 0 79.9-13.1 111.2-35.5zm45.3-45.3c22.4-31.4 35.5-69.8 35.5-111.2 0-106-86-192-192-192-41.5 0-79.9 13.1-111.2 35.5L412.5 367.2zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanParking = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;