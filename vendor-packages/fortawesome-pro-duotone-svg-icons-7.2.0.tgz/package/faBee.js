'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bee';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e0b2';
var svgPathData = ['M16 320c0-95.1 69.2-174.1 160-189.3 10.4-1.7 21.1-2.7 32-2.7 32 0 64 0 96 0 10.9 0 21.6 .9 32 2.7 90.8 15.2 160 94.2 160 189.3l0 16c0 17.7-14.3 32-32 32l-16 0c-19.2 0-37.8-2.8-55.3-8.1-7.4-2.2-14.6-4.9-21.5-7.9-25.6-11.1-48.1-27.6-66.4-48-27-30.2-44.7-69.1-48.2-112-.2-2-.3-4.1-.4-6.1L256 176c0 5.4-.2 10.7-.7 16-3.6 42.9-21.2 81.8-48.3 112-18.2 20.4-40.8 36.9-66.2 48-7.1 3-14.2 5.7-21.6 7.9-17.5 5.3-36 8.1-55.2 8.1l-16 0c-17.7 0-32-14.3-32-32l0-16z', 'M334 448c-25.8 28-52 49.8-63.7 59.1-4.1 3.2-9.1 4.9-14.3 4.9s-10.2-1.6-14.3-4.9C230 497.8 203.8 476 178 448l156 0zm37.3-96c7 3 14.1 5.7 21.5 7.9-5 13.5-12.1 27-20.7 40.1l-232.2 0c-8.5-13.1-15.7-26.6-20.7-40.1 7.4-2.2 14.5-4.8 21.5-7.9l230.5 0zM256.7 192c3.5 42.9 21.2 81.8 48.2 112l-97.9 0c27.1-30.2 44.6-69.1 48.2-112l1.4 0zM311 7c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9L326.9 59c5.8 11.1 9.1 23.6 9.1 37l0 34.7c-10.4-1.7-21.1-2.7-32-2.7l-96 0c-10.9 0-21.6 .9-32 2.7L176 96c0-13.3 3.3-25.9 9.1-37L167 41 165.4 39.2c-7.7-9.4-7.1-23.3 1.7-32.1s22.7-9.3 32.1-1.7L201 7 219 25.1c11.1-5.8 23.6-9.1 37-9.1 13.3 0 25.9 3.3 36.9 9.1L311 7z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBee = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;