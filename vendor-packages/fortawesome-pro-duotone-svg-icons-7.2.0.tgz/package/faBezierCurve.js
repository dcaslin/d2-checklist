'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bezier-curve';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f55b';
var svgPathData = ['M0 112c0-35.3 28.7-64 64-64 25.3 0 47.2 14.7 57.6 36l118.4 0 0 60c0 10 3 19.2 8.2 26.9-59 25.7-101.6 82.1-107.5 149.1l-56.2 0c5-75 45.1-140.4 104-180l-66.9 0c-10.4 21.3-32.3 36-57.6 36-35.3 0-64-28.7-64-64zm391.8 58.9c2.6-3.8 4.7-8.1 6.1-12.6 .7-2.3 1.2-4.6 1.6-7 .2-1.2 .3-2.4 .4-3.6s.1-2.5 .1-3.7l0-60 118.4 0c10.4-21.3 32.3-36 57.6-36 35.3 0 64 28.7 64 64s-28.7 64-64 64c-25.3 0-47.2-14.7-57.6-36l-66.9 0c58.9 39.6 98.9 105 104 180l-56.2 0c-5.9-67-48.5-123.4-107.5-149.1z', 'M296 136l48 0 0-48-48 0 0 48zM240 80c0-26.5 21.5-48 48-48l64 0c26.5 0 48 21.5 48 48l0 64c0 26.5-21.5 48-48 48l-64 0c-26.5 0-48-21.5-48-48l0-64zM88 376l0 48 48 0 0-48-48 0zm-8-56l64 0c26.5 0 48 21.5 48 48l0 64c0 26.5-21.5 48-48 48l-64 0c-26.5 0-48-21.5-48-48l0-64c0-26.5 21.5-48 48-48zm424 56l0 48 48 0 0-48-48 0zm-8-56l64 0c26.5 0 48 21.5 48 48l0 64c0 26.5-21.5 48-48 48l-64 0c-26.5 0-48-21.5-48-48l0-64c0-26.5 21.5-48 48-48z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBezierCurve = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;