'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'austral-sign';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e0a9';
var svgPathData = ['M8 264c0-13.3 10.7-24 24-24l80.6 0-19.2 48-61.4 0c-13.3 0-24-10.7-24-24zm0 96c0-13.3 10.7-24 24-24l42.3 0-19.2 48-23.1 0c-13.3 0-24-10.7-24-24zm116 24l19.2-48 161.6 0 19.2 48-200 0zm38.3-96l19.2-48 85 0 19.2 48-123.3 0zm173.1-48l80.6 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-61.4 0-19.2-48zm38.3 96l42.3 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-23.1 0-19.2-48z', 'M224 133.6L354.3 459.9c6.6 16.4 25.2 24.4 41.6 17.9s24.4-25.2 17.8-41.6L262.9 58.3C256.5 42.4 241.1 32 224 32s-32.5 10.4-38.9 26.3L34.3 436.1c-6.6 16.4 1.4 35 17.9 41.6s35-1.4 41.6-17.9L224 133.6z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAustralSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;