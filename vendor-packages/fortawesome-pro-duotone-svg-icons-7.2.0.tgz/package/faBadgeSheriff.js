'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'badge-sheriff';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f8a2';
var svgPathData = ['M65.4 180.9c10-3.8 18.9-10.9 24.6-20.9 5.8-10.1 7.6-21.4 5.8-32l69.8 0c11.6 0 22.2-6.2 27.9-16.3l32.8-58.3C234.5 60 245 64 256.4 64s21.8-4 30.1-10.6l32.8 58.3c5.7 10.1 16.3 16.3 27.9 16.3l69.8 0c-1.8 10.6-.1 21.9 5.8 32 5.8 10 14.6 17.1 24.6 20.9L411 239c-6.5 10.4-6.5 23.5 0 33.9l36.3 58.1c-10 3.8-18.9 10.9-24.6 20.9-5.8 10.1-7.6 21.4-5.8 32l-69.8 0c-11.6 0-22.2 6.2-27.9 16.3l-32.8 58.3c-8.2-6.6-18.7-10.6-30.1-10.6s-21.8 4-30.1 10.6l-32.8-58.3c-5.7-10.1-16.3-16.3-27.9-16.3l-69.8 0c1.8-10.6 .1-21.9-5.8-32-5.8-10-14.6-17.1-24.6-20.9L101.8 273c6.5-10.4 6.5-23.5 0-33.9L65.4 180.9zM192.4 256a63.6 63.6 0 1 0 127.3 0 63.6 63.6 0 1 0 -127.3 0z', 'M304.4 16a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm0 480a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm201.4-96a48 48 0 1 0 -83.1-48 48 48 0 1 0 83.1 48zM72.5 94.4a48 48 0 1 0 -48 83.1 48 48 0 1 0 48-83.1zM505.8 112a48 48 0 1 0 -83.1 48 48 48 0 1 0 83.1-48zM24.5 334.4a48 48 0 1 0 48 83.1 48 48 0 1 0 -48-83.1zM256.4 320a64 64 0 1 0 -.7-128 64 64 0 1 0 .7 128z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBadgeSheriff = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;