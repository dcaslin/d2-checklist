'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'ballot-check';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'f733';
var svgPathData = ['M0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-384c0-35.3-28.7-64-64-64L64 0C28.7 0 0 28.7 0 64zM56.6 251.5C50.3 243 52 231 60.5 224.6S81 220 87.4 228.5L96 240 128.6 196.5c6.4-8.5 18.4-10.2 26.9-3.8s10.2 18.4 3.8 26.9l-48 64c-3.6 4.8-9.3 7.7-15.4 7.7s-11.7-2.8-15.4-7.7l-24-32zM128 128a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm0 256a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm48-256c0-13.3 10.7-24 24-24l96 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-96 0c-13.3 0-24-10.7-24-24zm0 256c0-13.3 10.7-24 24-24l96 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-96 0c-13.3 0-24-10.7-24-24zm32-128c0-13.3 10.7-24 24-24l64 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-64 0c-13.3 0-24-10.7-24-24z', 'M96 96a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm0 256a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm80 32c0 13.3 10.7 24 24 24l96 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-96 0c-13.3 0-24 10.7-24 24zm24-280c-13.3 0-24 10.7-24 24s10.7 24 24 24l96 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-96 0zm8 152c0 13.3 10.7 24 24 24l64 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-64 0c-13.3 0-24 10.7-24 24zm-48.6-36.5c6.4-8.5 4.6-20.5-3.8-26.9s-20.5-4.6-26.9 3.8L96 240 87.4 228.5C81 220 69 218.3 60.5 224.6S50.3 243 56.6 251.5l24 32c3.6 4.8 9.3 7.7 15.4 7.7s11.7-2.8 15.4-7.7l48-64z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBallotCheck = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;