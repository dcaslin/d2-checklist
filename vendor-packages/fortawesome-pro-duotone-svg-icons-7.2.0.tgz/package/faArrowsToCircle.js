'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrows-to-circle';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e4bd';
var svgPathData = ['M200 256a56 56 0 1 0 112 0 56 56 0 1 0 -112 0z', 'M54.6 9.4C42.1-3.1 21.9-3.1 9.4 9.4s-12.5 32.8 0 45.3L82.7 128 64 128c-17.7 0-32 14.3-32 32s14.3 32 32 32l96 0c17.7 0 32-14.3 32-32l0-96c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 18.7-73.4-73.4zm448 45.3c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L384 82.7 384 64c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 96c0 17.7 14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-18.7 0 73.4-73.4zm-45.3 448c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L429.3 384 448 384c17.7 0 32-14.3 32-32s-14.3-32-32-32l-96 0c-17.7 0-32 14.3-32 32l0 96c0 17.7 14.3 32 32 32s32-14.3 32-32l0-18.7 73.4 73.4zM9.4 457.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l73.4-73.4 0 18.7c0 17.7 14.3 32 32 32s32-14.3 32-32l0-96c0-17.7-14.3-32-32-32l-96 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l18.7 0-73.4 73.4z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsToCircle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;