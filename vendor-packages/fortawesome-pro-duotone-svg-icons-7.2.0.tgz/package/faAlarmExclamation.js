'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'alarm-exclamation';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f843';
var svgPathData = ['M32 288c0 50.3 16.6 96.8 44.6 134.2L41.4 457.4c-12.5 12.5-12.5 32.8 0 45.2s32.8 12.5 45.2 0l35.2-35.2c37.4 28 83.8 44.6 134.2 44.6s96.8-16.6 134.2-44.6l35.2 35.2c12.5 12.5 32.8 12.5 45.2 0s12.5-32.8 0-45.2l-35.2-35.2c28-37.4 44.6-83.8 44.6-134.2 0-123.7-100.3-224-224-224S32 164.3 32 288zm256 96a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM224.6 193.7c-1.3-18.2 13.1-33.7 31.4-33.7 18.2 0 32.7 15.5 31.4 33.7l-7.4 104c-.9 12.6-11.4 22.3-23.9 22.3-12.6 0-23-9.7-23.9-22.3l-7.4-104z', 'M256 416a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm0-256c18.2 0 32.7 15.5 31.4 33.7l-7.4 104c-.9 12.6-11.4 22.3-23.9 22.3-12.6 0-23-9.7-23.9-22.3l-7.4-104C223.3 175.5 237.8 160 256 160zM95.2 0c19.3 0 37.3 5.8 52.3 15.7 9.5 6.3 6.3 19.9-4.1 24.6-44.8 20.4-83.1 52.6-110.9 92.6-6.5 9.4-20.5 10.1-25-.4-4.9-11.4-7.6-24.1-7.6-37.3 0-52.6 42.6-95.2 95.2-95.2zM416.7 0c52.6 0 95.3 42.6 95.3 95.2 0 13.2-2.7 25.8-7.6 37.3-4.5 10.5-18.4 9.8-25 .4-27.8-40-66.1-72.2-110.9-92.6-10.4-4.7-13.7-18.3-4.1-24.6 15-9.9 33-15.7 52.3-15.7z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlarmExclamation = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;