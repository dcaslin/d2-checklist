'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bacon';
var width = 576;
var height = 512;
var aliases = [129363];
var unicode = 'f7e5';
var svgPathData = ['M56.5 452.1l91.4-70.3c36.6-28.1 66.3-64.2 86.9-105.4 8.2-16.4 16.4-32.7 24.5-49.1 28.4-56.8 71.5-104.8 124.9-139.1 33.3-21.4 66.6-42.8 99.9-64.2 11.6 11.6 23.2 23.2 34.7 34.7-36.2 23.3-72.5 46.6-108.7 69.9-46.1 29.7-83.4 71.2-107.9 120.2-8.2 16.4-16.4 32.7-24.5 49.1-23.9 47.7-58.3 89.4-100.6 122-28.8 22.2-57.6 44.3-86.5 66.5L56.5 452.1z', 'M557 96.7c14.4 14.4 12.4 38.4-4.3 50.2l-64.6 45.7c-43.7 30.9-79.2 71.9-103.4 119.6l-25.3 49.8c-25.1 49.3-62.1 91.5-107.8 122.6l-74.1 50.6c-13.1 8.9-30.7 7.3-41.8-3.9l-44.9-44.9 86.5-66.5c42.3-32.5 76.7-74.3 100.6-122l24.5-49.1c24.5-49 61.8-90.6 107.9-120.2l108.7-69.9 38 38zM484.2 23.9L384.3 88.2c-53.4 34.3-96.5 82.4-124.9 139.1l-24.5 49.1c-20.6 41.3-50.3 77.3-86.9 105.4l-91.4 70.3-36.9-36.9c-14.4-14.4-12.4-38.4 4.3-50.2l64.6-45.7c43.7-30.9 79.2-71.9 103.4-119.6l25.3-49.8C242.3 100.8 279.3 58.6 325 27.4l74.1-50.6c13.1-8.9 30.6-7.3 41.8 3.9l43.3 43.3z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBacon = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;