'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-pointer';
var width = 448;
var height = 512;
var aliases = ["mouse-pointer"];
var unicode = 'f245';
var svgPathData = ['M198.6 316.6l21.5-28.7 35.7 0 88.9 177.7c7.9 15.8 1.5 35-14.3 42.9s-35 1.5-42.9-14.3L198.6 316.6z', 'M102.4 4.8c-7.3-5.5-17-6.3-25.1-2.3S64 14.9 64 24l0 400c0 10.3 6.6 19.5 16.4 22.8s20.6-.1 26.8-8.4l112.8-150.5 188 0c10.3 0 19.5-6.6 22.8-16.4s-.1-20.6-8.4-26.8L102.4 4.8z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowPointer = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;