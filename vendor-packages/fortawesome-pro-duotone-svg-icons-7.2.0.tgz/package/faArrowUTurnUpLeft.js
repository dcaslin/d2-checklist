'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-u-turn-up-left';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e7ed';
var svgPathData = ['M64 448c0 16.6 12.6 30.2 28.7 31.8l3.3 .2 224 0c106 0 192-86 192-192l-.2-9.9C506.6 176.7 422.7 96 320 96l-210.7 0-32 32 32 32 210.8 0c68.5 0 124.4 53.8 127.8 121.4l.2 6.6c0 70.7-57.3 128-128 128l-224 0-3.3 .2C76.6 417.8 64 431.4 64 448z', 'M7.2 148.2c-10.3-12.6-9.5-31.1 2.2-42.8l112-112c12.5-12.5 32.8-12.5 45.2 0s12.5 32.8 0 45.2l-89.4 89.4 89.4 89.4 2.2 2.4c10.2 12.6 9.5 31.1-2.2 42.8s-30.2 12.4-42.8 2.2l-2.4-2.2-112-112-2.2-2.4z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUTurnUpLeft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;