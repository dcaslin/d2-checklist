'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrows-up-down-left-right';
var width = 512;
var height = 512;
var aliases = ["arrows"];
var unicode = 'f047';
var svgPathData = ['M169.4 73.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l9.4-9.4 0 114.7 64 0 0-114.7 9.4 9.4c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-64-64c-12.5-12.5-32.8-12.5-45.3 0l-64 64zm0 320c-12.5 12.5-12.5 32.8 0 45.3l64 64c12.5 12.5 32.8 12.5 45.3 0l64-64c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-9.4 9.4 0-114.7-64 0 0 114.7-9.4-9.4c-12.5-12.5-32.8-12.5-45.3 0z', 'M118.6 169.4c12.5 12.5 12.5 32.8 0 45.3l-9.4 9.4 293.5 0-9.4-9.4c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l64 64c12.5 12.5 12.5 32.8 0 45.3l-64 64c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l9.4-9.4-293.5 0 9.4 9.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0l-64-64c-12.5-12.5-12.5-32.8 0-45.3l64-64c12.5-12.5 32.8-12.5 45.3 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsUpDownLeftRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;