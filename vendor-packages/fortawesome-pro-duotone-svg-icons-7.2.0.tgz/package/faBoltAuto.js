'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bolt-auto';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0b6';
var svgPathData = ['M33.8 266.7C38.4 279.5 50.5 288 64 288l110 0-75 162.6c-6.2 13.5-2.3 29.5 9.4 38.7s28.3 9 39.8-.4l256-208c10.5-8.5 14.5-22.8 10-35.5S397.5 224 384 224l-110 0 75-162.6c6.2-13.5 2.3-29.5-9.4-38.7s-28.3-9-39.8 .4l-256 208c-10.5 8.5-14.5 22.8-10 35.5z', 'M485.5 301.3c-4.1-8.1-12.4-13.3-21.5-13.3s-17.4 5.1-21.5 13.3l-88 176c-5.9 11.9-1.1 26.3 10.7 32.2s26.3 1.1 32.2-10.7l13.4-26.7 106.3 0 13.4 26.7c5.9 11.9 20.3 16.7 32.2 10.7s16.7-20.3 10.7-32.2l-88-176zM493.2 424l-58.3 0 29.2-58.3 29.2 58.3z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoltAuto = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;