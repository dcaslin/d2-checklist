'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'binary-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e33e';
var svgPathData = ['M96 480c0 17.7 14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-16 0 0-128c0-10.3-4.9-19.9-13.3-26s-19.1-7.7-28.8-4.4l-48 16c-16.8 5.6-25.8 23.7-20.2 40.5s23.7 25.8 40.5 20.2l5.9-2 0 83.6-16 0c-17.7 0-32 14.3-32 32zM288 357.8l0 90.2c0 35.3 28.7 64 64 64l64 0c7.8 0 15.3-1.4 22.2-4L288 357.8z', 'M7-24.9c9.4-9.4 24.6-9.4 33.9 0l61.3 61.3C112.6 14.9 134.5 0 160 0l64 0c35.3 0 64 28.7 64 64l0 96c0 17.2-6.8 32.8-17.8 44.3l83.7 83.7 62.2 0c35.3 0 64 28.7 64 64l0 62.2 89 89c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0L7 9.1C-2.3-.3-2.3-15.5 7-24.9zm217 183l0-94.2-64 0 0 30.2 64 64zM418.7 6c8.3 6 13.3 15.7 13.3 26l0 128 16 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-96 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l16 0 0-83.6-5.9 2c-16.8 5.6-34.9-3.5-40.5-20.2s3.5-34.9 20.2-40.5l48-16C399.6-1.6 410.4 0 418.7 6z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinarySlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;