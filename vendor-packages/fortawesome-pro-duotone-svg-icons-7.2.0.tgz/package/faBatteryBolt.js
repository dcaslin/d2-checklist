'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'battery-bolt';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f376';
var svgPathData = ['M32 144l0 224c0 44.2 35.8 80 80 80l76.1 0c-5.5-15.7-5.7-33.2 .6-49.6l5.5-14.4-82.2 0c-8.8 0-16-7.2-16-16l0-224c0-8.8 7.2-16 16-16l121.4 0 70.1-64-191.5 0c-44.2 0-80 35.8-80 80zM336.5 448L528 448c44.2 0 80-35.8 80-80l0-48c17.7 0 32-14.3 32-32l0-64c0-17.7-14.3-32-32-32l0-48c0-44.2-35.8-80-80-80l-76.1 0c5.5 15.7 5.7 33.2-.6 49.6l-5.5 14.4 82.2 0c8.8 0 16 7.2 16 16l0 224c0 8.8-7.2 16-16 16l-121.4 0-70.1 64z', 'M406.4 96.5c4-10.4 .3-22.1-8.9-28.4s-21.5-5.4-29.7 2.1l-184 168c-7.3 6.7-9.8 17.2-6.2 26.4S190.1 280 200 280l85.2 0-51.6 135.5c-4 10.4-.3 22.1 8.9 28.4s21.5 5.4 29.7-2.1l184-168c7.3-6.7 9.8-17.2 6.2-26.4S449.9 232 440 232l-85.2 0 51.6-135.5z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBatteryBolt = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;