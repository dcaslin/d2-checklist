'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'angle';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e08c';
var svgPathData = ['M192.2 199.1l21.6-43.2c30.6 19.1 58 42.9 81.2 70.3 9 10.7 5.8 26.7-6.1 34.1-10.7 6.6-24.6 3.9-32.8-5.6-18.5-21.4-40-40.2-63.9-55.6zM304.8 332.9c-4.9-11.6-1.2-25.3 9.5-31.9 11.9-7.4 27.6-3.2 33.2 9.7 14.3 32.8 23.6 68.2 27 105.3l-48.2 0c-3.1-29.2-10.5-57.1-21.5-83.1z', 'M238.3 35.4c15.8 7.9 22.2 27.1 14.3 42.9L83.8 416 416 416c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 480c-11.1 0-21.4-5.7-27.2-15.2s-6.4-21.2-1.4-31.1l192-384c7.9-15.8 27.1-22.2 42.9-14.3z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAngle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;