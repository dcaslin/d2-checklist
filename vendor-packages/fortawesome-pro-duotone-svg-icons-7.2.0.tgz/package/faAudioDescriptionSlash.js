'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'audio-description-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0a8';
var svgPathData = ['M32 128l0 256c0 35.3 28.7 64 64 64l282.2 0-108.9-108.9c-4 7.7-12 12.9-21.3 12.9-13.3 0-24-10.7-24-24l0-24-48 0 0 24c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-104c0-7.8 1.4-15.3 4-22.2l-96-96c-2.6 6.9-4 14.4-4 22.2z', 'M41-24.9c-9.4-9.4-24.6-9.4-33.9 0S-2.3-.3 7 9.1l528 528c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-61.4-61.4C529.1 431.4 544 409.5 544 384l0-256c0-35.3-28.7-64-64-64L129.8 64 41-24.9zm311 311l-48-48 0-54.2c0-13.3 10.7-24 24-24l48 0c39.8 0 72 32.2 72 72l0 48c0 27.6-15.6 51.7-38.4 63.7l-39.7-39.7 6.2 0c13.3 0 24-10.7 24-24l0-48c0-13.3-10.7-24-24-24l-24 0 0 78.2z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAudioDescriptionSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;