'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-up-9-1';
var width = 512;
var height = 512;
var aliases = ["sort-numeric-up-alt"];
var unicode = 'f887';
var svgPathData = ['M320 112c0 36.1 23.9 66.7 56.8 76.6l-11.7 18c-9.6 14.8-5.4 34.6 9.4 44.3s34.6 5.4 44.3-9.4l42.1-64.9c12.4-19.2 19.1-41.6 19.1-64.5 0-44.2-35.8-80-80-80s-80 35.8-80 80zm0 336c0 17.7 14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-16 0 0-96c0-10.3-4.9-19.9-13.3-26s-19.1-7.7-28.8-4.4l-48 16c-16.8 5.6-25.8 23.7-20.2 40.5s23.7 25.8 40.5 20.2l5.9-2 0 51.6-16 0c-17.7 0-32 14.3-32 32zM424 112a24 24 0 1 1 -48 0 24 24 0 1 1 48 0z', 'M105.4 41.4c12.5-12.5 32.8-12.5 45.3 0l96 96c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L160 141.3 160 448c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-306.7-41.4 41.4c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l96-96z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUp91 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;