'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-archery';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e839';
var svgPathData = ['M144.7 365.4l307.1-307.1 33.9 33.9-307.1 307.1-3.3-13.2c-2.2-8.6-8.9-15.3-17.5-17.5l-13.2-3.3z', 'M73.4 357c5.8-4.4 13.3-6 20.4-4.2l64 16c8.6 2.2 15.3 8.9 17.5 17.5l16 64c2 8.2-.4 16.8-6.3 22.8l-64 64c-6.1 6.1-15 8.5-23.4 6.2s-14.8-8.9-16.9-17.3l-12.5-50-50-12.5c-8.4-2.1-15-8.5-17.3-16.9S.9 429.1 7 423l64-64 2.3-2.1zM556.1-31.5c5.4-1.4 11.2 .3 15.2 4.2s5.6 9.7 4.2 15.2l-32 128c-1.4 5.6-5.7 10-11.3 11.5-5.6 1.5-11.5 0-15.6-4.1l-96-96c-4.1-4.1-5.6-10-4.1-15.6s5.9-9.9 11.5-11.3l128-32z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowArchery = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;