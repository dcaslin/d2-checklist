'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'barcode-scan';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f465';
var svgPathData = ['M64 64l0 160 64 0 0-160c0-17.7-14.3-32-32-32S64 46.3 64 64zm0 256l0 128c0 17.7 14.3 32 32 32s32-14.3 32-32l0-128-64 0zM160 56l0 168 48 0 0-168c0-13.3-10.7-24-24-24s-24 10.7-24 24zm0 264l0 136c0 13.3 10.7 24 24 24s24-10.7 24-24l0-136-48 0zM256 64l0 160 64 0 0-160c0-17.7-14.3-32-32-32s-32 14.3-32 32zm0 256l0 128c0 17.7 14.3 32 32 32s32-14.3 32-32l0-128-64 0zM368 56l0 168 48 0 0-168c0-13.3-10.7-24-24-24s-24 10.7-24 24zm0 264l0 136c0 13.3 10.7 24 24 24s24-10.7 24-24l0-136-48 0zM464 56l0 168 48 0 0-168c0-13.3-10.7-24-24-24s-24 10.7-24 24zm0 264l0 136c0 13.3 10.7 24 24 24s24-10.7 24-24l0-136-48 0z', 'M0 248c0-13.3 10.7-24 24-24l528 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L24 272c-13.3 0-24-10.7-24-24z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarcodeScan = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;