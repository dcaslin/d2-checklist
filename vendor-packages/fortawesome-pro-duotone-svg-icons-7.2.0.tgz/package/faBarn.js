'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'barn';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6c7';
var svgPathData = ['M32 304c14.5 0 27.6-9.9 31.1-24.6L98.3 131.8c.6-2.6 2.4-4.6 4.9-5.6L256 66.4 408.9 126.2c2.4 1 4.3 3 4.9 5.6l35.2 147.6c3.5 14.7 16.6 24.6 31.1 24.6l0 144c0 35.3-28.7 64-64 64l-64 0 0-160c0-17.7-14.3-32-32-32l-128 0c-17.7 0-32 14.3-32 32l0 160-64 0c-35.3 0-64-28.7-64-64l0-144zM208 168l0 48c0 13.3 10.7 24 24 24l48 0c13.3 0 24-10.7 24-24l0-48c0-13.3-10.7-24-24-24l-48 0c-13.3 0-24 10.7-24 24z', 'M267.7 2.2c-7.5-2.9-15.8-2.9-23.3 0L79.8 66.6C57.9 75.2 41.5 94 36 116.9L.9 264.6c-4.1 17.2 6.5 34.4 23.7 38.5s34.4-6.5 38.5-23.7L98.3 131.8c.6-2.6 2.4-4.6 4.9-5.6L256 66.4 408.9 126.2c2.4 1 4.3 3 4.9 5.6l35.2 147.6c4.1 17.2 21.4 27.8 38.5 23.7s27.8-21.4 23.7-38.5L476 116.9c-5.5-23-21.8-41.8-43.8-50.4L267.7 2.2zM160 512L318.1 512 160 353.9 160 512zm33.9-192L352 478.1 352 352c0-17.7-14.3-32-32-32l-126.1 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;