'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-u-turn-down-left';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e7e7';
var svgPathData = ['M64 64c0 16.6 12.6 30.2 28.7 31.8L96 96 320 96c70.7 0 128 57.3 128 128l-.2 6.6C444.4 298.2 388.5 352 320 352l-210.7 0-32 32 32 32 210.7 0c102.7 0 186.6-80.7 191.8-182.1l.2-9.9c0-106-86-192-192-192l-224 0-3.3 .2C76.6 33.8 64 47.4 64 64z', 'M7.2 363.8c-10.3 12.6-9.5 31.1 2.2 42.8l112 112c12.5 12.5 32.8 12.5 45.2 0s12.5-32.8 0-45.3l-89.4-89.4 89.4-89.4 2.2-2.4c10.2-12.6 9.5-31.1-2.2-42.8s-30.2-12.4-42.8-2.2l-2.4 2.2-112 112-2.2 2.4z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUTurnDownLeft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;