'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrows-rotate-reverse';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e630';
var svgPathData = ['M2.6 292.5C20.3 416.6 127 512 256 512 326.5 512 390.5 483.4 436.7 437.3l10.7-10.1-.4 51.5c-.1 17.7 14.1 32.1 31.7 32.3s32.1-14.1 32.3-31.7l1-127c.1-8.5-3.3-16.7-9.3-22.8S488.5 320 480 320l-128 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l47.9 0-7.6 7.2c-.2 .2-.4 .4-.6 .6-34.8 34.8-82.7 56.2-135.8 56.2-96.7 0-176.7-71.5-190.1-164.5-2.5-17.5-18.7-29.6-36.2-27.1S.1 275 2.6 292.5z', 'M256 64c96.7 0 176.7 71.5 190.1 164.5 2.5 17.5 18.7 29.6 36.2 27.1s29.6-18.7 27.1-36.2C491.7 95.4 385 0 256 0 185.5 0 121.5 28.6 75.3 74.7L64 85.4 64 32C64 14.3 49.7 0 32 0S0 14.3 0 32L0 160c0 17.7 14.3 32 32 32l128 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-47.9 0 7.6-7.2c.2-.2 .4-.4 .6-.6 34.8-34.8 82.7-56.2 135.8-56.2z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsRotateReverse = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;