'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'binary-lock';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e33d';
var svgPathData = ['M64 64l0 96c0 35.3 28.7 64 64 64l64 0c35.3 0 64-28.7 64-64l0-96c0-35.3-28.7-64-64-64L128 0C92.7 0 64 28.7 64 64zm0 416c0 17.7 14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-16 0 0-128c0-10.3-4.9-19.9-13.3-26s-19.1-7.7-28.8-4.4l-48 16c-16.8 5.6-25.8 23.7-20.2 40.5s23.7 25.8 40.5 20.2l5.9-2 0 83.6-16 0c-17.7 0-32 14.3-32 32zM128 64l64 0 0 96-64 0 0-96zM256 352l0 96c0 30.2 20.9 55.5 49.1 62.2-.7-4.7-1.1-9.5-1.1-14.3l0-96c0-28.5 12.4-54 32-71.5l0-24.4c0-5.4 .3-10.8 1-16l-17 0c-35.3 0-64 28.7-64 64zm32-160c0 17.7 14.3 32 32 32l44.1 0c19.6-24.5 48-41.6 80.4-46.5-5.3-10.4-16.1-17.5-28.5-17.5l-16 0 0-128c0-10.3-4.9-19.9-13.3-26s-19.1-7.7-28.8-4.4l-48 16c-16.8 5.6-25.8 23.7-20.2 40.5s23.7 25.8 40.5 20.2l5.9-2 0 83.6-16 0c-17.7 0-32 14.3-32 32z', 'M432 352l0-47.9c0-17.7 14.3-32 32-32s32 14.3 32 32l0 47.9-64 0zm-48 2.7c-18.6 6.6-32 24.4-32 45.3l0 96c0 26.5 21.5 48 48 48l128 0c26.5 0 48-21.5 48-48l0-96c0-20.9-13.4-38.7-32-45.3l0-50.6c0-44.2-35.8-80-80-80s-80 35.8-80 80l0 50.6z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinaryLock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;