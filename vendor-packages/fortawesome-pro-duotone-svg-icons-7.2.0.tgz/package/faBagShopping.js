'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bag-shopping';
var width = 448;
var height = 512;
var aliases = ["shopping-bag"];
var unicode = 'f290';
var svgPathData = ['M0 176c0-26.5 21.5-48 48-48l64 0 0 72c0 13.3 10.7 24 24 24s24-10.7 24-24l0-72 128 0 0 72c0 13.3 10.7 24 24 24s24-10.7 24-24l0-72 64 0c26.5 0 48 21.5 48 48l0 208c0 53-43 96-96 96L96 480c-53 0-96-43-96-96L0 176z', 'M224 16c-35.3 0-64 28.7-64 64l0 120c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-120c0-61.9 50.1-112 112-112S336 18.1 336 80l0 120c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-120c0-35.3-28.7-64-64-64z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBagShopping = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;