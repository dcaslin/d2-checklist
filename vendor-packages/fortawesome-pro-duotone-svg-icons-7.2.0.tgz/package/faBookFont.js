'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'book-font';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e0bf';
var svgPathData = ['M0 96L0 416c0 53 43 96 96 96l320 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l0-66.7c18.6-6.6 32-24.4 32-45.3l0-288c0-26.5-21.5-48-48-48L96 0C43 0 0 43 0 96zM64 416c0-17.7 14.3-32 32-32l256 0 0 64-256 0c-17.7 0-32-14.3-32-32zm50.5-146.7l23.8-47.5c.1-.3 .3-.6 .4-.9L202.5 93.3C206.6 85.1 214.9 80 224 80s17.4 5.1 21.5 13.3l63.8 127.6c.2 .3 .3 .6 .4 .9l23.8 47.5c5.9 11.9 1.1 26.3-10.7 32.2s-26.3 1.1-32.2-10.7l-17.4-34.7-98.3 0-17.4 34.7c-5.9 11.9-20.3 16.7-32.2 10.7s-16.7-20.3-10.7-32.2zM198.8 208l50.3 0-25.2-50.3-25.2 50.3z', 'M224 80c9.1 0 17.4 5.1 21.5 13.3l63.8 127.6c.2 .3 .3 .6 .4 .9l23.8 47.5c5.9 11.9 1.1 26.3-10.7 32.2s-26.3 1.1-32.2-10.7l-17.4-34.7-98.3 0-17.4 34.7c-5.9 11.9-20.3 16.7-32.2 10.7s-16.7-20.3-10.7-32.2l23.8-47.5c.1-.3 .3-.6 .4-.9L202.5 93.3C206.6 85.1 214.9 80 224 80zM198.8 208l50.3 0-25.2-50.3-25.2 50.3z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookFont = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;