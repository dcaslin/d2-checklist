'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bell-on';
var width = 640;
var height = 512;
var aliases = [128365];
var unicode = 'f8fa';
var svgPathData = ['M96 380.5c0 19.6 15.9 35.5 35.5 35.5l376.9 0c19.6 0 35.5-15.9 35.5-35.5 0-8.1-2.7-15.9-7.8-22.2l-9.8-12.2C496.4 308.5 480 261.8 480 213.7l0-21.7c0-77.4-55-142-128-156.8l0-3.2c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 3.2C215 50 160 114.6 160 192l0 21.7c0 48.1-16.4 94.8-46.4 132.4l-9.8 12.2c-5 6.3-7.8 14.1-7.8 22.2z', 'M606.1 14.5c5.2 12.2-.4 26.3-12.6 31.5l-56 24c-12.2 5.2-26.3-.4-31.5-12.6s.4-26.3 12.6-31.5l56-24c12.2-5.2 26.3 .4 31.5 12.6zM0 184c0-13.3 10.7-24 24-24l64 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-64 0c-13.3 0-24-10.7-24-24zM258 464l124 0c-7.1 27.6-32.2 48-62 48s-54.9-20.4-62-48zM552 160l64 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-64 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zM46.5 46.1C34.4 40.8 28.7 26.7 33.9 14.5S53.3-3.3 65.5 1.9l56 24c12.2 5.2 17.8 19.3 12.6 31.5s-19.3 17.8-31.5 12.6l-56-24z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellOn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;