'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-up-from-ground-water';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4b5';
var svgPathData = ['M64 240l0 147.2c6.8 2.4 13.3 5.8 19.3 10.4 3.4 2.6 6.1 1.4 9.8-.3 .3-.1 .6-.3 .8-.4 5.7-2.6 12.9-6.9 21.7-13.5 27.5-20.7 59.9-31.2 92.3-31.4 10.7-.1 21.4 1 32 3.1l0-163.1-128 0c-26.5 0-48 21.5-48 48zm336-48l0 167.3c15-4.8 30.4-7.2 46-7.3 33.1-.2 66.3 10.2 94.4 31.4 6.9 5.2 12.8 9 18 11.7 .6 .3 1.2 .6 1.8 1 4.2 2.3 8.5 4.6 12.6 1.5 1.1-.8 2.2-1.6 3.3-2.4L576 240c0-26.5-21.5-48-48-48l-128 0z', 'M303 7c9.4-9.4 24.6-9.4 33.9 0l88 88c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-47-47 0 278.1c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-278.1-47 47c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9L303 7zm171.6 469c-21.3-16.1-49.9-16.1-71.2 0-24.2 18.3-52.3 35.9-83.4 35.9s-59.1-17.7-83.4-35.9c-21.3-16.1-49.9-16.1-71.2 0-23.8 17.9-54.1 35.5-88.1 35.3-20.4-.1-40.7-6.7-59.8-21.1-10.6-8-12.7-23-4.7-33.6s23-12.7 33.6-4.7c11.3 8.5 21.6 11.4 31.2 11.5 17.6 .1 37.3-9.4 58.9-25.7 38.4-29 90.5-29 129 0 24 18.1 40.7 26.3 54.5 26.3s30.5-8.2 54.5-26.3c38.4-29 90.5-29 129 0 16.9 12.7 32.9 21.5 47.8 24.6 13.7 2.8 27.4 .9 42.3-10.3 10.6-8 25.6-5.9 33.6 4.7s5.9 25.6-4.7 33.6c-26.4 19.9-54.2 24.4-80.7 19.1-25.3-5.1-48.1-18.9-67.2-33.3z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpFromGroundWater = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;