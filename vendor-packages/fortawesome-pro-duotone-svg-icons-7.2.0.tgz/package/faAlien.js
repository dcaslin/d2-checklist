'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'alien';
var width = 448;
var height = 512;
var aliases = [128125];
var unicode = 'f8f5';
var svgPathData = ['M0 224c0 135.3 148.8 247.7 194.7 279.2 8.6 5.9 18.9 8.8 29.3 8.8s20.7-2.9 29.3-8.8C299.2 471.7 448 359.3 448 224 448 100.3 347.7 0 224 0S0 100.3 0 224zm64 13.7c0-7.6 6.1-13.7 13.7-13.7l32 0c45.4 0 82.3 36.8 82.3 82.3 0 7.6-6.1 13.7-13.7 13.7l-32 0C100.8 320 64 283.2 64 237.7zm192 68.6c0-45.4 36.8-82.3 82.3-82.3l32 0c7.6 0 13.7 6.1 13.7 13.7 0 45.4-36.8 82.3-82.3 82.3l-32 0c-7.6 0-13.7-6.1-13.7-13.7z', 'M109.7 224c45.4 0 82.3 36.8 82.3 82.3 0 7.6-6.1 13.7-13.7 13.7l-32 0c-45.4 0-82.3-36.8-82.3-82.3 0-7.6 6.1-13.7 13.7-13.7l32 0zm228.6 0l32 0c7.6 0 13.7 6.1 13.7 13.7 0 45.4-36.8 82.3-82.3 82.3l-32 0c-7.6 0-13.7-6.1-13.7-13.7 0-45.4 36.8-82.3 82.3-82.3z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlien = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;