'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'alarm-minus';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e803';
var svgPathData = ['M32 288c0 50.3 16.6 96.7 44.6 134.1L41.4 457.4c-12.5 12.5-12.5 32.8 0 45.2s32.8 12.5 45.2 0l35.2-35.2c37.4 28 83.8 44.6 134.2 44.6s96.7-16.6 134.1-44.6l35.3 35.2c12.5 12.5 32.8 12.5 45.2 0s12.5-32.8 0-45.2l-35.2-35.3c28-37.4 44.6-83.8 44.6-134.1 0-123.7-100.3-224-224-224S32 164.3 32 288zm128 0c0-13.3 10.7-24 24-24l144 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-144 0c-13.3 0-24-10.7-24-24z', 'M328 264c13.3 0 24 10.7 24 24s-10.7 24-24 24l-144 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l144 0zM95.2 0c19.3 0 37.3 5.8 52.3 15.7 9.5 6.3 6.3 19.9-4.1 24.7-44.8 20.4-83 52.5-110.8 92.5-6.5 9.4-20.5 10.1-25-.4-4.9-11.4-7.7-24-7.7-37.3 0-52.6 42.6-95.2 95.2-95.2zM416.7 0c52.6 0 95.3 42.6 95.3 95.2 0 13.2-2.7 25.8-7.7 37.3-4.5 10.5-18.4 9.7-25 .3-27.8-40-66-72.1-110.8-92.5-10.4-4.7-13.7-18.3-4.1-24.7 15-9.9 32.9-15.7 52.3-15.7z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlarmMinus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;