'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'boombox';
var width = 576;
var height = 512;
var aliases = [128254];
var unicode = 'f8a5';
var svgPathData = ['M0 224c0-23.7 12.9-44.4 32-55.4 9.4-5.4 20.3-8.6 32-8.6l448 0c11.7 0 22.6 3.1 32 8.6 19.1 11.1 32 31.7 32 55.4l0 192c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 224zm64 96a96 96 0 1 0 192 0 96 96 0 1 0 -192 0zm256 0a96 96 0 1 0 192 0 96 96 0 1 0 -192 0z', 'M120 48C97.9 48 80 65.9 80 88l0 72-16 0c-11.7 0-22.6 3.1-32 8.6L32 88C32 39.4 71.4 0 120 0L456 0c48.6 0 88 39.4 88 88l0 80.6c-9.4-5.4-20.3-8.6-32-8.6l-16 0 0-72c0-22.1-17.9-40-40-40L120 48zm88 272a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM64 320a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zm352 48a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm0-144a96 96 0 1 1 0 192 96 96 0 1 1 0-192zM192 128c17.7 0 32 14.3 32 32l-64 0c0-17.7 14.3-32 32-32zm96 0c17.7 0 32 14.3 32 32l-64 0c0-17.7 14.3-32 32-32zm96 0c17.7 0 32 14.3 32 32l-64 0c0-17.7 14.3-32 32-32z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoombox = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;