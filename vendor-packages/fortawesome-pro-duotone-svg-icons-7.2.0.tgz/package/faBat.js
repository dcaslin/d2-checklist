'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bat';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f6b5';
var svgPathData = ['M195.1 159.2c8.5 4 17 8.1 25.5 12.1 6.4 3.1 13.5 4.7 20.6 4.7l93.5 0c7.1 0 14.2-1.6 20.6-4.7l25.5-12.1-18.6-99.3c-1.3-6.9-7.3-11.9-14.4-11.9-2.5 0-5 .7-7.2 1.9l-36.8 21c-9.8 5.6-21.9 5.6-31.8 0l-36.8-21c-2.2-1.3-4.7-1.9-7.2-1.9-7 0-13.1 5-14.4 11.9l-18.6 99.3z', 'M334.8 176l-93.5 0c-7.1 0-14.2-1.6-20.6-4.7L123.4 125C107.2 117.3 87.9 121.4 76.3 135 27.1 192.4 0 265.6 0 341.2l0 37.6c0 9.7 10.2 16 18.9 11.7l63.8-31.9c7.5-3.7 16.6-1.1 20.9 6.1l29.8 49.7c5.4 8.9 17.7 10.4 25 3.1l36.6-36.6c6.8-6.8 18.1-6.1 24 1.6l56.2 73.1c6.4 8.3 19 8.3 25.4 0l56.2-73.1c5.9-7.7 17.2-8.4 24-1.6l36.6 36.6c7.4 7.4 19.7 5.8 25-3.1l29.8-49.7c4.3-7.2 13.4-9.8 20.9-6.1l63.8 31.9c8.7 4.3 18.9-2 18.9-11.7l0-37.6c0-75.6-27.1-148.8-76.3-206.2-11.6-13.6-30.9-17.7-47.1-10l-97.2 46.3c-6.4 3.1-13.5 4.7-20.6 4.7z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBat = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;