'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'book-tanakh';
var width = 448;
var height = 512;
var aliases = ["tanakh"];
var unicode = 'f827';
var svgPathData = ['M0 48L0 336c0 20.9 13.4 38.7 32 45.3L32 448c-17.7 0-32 14.3-32 32s14.3 32 32 32l320 0c53 0 96-43 96-96l0-320c0-53-43-96-96-96L48 0C21.5 0 0 21.5 0 48zM96 384l256 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-256 0 0-64zm16-251.5c0-6.9 5.6-12.5 12.5-12.5l56.9 0 30.5-49.2C214.4 66.6 219 64 224 64s9.6 2.6 12.2 6.8l30.5 49.2 56.9 0c6.9 0 12.5 5.6 12.5 12.5 0 2.3-.6 4.6-1.9 6.6l-27.8 45 27.8 45c1.2 2 1.9 4.2 1.9 6.6 0 6.9-5.6 12.5-12.5 12.5l-56.9 0-30.5 49.2c-2.6 4.2-7.2 6.8-12.2 6.8s-9.6-2.6-12.2-6.8l-30.5-49.2-56.9 0c-6.9 0-12.5-5.6-12.5-12.5 0-2.3 .6-4.6 1.9-6.6l27.8-45-27.8-45c-1.2-2-1.9-4.2-1.9-6.6z', 'M141.7 184l-27.8 45c-1.2 2-1.9 4.2-1.9 6.6 0 6.9 5.6 12.5 12.5 12.5l56.9 0 30.5 49.2c2.6 4.2 7.2 6.8 12.2 6.8s9.6-2.6 12.2-6.8l30.5-49.2 56.9 0c6.9 0 12.5-5.6 12.5-12.5 0-2.3-.6-4.6-1.9-6.6l-27.8-45 27.8-45c1.2-2 1.9-4.2 1.9-6.6 0-6.9-5.6-12.5-12.5-12.5l-56.9 0-30.5-49.2C233.6 66.6 229 64 224 64s-9.6 2.6-12.2 6.8l-30.5 49.2-56.9 0c-6.9 0-12.5 5.6-12.5 12.5 0 2.3 .6 4.6 1.9 6.6l27.8 45z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookTanakh = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;