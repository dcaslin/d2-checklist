'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'blender';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f517';
var svgPathData = ['M0 56L0 184c0 30.9 25.1 56 56 56l59.2 0 11.6 145.1c3-.7 6-1.1 9.2-1.1l240 0c4 0 7.8 .6 11.4 1.7 11.7-48.6 23.3-97.1 35-145.7L344 240c-13.3 0-24-10.7-24-24s10.7-24 24-24l89.9 0c5.1-21.3 10.2-42.7 15.4-64L344 128c-13.3 0-24-10.7-24-24s10.7-24 24-24l116.8 0c3.2-13.5 6.5-27 9.7-40.5 4.8-20.1-10.4-39.5-31.1-39.5L56 0C25.1 0 0 25.1 0 56zm48 0c0-4.4 3.6-8 8-8l43.8 0 11.5 144-55.4 0c-4.4 0-8-3.6-8-8L48 56z', 'M344 80l116.8 0-11.5 48-105.3 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm0 112l89.9 0-11.5 48-78.4 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zM96 424c0-22.1 17.9-40 40-40l240 0c22.1 0 40 17.9 40 40l0 48c0 22.1-17.9 40-40 40l-240 0c-22.1 0-40-17.9-40-40l0-48zm184 24a24 24 0 1 0 -48 0 24 24 0 1 0 48 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlender = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;