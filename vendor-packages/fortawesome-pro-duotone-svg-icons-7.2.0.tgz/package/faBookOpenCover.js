'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'book-open-cover';
var width = 576;
var height = 512;
var aliases = ["book-open-alt"];
var unicode = 'e0c0';
var svgPathData = ['M288 72l0 382c3.6 0 7.3-.6 10.8-1.9l38.6-13.8c41.5-14.8 85.1-22.4 129.2-22.4l61.5 0c26.5 0 48-21.5 48-48l0-288c0-26.5-21.5-48-48-48l-61.5 0c-44 0-87.7 7.6-129.2 22.4L288 72z', 'M238.6 54.4L288 72 288 454c-3.6 0-7.3-.6-10.8-1.9l-38.6-13.8C197.2 423.6 153.5 416 109.5 416L48 416c-26.5 0-48-21.5-48-48L0 80C0 53.5 21.5 32 48 32l61.5 0c44 0 87.7 7.6 129.2 22.4zM24 464l85.5 0c46.8 0 93.2 8 137.2 23.8l38.6 13.8c1.7 .6 3.6 .6 5.4 0l38.6-13.8c44-15.7 90.5-23.8 137.2-23.8l85.5 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-85.5 0c-41.3 0-82.2 7.1-121.1 21l-38.6 13.8c-12.2 4.3-25.5 4.3-37.7 0L230.6 533c-38.9-13.9-79.8-21-121.1-21L24 512c-13.3 0-24-10.7-24-24s10.7-24 24-24z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookOpenCover = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;