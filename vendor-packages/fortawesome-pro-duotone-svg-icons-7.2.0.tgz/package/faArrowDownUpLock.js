'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-down-up-lock';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e4b0';
var svgPathData = ['M32 256c0 17.7 14.3 32 32 32l64 0 0 114.7-25.4-25.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l80 80c12.5 12.5 32.8 12.5 45.3 0l80-80c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-25.4 25.4 0-114.7 145 0c4.2-33.9 21.7-63.6 47-83.9l0-94.8 25.4 25.4c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-80-80c-12.5-12.5-32.8-12.5-45.3 0l-80 80c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l25.4-25.4 0 114.7-256 0c-17.7 0-32 14.3-32 32zM128 32l0 144 64 0 0-144c0-17.7-14.3-32-32-32s-32 14.3-32 32z', 'M432 352l0-47.9c0-17.7 14.3-32 32-32s32 14.3 32 32l0 47.9-64 0zm-48 2.7c-18.6 6.6-32 24.4-32 45.3l0 96c0 26.5 21.5 48 48 48l128 0c26.5 0 48-21.5 48-48l0-96c0-20.9-13.4-38.7-32-45.3l0-50.6c0-44.2-35.8-80-80-80s-80 35.8-80 80l0 50.6z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownUpLock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;