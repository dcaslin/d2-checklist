'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'axe-battle';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f6b3';
var svgPathData = ['M0 192c0 71.6 29.4 136.3 76.8 182.8 8.8 8.6 23.3 3 27.2-8.7 17.7-54.1 63.5-95.4 120.1-106.9l0-134.4C167.4 113.3 121.7 71.9 103.9 17.9 100.1 6.2 85.6 .6 76.8 9.2 29.4 55.7 0 120.4 0 192zm288-67.2l0 134.4c56.6 11.5 102.4 52.9 120.1 106.9 3.8 11.7 18.3 17.3 27.2 8.7 38.3-37.5 64.8-86.9 73.6-142.3L448 192 508.8 151.5c-8.8-55.3-35.3-104.8-73.6-142.3-8.8-8.6-23.3-3-27.2 8.7-17.7 54.1-63.5 95.4-120.1 106.9z', 'M256 0c17.7 0 32 14.3 32 32l0 480c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-480c0-17.7 14.3-32 32-32z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAxeBattle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;