'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrows-minimize';
var width = 448;
var height = 512;
var aliases = ["compress-arrows"];
var unicode = 'e0a5';
var svgPathData = ['M9.4 425.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l73.4-73.4 0 34.7c0 17.7 14.3 32 32 32s32-14.3 32-32l0-112c0-17.7-14.3-32-32-32L48 288c-17.7 0-32 14.3-32 32s14.3 32 32 32l34.7 0-73.4 73.4zM256 80l0 112c0 17.7 14.3 32 32 32l112 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-34.7 0 73.4-73.4c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L320 114.7 320 80c0-17.7-14.3-32-32-32s-32 14.3-32 32z', 'M9.4 41.4c12.5-12.5 32.8-12.5 45.3 0L128 114.7 128 80c0-17.7 14.3-32 32-32s32 14.3 32 32l0 112c0 17.7-14.3 32-32 32L48 224c-17.7 0-32-14.3-32-32s14.3-32 32-32l34.7 0-73.4-73.4C-3.1 74.1-3.1 53.9 9.4 41.4zM256 320c0-17.7 14.3-32 32-32l112 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-34.7 0 73.4 73.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L320 397.3 320 432c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-112z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsMinimize = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;