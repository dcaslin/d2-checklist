'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'airplay-audio';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e77b';
var svgPathData = ['M0 256c0 66.3 25.2 126.8 66.6 172.2l34-34C67.9 357.5 48 309.1 48 256 48 141.1 141.1 48 256 48s208 93.1 208 208c0 53.1-19.9 101.5-52.6 138.3l34 34C486.8 382.8 512 322.3 512 256 512 114.6 397.4 0 256 0S0 114.6 0 256zm96 0c0 39.8 14.5 76.2 38.6 104.2l34.1-34.1c-15.5-19.2-24.7-43.6-24.7-70.2 0-61.9 50.1-112 112-112s112 50.1 112 112c0 26.6-9.2 51-24.7 70.2l34.1 34.1c24.1-28 38.6-64.4 38.6-104.2 0-88.4-71.6-160-160-160S96 167.6 96 256zm96 0c0 13.4 4.1 25.7 11.1 36 30.2-26.7 75.7-26.7 105.8 0 7-10.3 11.1-22.7 11.1-36 0-35.3-28.7-64-64-64s-64 28.7-64 64z', 'M128 512c-12.9 0-24.6-7.8-29.6-19.8s-2.2-25.7 6.9-34.9l128-128c12.5-12.5 32.8-12.5 45.3 0l128 128c9.2 9.2 11.9 22.9 6.9 34.9S396.9 512 384 512l-256 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAirplayAudio = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;