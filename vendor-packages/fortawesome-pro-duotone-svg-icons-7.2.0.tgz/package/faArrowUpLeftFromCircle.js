'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-up-left-from-circle';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e09e';
var svgPathData = ['M67.1 325.3c17.8 106 109.9 186.7 220.9 186.7 123.7 0 224-100.3 224-224 0-111-80.7-203.1-186.7-220.9-17.4-2.9-33.9 8.8-36.9 26.3s8.8 33.9 26.3 36.9c75.6 12.7 133.3 78.5 133.3 157.8 0 88.4-71.6 160-160 160-79.2 0-145.1-57.6-157.8-133.3-2.9-17.4-19.4-29.2-36.9-26.3s-29.2 19.4-26.3 36.9z', 'M32 0L192 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-82.7 0 233.4 233.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L64 109.3 64 192c0 17.7-14.3 32-32 32S0 209.7 0 192L0 32C0 14.3 14.3 0 32 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpLeftFromCircle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;