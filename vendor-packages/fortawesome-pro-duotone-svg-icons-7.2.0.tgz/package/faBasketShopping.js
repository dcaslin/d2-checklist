'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'basket-shopping';
var width = 576;
var height = 512;
var aliases = ["shopping-basket"];
var unicode = 'f291';
var svgPathData = ['M16 192c0-17.7 14.3-32 32-32l78.1 0c-8.6 9.6-8.1 24.5 1.4 33.4 9.6 9.1 24.8 8.7 33.9-.9l30.8-32.5 191.6 0 30.8 32.5c9.1 9.6 24.3 10 33.9 .9 9.5-9 10-23.8 1.4-33.4l78.1 0c17.7 0 32 14.3 32 32 0 14.5-9.6 26.7-22.8 30.7L491.1 429.9c-6.5 29.3-32.5 50.1-62.5 50.1l-281.3 0c-30 0-56-20.8-62.5-50.1l-46-207.2C25.6 218.7 16 206.5 16 192zm144 72l0 112c0 13.3 10.7 24 24 24s24-10.7 24-24l0-112c0-13.3-10.7-24-24-24s-24 10.7-24 24zm104 0l0 112c0 13.3 10.7 24 24 24s24-10.7 24-24l0-112c0-13.3-10.7-24-24-24s-24 10.7-24 24zm104 0l0 112c0 13.3 10.7 24 24 24s24-10.7 24-24l0-112c0-13.3-10.7-24-24-24s-24 10.7-24 24z', 'M288 0c6.6 0 12.9 2.7 17.4 7.5l144 152c9.1 9.6 8.7 24.8-.9 33.9s-24.8 8.7-33.9-.9L288 58.9 161.4 192.5c-9.1 9.6-24.3 10-33.9 .9s-10-24.3-.9-33.9l144-152C275.1 2.7 281.4 0 288 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBasketShopping = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;