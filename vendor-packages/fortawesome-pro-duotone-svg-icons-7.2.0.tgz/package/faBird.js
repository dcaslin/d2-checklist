'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bird';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e469';
var svgPathData = ['M162.1 407.4c18.7 5.4 38.5 8.4 58.9 8.6l32.2 60.8 1 2.2c4.6 11.3 0 24.4-11 30.2s-24.4 2.2-31.2-7.9l-1.3-2.1-48.6-91.9zm99 5.6c16.4-2.7 32.2-7.3 47.2-13.4l40.9 77.2 1 2.2c4.6 11.3 0 24.4-11 30.2s-24.4 2.2-31.2-7.9l-1.3-2.1-45.7-86.3zM446.6 79.7l57.6 34.6c4.8 2.9 7.8 8.1 7.8 13.7s-3 10.8-7.8 13.7L448 175.4 448 96c0-5.5-.5-11-1.4-16.3z', 'M0 188.4L0 192C0 315.7 100.3 416 224 416S448 315.7 448 192l0-96c0-53-43-96-96-96s-96 43-96 96l0 32c0 17.7-14.3 32-32 32L28.4 160C12.7 160 0 172.7 0 188.4zM352 96a24 24 0 1 1 0 48 24 24 0 1 1 0-48z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBird = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;