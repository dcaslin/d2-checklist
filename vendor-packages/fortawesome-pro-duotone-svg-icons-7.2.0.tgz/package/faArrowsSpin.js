'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrows-spin';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e4bb';
var svgPathData = ['M.6 237.7c-1.2 17.6 12 32.9 29.7 34.2s32.9-12 34.2-29.7c3.3-47 23.6-89.4 54.8-121L151 153c6.9 6.9 17.2 8.9 26.2 5.2S192 145.7 192 136l0-112c0-13.3-10.7-24-24-24L56 0C46.3 0 37.5 5.8 33.8 14.8S32.2 34.1 39 41L74 76C32.3 118.1 5.1 174.8 .6 237.7zM320 376l0 112c0 13.3 10.7 24 24 24l112 0c9.7 0 18.5-5.8 22.2-14.8s1.7-19.3-5.2-26.2l-35-35c41.7-42.2 68.9-98.8 73.4-161.8 1.2-17.6-12-32.9-29.7-34.2s-32.9 12-34.2 29.7c-3.3 47-23.6 89.4-54.8 121L361 359c-6.9-6.9-17.2-8.9-26.2-5.2S320 366.3 320 376z', 'M274.3 .6c-17.6-1.2-32.9 12-34.2 29.7s12 32.9 29.7 34.2c47 3.3 89.4 23.6 121 54.8L359 151c-6.9 6.9-8.9 17.2-5.2 26.2S366.3 192 376 192l112 0c13.3 0 24-10.7 24-24l0-112c0-9.7-5.8-18.5-14.8-22.2S477.9 32.2 471 39L436 74C393.9 32.3 337.2 5.1 274.3 .6zM76 438c42.2 41.7 98.8 68.9 161.8 73.4 17.6 1.2 32.9-12 34.2-29.7s-12-32.9-29.7-34.2c-47-3.3-89.4-23.6-121-54.8L153 361c6.9-6.9 8.9-17.2 5.2-26.2S145.7 320 136 320L24 320c-13.3 0-24 10.7-24 24L0 456c0 9.7 5.8 18.5 14.8 22.2S34.1 479.8 41 473l35-35z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsSpin = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;