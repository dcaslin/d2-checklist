'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'block-brick-fire';
var width = 640;
var height = 512;
var aliases = ["firewall"];
var unicode = 'e3dc';
var svgPathData = ['M96 96l0 16 96 0 0-80-32 0c-35.3 0-64 28.7-64 64zm0 48l0 96 208 0 0-96-208 0zm0 128l0 96 96 0 0-96-96 0zm0 128l0 16c0 35.3 28.7 64 64 64l122.6 0c-6.9-20.9-10.6-43.1-10.6-65.9 0-4.7 .3-9.4 .7-14.1L96 400zM224 32l0 80 192 0 0-80-192 0zm0 240l0 96 55.2 0c7.2-24.5 19.2-48.3 32.3-69.7 5.4-8.8 11.3-17.6 17.7-26.3L224 272zM336 144l0 96 18.6 0c14.4-16.7 30.2-32.9 47.2-48.1 23.9-21.3 60.1-21.2 83.9 .2 8.3 7.5 16.3 15.1 24.2 23.1 10.3-7.1 22.2-10.7 34.1-11l0-60.2-208 0zM448 32l0 80 96 0 0-16c0-35.3-28.7-64-64-64l-32 0z', 'M518 258.5l-12.3 13.8s-24.5-29.4-38.9-40.7c-5.4-4.3-11.5-7.3-18.8-7.5s-14.6 2.3-20.3 7.5c-23.4 21.1-50 48.9-70.9 80.2-20.8 31.1-36.8 67.1-36.8 104.5 0 88.6 70.4 159.8 160 159.8 88.7 0 160-71.2 160-159.8 0-30-11-60.9-26.2-88.1-15.2-27.4-35.3-52.3-55-70.6-5.6-5.2-12.8-7.8-19.9-7.8-7.6 0-15.5 2.8-20.9 8.9zM480 528.2c-35.3 0-64-28.7-64-64 0-36.5 37-73 54.8-88.4 5.4-4.7 13.1-4.7 18.5 0 17.7 15.4 54.8 51.9 54.8 88.4 0 35.3-28.7 64-64 64z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlockBrickFire = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;