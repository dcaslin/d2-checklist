'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'alarm-snooze';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f845';
var svgPathData = ['M32 288c0 50.3 16.6 96.8 44.6 134.2L41.4 457.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l35.2-35.2c37.4 28 83.8 44.6 134.1 44.6s96.8-16.6 134.2-44.6l35.2 35.2c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-35.2-35.2c28-37.4 44.6-83.8 44.6-134.2 0-123.7-100.3-224-224-224S32 164.3 32 288zm144-72c0-13.3 10.7-24 24-24l112 0c9.2 0 17.5 5.2 21.6 13.5s3 18-2.6 25.3L249.1 336 312 336c13.3 0 24 10.7 24 24s-10.7 24-24 24l-112 0c-9.2 0-17.5-5.2-21.6-13.5s-3-18 2.6-25.3L262.9 240 200 240c-13.3 0-24-10.7-24-24z', 'M479.5 132.9c6.5 9.4 20.5 10.1 24.9-.4 4.9-11.5 7.6-24.1 7.6-37.3 0-52.6-42.6-95.2-95.2-95.2-19.3 0-37.3 5.8-52.3 15.7-9.6 6.3-6.3 19.9 4.1 24.6 44.8 20.4 83.1 52.6 111 92.6zM7.6 132.5c4.5 10.5 18.4 9.8 24.9 .4 27.8-40 66.1-72.2 111-92.6 10.4-4.7 13.7-18.3 4.1-24.6-15-9.9-33-15.7-52.3-15.7-52.6 0-95.2 42.6-95.2 95.2 0 13.2 2.7 25.8 7.6 37.3zM200 192c-13.3 0-24 10.7-24 24s10.7 24 24 24l62.9 0-81.9 105.3c-5.6 7.2-6.6 17-2.6 25.3S190.8 384 200 384l112 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-62.9 0 81.9-105.3c5.6-7.2 6.6-17 2.6-25.3S321.2 192 312 192l-112 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlarmSnooze = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;