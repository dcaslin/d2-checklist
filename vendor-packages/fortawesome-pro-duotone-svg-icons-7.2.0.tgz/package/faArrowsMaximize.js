'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrows-maximize';
var width = 448;
var height = 512;
var aliases = ["expand-arrows"];
var unicode = 'f31d';
var svgPathData = ['M0 64L0 192c0 17.7 14.3 32 32 32s32-14.3 32-32L64 141.3 178.7 256 224 210.7 109.3 96 160 96c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 32C14.3 32 0 46.3 0 64zM224 301.3L338.7 416 288 416c-17.7 0-32 14.3-32 32s14.3 32 32 32l128 0c17.7 0 32-14.3 32-32l0-128c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 50.7-114.7-114.7c-15.1 15.1-30.2 30.2-45.3 45.3z', 'M256 64c0-17.7 14.3-32 32-32l128 0c17.7 0 32 14.3 32 32l0 128c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-50.7-274.7 274.7 50.7 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 480c-17.7 0-32-14.3-32-32L0 320c0-17.7 14.3-32 32-32s32 14.3 32 32L64 370.7 338.7 96 288 96c-17.7 0-32-14.3-32-32z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsMaximize = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;