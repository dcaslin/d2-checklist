'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'blender-phone';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f6b6';
var svgPathData = ['M194.8 34.6C193.3 15.9 208 0 226.7 0L535.4 0c20.7 0 35.9 19.3 31.1 39.5-3.2 13.5-6.5 27-9.7 40.5L440 80c-13.3 0-24 10.7-24 24s10.7 24 24 24l105.3 0c-5.1 21.3-10.2 42.7-15.4 64L440 192c-13.3 0-24 10.7-24 24s10.7 24 24 24l78.4 0c-11.7 48.5-23.3 97.1-35 145.7-3.6-1.1-7.5-1.7-11.4-1.7l-240 0c-3.2 0-6.2 .4-9.2 1.1l-28-350.5z', 'M151.4 13.2c10.2 5.8 14.5 18.4 10 29.3L138.2 98.8c-3.9 9.6-13.7 15.4-24 14.4l-20.2-2C78.7 152.9 78 198.9 91.9 241.1l22.4-2.2c10.3-1 20 4.8 24 14.4l23.2 56.3c4.5 10.9 .2 23.4-10 29.3l-2.9 1.6c-33.6 19.2-81.7 16.2-106.2-21.6-56.3-86.6-56.3-199.1 0-285.7 24.6-37.7 72.7-40.7 106.2-21.6l2.9 1.6zM556.8 80l-11.5 48-105.3 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l116.8 0zM529.9 192l-11.5 48-78.4 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l89.9 0zM232 384l240 0c22.1 0 40 17.9 40 40l0 48c0 22.1-17.9 40-40 40l-240 0c-22.1 0-40-17.9-40-40l0-48c0-22.1 17.9-40 40-40zm120 88a24 24 0 1 0 0-48 24 24 0 1 0 0 48z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlenderPhone = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;