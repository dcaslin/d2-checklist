'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'aeropress';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e82b';
var svgPathData = ['M64 144c0-20.9 13.4-38.7 32-45.3 2.5-.8 5.1-1.5 7.8-2 2.7-.5 5.4-.7 8.2-.7l160 0c2.8 0 5.6 .3 8.2 .7 2.7 .5 5.3 1.1 7.8 2.1 18.6 6.5 32 24.3 32 45.2l0 256-256 0 0-256zm160 24a24 24 0 1 0 48 0 24 24 0 1 0 -48 0zm0 80a24 24 0 1 0 48 0 24 24 0 1 0 -48 0zm0 80a24 24 0 1 0 48 0 24 24 0 1 0 -48 0z', 'M360 400c13.3 0 24 10.7 24 24s-10.7 24-24 24l-40 0 0 16c0 26.5-21.5 48-48 48l-160 0c-26.5 0-48-21.5-48-48l0-16-40 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l336 0zM312-16c13.3 0 24 10.7 24 24s-10.7 24-24 24l-24 0 0 66.8C283 97 277.6 96 272 96L112 96c-5.6 0-11 1-16 2.8L96 32 72 32C58.7 32 48 21.3 48 8S58.7-16 72-16l240 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAeropress = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;