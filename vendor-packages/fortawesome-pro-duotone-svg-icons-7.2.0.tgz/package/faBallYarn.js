'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'ball-yarn';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6ce';
var svgPathData = ['M1.1 232l509.8 0c-1.5-16.5-4.6-32.6-9.2-48L10.3 184c-4.5 15.4-7.6 31.5-9.2 48zm0 48c1.5 16.5 4.6 32.6 9.2 48l491.5 0c4.5-15.4 7.6-31.5 9.2-48L1.1 280zM29.8 136L207 136 243.4 .3C150.7 4.8 71 58.6 29.8 136zm0 240c20.6 38.7 50.8 71.5 87.4 95.2l25.5-95.2-112.9 0zM160.9 493.7c19.7 7.9 40.5 13.4 62.3 16.2l35.9-133.9-66.6 0-31.5 117.7zM256 512l232 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-82.7 0c31.9-22.9 58.3-53.1 76.9-88l-173.5 0-36.3 135.5c-5.4 .3-10.9 .5-16.4 .5zm.7-376l66.6 0 31.2-116.4c-19.6-8.2-40.4-14-62-17.1L256.7 136zM373 136l109.2 0c-20-37.6-49-69.6-84.2-93.1L373 136z', 'M29.8 136L207 136 243.4 .3c4.2-.2 8.4-.3 12.6-.3 12.4 0 24.6 .9 36.5 2.6l-35.7 133.4 66.6 0 31.2-116.4C369.8 26 384.3 33.8 398 42.9L373 136 482.2 136c8.1 15.2 14.6 31.2 19.5 48L10.3 184c4.9-16.8 11.5-32.8 19.5-48zM1.1 280C.4 272.1 0 264.1 0 256s.4-16.1 1.1-24l509.8 0c1.5 15.7 1.5 32.3 0 48L1.1 280zm28.7 96c-8.1-15.2-14.6-31.2-19.5-48l491.5 0c-4.9 16.8-11.5 32.8-19.5 48l-173.5 0-36.3 135.5c-5.4 .3-10.9 .5-16.4 .5-11.1 0-22.1-.7-32.9-2.1l35.9-133.9-66.6 0-31.5 117.7c-15.3-6.1-29.9-13.7-43.6-22.6l25.5-95.2-112.9 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBallYarn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;