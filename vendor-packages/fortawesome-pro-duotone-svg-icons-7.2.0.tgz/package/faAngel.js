'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'angel';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f779';
var svgPathData = ['M16 172.3l0 63.4c0 42.4 17.8 80.6 46.3 107.6 16.4 15.6 23 41.2 19.3 63.6l-9.3 55.5c-4.3 26 15.7 49.6 42 49.6l77.7 0c3.4 0 6.8-.2 10.1-.5-17.4-3.2-29.4-20.4-25.4-38.4l43.2-194.4c3.7-16.8 13.3-31.1 26.4-40.8L150.9 123.4C136.4 106.1 114.9 96 92.3 96 50.1 96 16 130.1 16 172.3zM160 48c0 14 9 27 24.3 37.5 3.8-9.2 8.7-17.8 14.7-25.5-4.5-3.7-7-7.8-7-12 0-17.7 43-32 96-32s96 14.3 96 32c0 4.2-2.5 8.3-7 12 5.9 7.8 10.9 16.3 14.7 25.5 15.3-10.5 24.3-23.5 24.3-37.5 0-35.3-57.3-64-128-64S160 12.7 160 48zM329.8 237.9c13 9.7 22.6 24 26.4 40.8l43.2 194.4c4 18-8 35.2-25.4 38.4 3.3 .3 6.7 .5 10.1 .5l77.7 0c26.3 0 46.4-23.6 42-49.6l-9.3-55.5c-3.7-22.3 2.8-48 19.3-63.6 28.5-27 46.3-65.3 46.3-107.6l0-63.4c0-42.1-34.2-76.3-76.3-76.3-22.6 0-44.1 10.1-58.6 27.4L329.8 237.9z', 'M288 192a64 64 0 1 0 0-128 64 64 0 1 0 0 128zm0 32c-32.7 0-61 22.7-68.1 54.7L176.7 473.1c-4.4 20 10.8 38.9 31.2 38.9l160.2 0c20.5 0 35.7-19 31.2-38.9L356.1 278.7C349 246.7 320.7 224 288 224z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAngel = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;