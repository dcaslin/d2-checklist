'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'backward-fast';
var width = 512;
var height = 512;
var aliases = [9198,"fast-backward"];
var unicode = 'f049';
var svgPathData = ['M64 210.7l0 90.5 169.4 169.4c9.2 9.2 22.9 11.9 34.9 6.9S288 460.9 288 448l0-146.7 169.4 169.4c9.2 9.2 22.9 11.9 34.9 6.9S512 460.9 512 448l0-384c0-12.9-7.8-24.6-19.8-29.6s-25.7-2.2-34.9 6.9L288 210.7 288 64c0-12.9-7.8-24.6-19.8-29.6s-25.7-2.2-34.9 6.9L64 210.7z', 'M32 480c-17.7 0-32-14.3-32-32L0 64C0 46.3 14.3 32 32 32S64 46.3 64 64l0 384c0 17.7-14.3 32-32 32z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBackwardFast = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;