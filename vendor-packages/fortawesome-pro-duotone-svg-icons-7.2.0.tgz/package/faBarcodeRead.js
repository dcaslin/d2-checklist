'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'barcode-read';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f464';
var svgPathData = ['M96 160l0 192c0 17.7 14.3 32 32 32s32-14.3 32-32l0-192c0-17.7-14.3-32-32-32s-32 14.3-32 32zm96-16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16s-16 7.2-16 16zm80 8l0 208c0 13.3 10.7 24 24 24s24-10.7 24-24l0-208c0-13.3-10.7-24-24-24s-24 10.7-24 24zm80 8l0 192c0 17.7 14.3 32 32 32s32-14.3 32-32l0-192c0-17.7-14.3-32-32-32s-32 14.3-32 32z', 'M0 64C0 28.7 28.7 0 64 0l72 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L64 48c-8.8 0-16 7.2-16 16l0 72c0 13.3-10.7 24-24 24S0 149.3 0 136L0 64zM352 24c0-13.3 10.7-24 24-24l72 0c35.3 0 64 28.7 64 64l0 72c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-72c0-8.8-7.2-16-16-16l-72 0c-13.3 0-24-10.7-24-24zM24 352c13.3 0 24 10.7 24 24l0 72c0 8.8 7.2 16 16 16l72 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-72 0c-35.3 0-64-28.7-64-64l0-72c0-13.3 10.7-24 24-24zm464 0c13.3 0 24 10.7 24 24l0 72c0 35.3-28.7 64-64 64l-72 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l72 0c8.8 0 16-7.2 16-16l0-72c0-13.3 10.7-24 24-24z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarcodeRead = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;