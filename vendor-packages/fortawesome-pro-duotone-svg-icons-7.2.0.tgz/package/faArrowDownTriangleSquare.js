'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-down-triangle-square';
var width = 512;
var height = 512;
var aliases = ["sort-shapes-down"];
var unicode = 'f888';
var svgPathData = ['M276 207.5c5.6 10.2 16.4 16.5 28 16.5l160 0c11.6 0 22.3-6.3 28-16.5s5.3-22.6-.9-32.5l-80-128C405.3 37.7 395 32 384 32s-21.3 5.7-27.1 15l-80 128c-6.2 9.9-6.5 22.3-.9 32.5zM288 336l0 96c0 26.5 21.5 48 48 48l96 0c26.5 0 48-21.5 48-48l0-96c0-26.5-21.5-48-48-48l-96 0c-26.5 0-48 21.5-48 48z', 'M105.4 470.6c12.5 12.5 32.8 12.5 45.3 0l80-80c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L160 370.7 160 64c0-17.7-14.3-32-32-32S96 46.3 96 64l0 306.7-25.4-25.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l80 80z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownTriangleSquare = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;