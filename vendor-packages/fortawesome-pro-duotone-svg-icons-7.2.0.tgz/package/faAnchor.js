'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'anchor';
var width = 576;
var height = 512;
var aliases = [9875];
var unicode = 'f13d';
var svgPathData = ['M80 307.9l32-28 32.1 28c1.8 66.8 49.1 122.2 111.9 136.5l0-257.9c10 3.5 20.8 5.5 32 5.5s22-1.9 32-5.5l0 257.9c62.9-14.3 110.2-69.7 111.9-136.5l32.1-28 32 28C493.9 421 401.6 512 288 512S82.1 421 80 307.9z', 'M288 64a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm96 32a96 96 0 1 1 -192 0 96 96 0 1 1 192 0zM96.2 229.9c9-7.9 22.6-7.9 31.6 0l64 56c10 8.7 11 23.9 2.3 33.9s-23.9 11-33.9 2.3L112 279.9 63.8 322.1c-10 8.7-25.1 7.7-33.9-2.3s-7.7-25.1 2.3-33.9l64-56zm352 0c9-7.9 22.6-7.9 31.6 0l64 56c10 8.7 11 23.9 2.3 33.9s-23.9 11-33.9 2.3l-48.2-42.2-48.2 42.2c-10 8.7-25.1 7.7-33.9-2.3s-7.7-25.1 2.3-33.9l64-56z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAnchor = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;