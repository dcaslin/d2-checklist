'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'blanket-fire';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e3da';
var svgPathData = ['M96 120l0 240c0 2.7 0 5.3 .3 8 4.1 62.5 56.2 112 119.7 112l80.1 0c-7.9-15.1-14-31.2-18.1-48l-62 0c-39.8 0-72-32.2-72-72s32.2-72 72-72l83.1 0c3.9-7.5 8.1-14.7 12.4-21.7 22.6-36.6 53.8-73.8 90.2-106.4 23.9-21.3 60.1-21.2 83.9 .2 8.3 7.5 16.3 15.1 24.2 23.1 10.3-7.1 22.2-10.7 34.1-11l0-52.2c0-48.6-39.4-88-88-88L184 32c-48.6 0-88 39.4-88 88zm96 240c0 13.3 10.7 24 24 24l56 0c0-.6 0-1.3 0-1.9 0-15.3 2.7-30.8 7.2-46.1L216 336c-13.3 0-24 10.7-24 24z', 'M518 226.5l-12.3 13.8s-24.5-29.4-38.9-40.7c-5.4-4.3-11.5-7.3-18.8-7.5s-14.6 2.3-20.3 7.5c-23.4 21.1-50 48.9-70.9 80.2-20.8 31.1-36.8 67.1-36.8 104.5 0 88.6 70.4 159.8 160 159.8 88.7 0 160-71.2 160-159.8 0-30-11-60.9-26.2-88.1-15.2-27.4-35.3-52.3-55-70.6-5.6-5.2-12.8-7.8-19.9-7.8-7.6 0-15.5 2.8-20.9 8.9zM480 496.2c-35.3 0-64-28.7-64-64 0-36.5 37-73 54.8-88.4 5.4-4.7 13.1-4.7 18.5 0 17.7 15.4 54.8 51.9 54.8 88.4 0 35.3-28.7 64-64 64z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlanketFire = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;