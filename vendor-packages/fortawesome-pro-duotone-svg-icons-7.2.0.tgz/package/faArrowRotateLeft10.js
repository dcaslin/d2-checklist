'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-rotate-left-10';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e836';
var svgPathData = ['M0 32L0 192c0 14.3 9.5 26.9 23.2 30.8s28.4-1.7 36-13.9l32-51.4 .1-.2 .1-.2C125.1 101.2 186.2 64 256 64 362 64 448 150 448 256S362 448 256 448c-65.2 0-122.8-32.5-157.6-82.3-10.1-14.5-30.1-18-44.6-7.9s-18 30.1-7.9 44.6C92.1 468.6 169 512 256 512 397.4 512 512 397.4 512 256S397.4 0 256 0C179.5 0 110.9 33.6 64 86.7L64 32C64 14.3 49.7 0 32 0S0 14.3 0 32z', 'M173.3 162.5c7.4-3.7 16.3-3.3 23.3 1.1S208 175.7 208 184l0 144c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-105.4c-11.3 4-24-.9-29.5-11.8-5.9-11.9-1.1-26.3 10.8-32.2l32-16zM312 160c30.9 0 56 25.1 56 56l0 80c0 30.9-25.1 56-56 56l-16 0c-30.9 0-56-25.1-56-56l0-80c0-30.9 25.1-56 56-56l16 0zm-16 48c-4.4 0-8 3.6-8 8l0 80c0 4.4 3.6 8 8 8l16 0c4.4 0 8-3.6 8-8l0-80c0-4.4-3.6-8-8-8l-16 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateLeft10 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;