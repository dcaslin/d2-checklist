'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-rotate-left';
var width = 512;
var height = 512;
var aliases = [8634,"arrow-left-rotate","arrow-rotate-back","arrow-rotate-backward","undo"];
var unicode = 'f0e2';
var svgPathData = ['M45.9 402.3C54.4 414.5 64.1 426.2 75 437 175 537 337 537 437 437S537 175 437 75C387 25 321.5 0 256 0 179.5 0 110.9 33.6 64 86.7l0 41.3 48.9 0c35.2-39.3 86.3-64 143.1-64 49.2 0 98.3 18.7 135.8 56.2 75 75 75 196.5 0 271.5s-196.5 75-271.5 0c-8.2-8.2-15.5-16.9-21.9-26.1-10.1-14.5-30.1-18-44.6-7.9s-18 30.1-7.9 44.6z', 'M32 0C49.7 0 64 14.3 64 32l0 96 96 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 192c-17.7 0-32-14.3-32-32L0 32C0 14.3 14.3 0 32 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateLeft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;