'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'baseball-bat';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e7e5';
var svgPathData = ['M41 455l48 48c30.7-30.7 61.3-61.3 92-92 7.3-7.3 15.7-13.4 24.9-18l39.4-19.7c-24.9-24.9-49.8-49.8-74.7-74.7-6.6 13.1-13.1 26.3-19.7 39.4-4.6 9.2-10.7 17.7-18 25-30.7 30.7-61.3 61.3-92 92z', 'M338.1 327l-92.7 46.4-74.7-74.7 46.4-92.7c4.6-9.2 10.7-17.7 18-24.9L430.8-14.7c11.1-11.1 26.1-17.3 41.7-17.3 15.1 0 29.7 5.8 40.6 16.2l47.2 44.8c12.6 12 19.1 29 17.5 46.4-1.2 13.3-7 25.8-16.5 35.2L363.1 309c-7.3 7.3-15.7 13.4-25 18zM39.2 453.4l1.8 1.7 48 48 1.7 1.8c7.7 9.4 7.1 23.3-1.7 32.1s-22.7 9.3-32.1 1.7l-1.8-1.7-48-48-1.7-1.8c-7.7-9.4-7.1-23.3 1.7-32.1s22.7-9.3 32.1-1.7z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBaseballBat = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;