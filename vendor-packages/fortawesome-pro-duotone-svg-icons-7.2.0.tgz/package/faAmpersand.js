'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'ampersand';
var width = 384;
var height = 512;
var aliases = [];
var unicode = '26';
var svgPathData = ['M112 112.7c0 12.2 4.5 24.1 12.5 33l27.6 30.9 36.4-26.6c12.3-9 19.5-23.2 19.5-38.4 0-26.2-21.4-47.6-47.8-47.6-26.2 0-48.2 22-48.2 48.7zm114.3 88.9l-31.3 22.8 88.1 98.5 47.5-42.8c13.1-11.8 33.4-10.8 45.2 2.4s10.8 33.4-2.4 45.2l-47.7 42.9 50.1 56c11.8 13.2 10.7 33.4-2.5 45.2s-33.4 10.7-45.2-2.5l-50-55.8-17.2 15.5c-36.5 32.9-83.9 51-133 51-70.2 0-128-56.9-128-127.5 0-40.7 19.4-78.9 52.3-102.9l47.9-35-23.4-26.1C58.2 167.6 48 140.4 48 112.7 48 51.2 98.1 0 160.2 0 221.7 0 272 49.9 272 111.6 272 147.2 255 180.7 226.3 201.7zM128 416c33.3 0 65.4-12.3 90.2-34.6l17.3-15.6-92.4-103.3-53 38.7c-16.4 12-26 31-26 51.3 0 34.9 28.7 63.5 64 63.5z', ''];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAmpersand = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;