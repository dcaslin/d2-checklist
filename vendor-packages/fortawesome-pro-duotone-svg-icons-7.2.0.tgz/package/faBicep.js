'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bicep';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e862';
var svgPathData = ['M.1 384c0 70.7 57.3 128 128 128 .5 0 1.1 0 1.6-.1l330.2-22c29.4-2 52.2-26.4 52.2-55.8l.1-116.6c0-16.5-7.3-33.3-22-43.9-43.4-31.2-96.6-49.6-154.1-49.6-42.3 0-82.2 9.9-117.6 27.6l5.7 74.4c1 13.2-8.9 24.7-22.1 25.8-13.2 1-24.7-8.9-25.7-22.1-1.6-20.6-5.9-77.2-12.9-169.7l20.7 0c48.6 0 88-39.4 88-88l0-16c0-30.9-25.1-56-56-56L120.3 0C81.2 0 45.9 26.1 37.1 65.5 22.7 129.5 .1 250.9 .1 384zM160.1 119.2c-1-13.2 8.9-24.7 22.1-25.8s24.7 8.9 25.7 22.1l3 40.2c-8.5 2.7-17.6 4.3-27 4.3l-20.7 0s0 0 0 0c1.9 24.6 3.7 49.2 5.6 73.8-.1-.4-.2-.8-.2-1.2l-8.6-113.4z', 'M224.1 326c1 13.2-8.9 24.7-22.1 25.8-13.2 1-24.7-8.9-25.7-22.1l-3.7-48.9c14.2-11.2 29.6-21 45.9-29.2l5.7 74.4zM182.2 93.5c13.2-1 24.7 8.9 25.7 22.1l3 40.2c-8.5 2.7-17.6 4.3-27 4.3l-20.7 0 5.6 73.8c-.1-.4-.2-.8-.2-1.2l-8.6-113.4c-1-13.2 8.9-24.7 22.1-25.8z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBicep = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;