'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bolt-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0b8';
var svgPathData = ['M65.9 266.9C70.5 279.6 82.5 288 96 288l122.2 0-95.7-95.7-47 39.1c-10.4 8.6-14.2 22.8-9.6 35.5zm96.4 217.2c-5.4 13.6-.9 29.2 10.9 37.8s28 8.1 39.3-1.3l130-108.3-108.2-108.2-72 180z', 'M7-24.9c9.4-9.4 24.6-9.4 33.9 0L196.5 130.6 363.5-8.6c11.3-9.4 27.4-9.9 39.3-1.3s16.3 24.2 10.9 37.8L335.3 224 480 224c13.5 0 25.5 8.4 30.1 21.1s.7 26.9-9.6 35.5l-84 70 152.5 152.5c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0L7 9.1C-2.3-.3-2.3-15.5 7-24.9z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoltSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;