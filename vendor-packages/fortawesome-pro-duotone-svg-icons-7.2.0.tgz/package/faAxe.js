'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'axe';
var width = 640;
var height = 512;
var aliases = [129683];
var unicode = 'f6b2';
var svgPathData = ['M230.6 105.4c-12.5 12.5-12.5 32.8 0 45.3 37.3 37.3 143.1 143.1 153.4 153.4l0 88c0 13.3 10.7 24 24 24l8 0c123.7 0 224-100.3 224-224l0-8c0-13.3-10.7-24-24-24l-88 0c-33.7-33.7-74.4-74.4-121.9-121.9L374.6 6.6c-12.5-12.5-32.8-12.5-45.3 0l-98.7 98.7z', 'M473.9 105.9l-67.9-67.9 24-24c18.7-18.7 49.1-18.7 67.9 0s18.7 49.1 0 67.9l-24 24zM262.1 182.1l67.9 67.9-232 232c-18.7 18.7-49.1 18.7-67.9 0s-18.7-49.1 0-67.9l232-232z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAxe = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;