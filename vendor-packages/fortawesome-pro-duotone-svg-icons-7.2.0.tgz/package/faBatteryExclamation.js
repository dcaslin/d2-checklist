'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'battery-exclamation';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e0b0';
var svgPathData = ['M32 144l0 224c0 44.2 35.8 80 80 80l134.7 0c-4.3-9.8-6.7-20.6-6.7-32s2.4-22.2 6.7-32L112 384c-8.8 0-16-7.2-16-16l0-224c0-8.8 7.2-16 16-16l129.4 0-1.1-29.4c-.4-12.3 2-24 6.6-34.6L112 64c-44.2 0-80 35.8-80 80zM393.1 64c4.6 10.6 7 22.2 6.6 34.5-.4 9.8-.7 19.7-1.1 29.5L528 128c8.8 0 16 7.2 16 16l0 224c0 8.8-7.2 16-16 16l-134.7 0c4.3 9.8 6.7 20.6 6.7 32s-2.4 22.2-6.7 32L528 448c44.2 0 80-35.8 80-80l0-48c17.7 0 32-14.3 32-32l0-64c0-17.7-14.3-32-32-32l0-48c0-44.2-35.8-80-80-80L393.1 64z', 'M320 448a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm0-384c18 0 32.3 14.9 31.7 32.8l-7.7 216c-.5 12.9-11.1 23.1-24 23.2s-23.5-10.2-24-23.2l-7.7-216C287.7 78.9 302.1 64 320 64z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBatteryExclamation = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;