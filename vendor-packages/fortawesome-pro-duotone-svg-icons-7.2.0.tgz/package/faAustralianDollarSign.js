'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'australian-dollar-sign';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6fe';
var svgPathData = ['M288 175.1c0 53 37.4 98.6 89.3 109l32.8 6.6c22 4.4 37.9 23.8 37.9 46.2 0 26-21.1 47.1-47.1 47.1L336 384c-17.7 0-32 14.3-32 32s14.3 32 32 32l48 0 0 24c0 13.3 10.7 24 24 24s24-10.7 24-24l0-28.4c46.2-13.5 80-56.1 80-106.7 0-53-37.4-98.6-89.3-109l-32.8-6.6c-22-4.4-37.9-23.7-37.9-46.2 0-26 21.1-47.1 47.1-47.1l48.9 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-16 0 0-24c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 25c-54.2 7.4-96 53.9-96 110.1z', 'M160.5 320l-65 0 32.5-135.9 32.5 135.9zm15.3 64l17.1 71.4c4.1 17.2 21.4 27.8 38.6 23.7s27.8-21.4 23.7-38.6L169 80.3c-4.5-19-21.5-32.3-41-32.3S91.6 61.4 87 80.3L.9 440.6c-4.1 17.2 6.5 34.5 23.7 38.6s34.5-6.5 38.6-23.7l17.1-71.4 95.6 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAustralianDollarSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;