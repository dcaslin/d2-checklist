'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'bag-seedling';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e5f2';
var svgPathData = ['M0 247.2l0 17.7C0 301.5 4.5 338 13.4 373.5l18.6 74.5 384 0 18.6-74.5c8.9-35.5 13.4-72 13.4-108.7l0-17.7c0-36.6-4.5-73.1-13.4-108.7L416 64 32 64 13.4 138.5C4.5 174 0 210.5 0 247.2zM96 176c0-8.8 7.2-16 16-16l2 0c47.3 0 88.4 26 110 64.5 21.6-38.5 62.7-64.5 110-64.5l2 0c8.8 0 16 7.2 16 16 0 59.2-45.9 107.6-104 111.7l0 40.3c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-40.3C141.9 283.6 96 235.2 96 176z', 'M6.6 38.6L32 64 416 64 441.4 38.6c4.2-4.2 6.6-10 6.6-16 0-12.5-10.1-22.6-22.6-22.6L22.6 0C10.1 0 0 10.1 0 22.6 0 28.6 2.4 34.4 6.6 38.6zm0 434.7c-4.2 4.2-6.6 10-6.6 16 0 12.5 10.1 22.6 22.6 22.6l402.7 0c12.5 0 22.6-10.1 22.6-22.6 0-6-2.4-11.8-6.6-16L416 448 32 448 6.6 473.4zM112 160c-8.8 0-16 7.2-16 16 0 59.2 45.9 107.6 104 111.7l0 40.3c0 13.3 10.7 24 24 24s24-10.7 24-24l0-40.3c58.1-4.1 104-52.6 104-111.7 0-8.8-7.2-16-16-16l-2 0c-47.3 0-88.4 26-110 64.5-21.6-38.5-62.7-64.5-110-64.5l-2 0z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBagSeedling = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;