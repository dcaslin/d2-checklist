'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'alicorn';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f6b0';
var svgPathData = ['M0 256l0 56c0 13.3 10.7 24 24 24s24-10.7 24-24l0-56c0-13.4 6.6-25.2 16.7-32.5-.4-3.5-.7-7.1-.7-10.7 0-16.1 4.5-31.2 12.3-44.1-43.1 5.7-76.3 42.6-76.3 87.2zM551.4 48c5.4 9.4 8.6 20.3 8.6 32l0 10.7 73.6-24.5c3.8-1.3 6.4-4.8 6.4-8.8 0-5.1-4.2-9.3-9.3-9.3l-79.3 0z', 'M448 238.1l0-78.1 9.8 19.6c12.5 25.1 42.2 36.4 68.3 26 20.5-8.2 33.9-28 33.9-50.1L560 80c0-19.1-8.4-36.3-21.7-48l5.7 0c8.8 0 16-7.2 16-16S552.8 0 544 0L448 0C378.4 0 321.7 55.6 320 124.8L184.9 34.7c-4.9-3.3-11.2-3.6-16.4-.8S160 42.1 160 48c0 48.1 3.8 99.9 26 139.8 9.2 16.6 21.7 31.3 38.2 42.7-7.2-2.5-14-5.4-20.3-8.8-22.5-12.1-38.6-29.4-49.9-49.8-7.3-13.2-12.7-27.8-16.5-43-41.5 5.6-73.5 41.1-73.5 84.1 0 16.8 5 33.1 14.2 47.1l28.2 42.4c8.3 12.4 6.4 28.7-1.2 41.6-16.5 28-20.6 62.2-10 93.9l17.5 52.4c4.4 13.1 16.6 21.9 30.4 21.9l33.7 0c21.8 0 37.3-21.4 30.4-42.1l-20.8-62.5c-2.1-6.4-.5-13.4 4.3-18.2l12.7-12.7c13.2-13.2 20.6-31.1 20.6-49.7 0-2.3-.1-4.6-.3-6.9l84 24c4.1 1.2 8.2 2.1 12.3 2.8L320 480c0 17.7 14.3 32 32 32l32 0c17.7 0 32-14.3 32-32l0-164.3c19.2-19.2 31.5-45.7 32-75.7l0 0 0-1.9zM496 64a16 16 0 1 1 0 32 16 16 0 1 1 0-32z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlicorn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;