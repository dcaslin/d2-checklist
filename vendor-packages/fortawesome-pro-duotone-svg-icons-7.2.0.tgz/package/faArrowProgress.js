'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'arrow-progress';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e5df';
var svgPathData = ['M32 416c0 35.3 28.7 64 64 64 23.7 0 44.4-12.9 55.4-32l32.6 0 0 8c0 9.7 5.8 18.5 14.8 22.2s19.3 1.7 26.2-5.2l40-40c9.4-9.4 9.4-24.6 0-33.9l-40-40c-6.9-6.9-17.2-8.9-26.2-5.2S184 366.3 184 376l0 8-32.6 0c-11.1-19.1-31.7-32-55.4-32-35.3 0-64 28.7-64 64zM352 96a64 64 0 1 0 128 0 64 64 0 1 0 -128 0z', 'M257 39c-6.9-6.9-17.2-8.9-26.2-5.2S216 46.3 216 56l0 8-104 0C50.1 64 0 114.1 0 176S50.1 288 112 288l288 0c26.5 0 48 21.5 48 48 0 14.7-6.6 27.8-17 36.6-11.7-12.7-28.4-20.6-47-20.6-35.3 0-64 28.7-64 64s28.7 64 64 64c27.2 0 50.4-16.9 59.7-40.8 40.2-17 68.3-56.8 68.3-103.2 0-61.9-50.1-112-112-112l-288 0c-26.5 0-48-21.5-48-48s21.5-48 48-48l104 0 0 8c0 9.7 5.8 18.5 14.8 22.2s19.3 1.7 26.2-5.2l40-40c9.4-9.4 9.4-24.6 0-33.9L257 39z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowProgress = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;