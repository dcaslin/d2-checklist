'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fad';
var iconName = 'anchor-lock';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4ad';
var svgPathData = ['M29.9 319.8c8.7 10 23.9 11 33.9 2.3L80 307.9c2.1 113.1 94.4 204.1 208 204.1 28.3 0 55.4-5.7 80-15.9 0-24.2 0-48.3 0-72.3-14.4 9.6-30.6 16.7-48 20.7l0-257.9c37.3-13.2 64-48.7 64-90.5 0-53-43-96-96-96s-96 43-96 96c0 41.8 26.7 77.4 64 90.5l0 257.9c-62.9-14.3-110.2-69.7-111.9-136.5l16.1 14.1c10 8.7 25.1 7.7 33.9-2.3s7.7-25.1-2.3-33.9l-64-56c-9-7.9-22.6-7.9-31.6 0l-64 56c-10 8.7-11 23.9-2.3 33.9zM320 96a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z', 'M496 352l0-47.9c0-17.7 14.3-32 32-32s32 14.3 32 32l0 47.9-64 0zm-48 2.7c-18.6 6.6-32 24.4-32 45.3l0 96c0 26.5 21.5 48 48 48l128 0c26.5 0 48-21.5 48-48l0-96c0-20.9-13.4-38.7-32-45.3l0-50.6c0-44.2-35.8-80-80-80s-80 35.8-80 80l0 50.6z'];

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAnchorLock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;