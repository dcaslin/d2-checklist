'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-atlas';
var width = 448;
var height = 512;
var aliases = ["atlas"];
var unicode = 'f558';
var svgPathData = 'M0 64C0 28.7 28.7 0 64 0L400 0c26.5 0 48 21.5 48 48l0 320c0 20.9-13.4 38.7-32 45.3l0 66.7 16 0c8.8 0 16 7.2 16 16s-7.2 16-16 16L64 512c-35.3 0-64-28.7-64-64l0 0 0-384zM64 416c-17.7 0-32 14.3-32 32s14.3 32 32 32l320 0 0-64-320 0zM32 392.6c9.4-5.4 20.3-8.6 32-8.6l336 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 32C46.3 32 32 46.3 32 64l0 328.6zM318.7 224L279 224c-1.8 28.6-8.3 54-17.7 72.5 29.8-12.6 51.9-39.7 57.4-72.5zm-189.3 0c5.5 32.8 27.6 59.9 57.4 72.5-9.5-18.5-15.9-43.9-17.7-72.5l-39.7 0zm84.5 55c4.5 9.7 8.2 13.8 10.2 15.5 2-1.7 5.7-5.8 10.2-15.5 6.2-13.4 11.1-32.5 12.7-55l-45.8 0c1.6 22.5 6.5 41.6 12.7 55zm-12.7-87l45.8 0c-1.6-22.5-6.5-41.6-12.7-55-4.5-9.6-8.2-13.8-10.2-15.5-2 1.7-5.7 5.8-10.2 15.5-6.2 13.4-11.1 32.5-12.7 55zm117.6 0c-5.5-32.8-27.6-59.9-57.4-72.5 9.5 18.5 15.9 43.9 17.7 72.5l39.7 0zM169 192c1.8-28.6 8.3-54 17.7-72.5-29.8 12.6-51.9 39.7-57.4 72.5l39.7 0zM96 208a128 128 0 1 1 256 0 128 128 0 1 1 -256 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookAtlas = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;