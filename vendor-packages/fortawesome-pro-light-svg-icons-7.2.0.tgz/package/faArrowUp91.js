'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-up-9-1';
var width = 512;
var height = 512;
var aliases = ["sort-numeric-up-alt"];
var unicode = 'f887';
var svgPathData = 'M139.3 36.7c-6.2-6.2-16.4-6.2-22.6 0l-112 112c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L112 86.6 112 464c0 8.8 7.2 16 16 16s16-7.2 16-16l0-377.4 84.7 84.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6l-112-112zM352 112a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm53.9 79.8l-27.1 39.1c-5 7.3-3.2 17.2 4 22.3s17.2 3.2 22.3-4l58.3-84.3c10.7-15.5 16.5-34 16.5-52.8 0-44.2-35.8-80-80-80s-80 35.8-80 80 35.8 80 80 80c2 0 4-.1 5.9-.2zm3.7 99.4c-4-3-9.2-4-14-2.6l-56 16c-8.5 2.4-13.4 11.3-11 19.8s11.3 13.4 19.8 11l35.6-10.2 0 122.8-40 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l112 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-40 0 0-144c0-5-2.4-9.8-6.4-12.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUp91 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;