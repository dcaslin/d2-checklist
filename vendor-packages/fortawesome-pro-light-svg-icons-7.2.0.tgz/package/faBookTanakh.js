'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-tanakh';
var width = 448;
var height = 512;
var aliases = ["tanakh"];
var unicode = 'f827';
var svgPathData = 'M448 64c0-35.3-28.7-64-64-64L48 0C21.5 0 0 21.5 0 48L0 368c0 20.9 13.4 38.7 32 45.3l0 66.7-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l368 0c35.3 0 64-28.7 64-64l0 0 0-384zM384 416c17.7 0 32 14.3 32 32s-14.3 32-32 32l-320 0 0-64 320 0zm32-23.4c-9.4-5.4-20.3-8.6-32-8.6L48 384c-8.8 0-16-7.2-16-16L32 48c0-8.8 7.2-16 16-16l336 0c17.7 0 32 14.3 32 32l0 328.6zM237.5 95.5c-2.9-4.6-8-7.5-13.5-7.5s-10.6 2.8-13.5 7.5L179.8 144 128 144c-5.8 0-11.2 3.2-14 8.3s-2.6 11.3 .5 16.3l24.9 39.5-24.9 39.5c-3.1 4.9-3.3 11.2-.5 16.3s8.2 8.3 14 8.3l51.8 0 30.7 48.5c2.9 4.6 8 7.5 13.5 7.5s10.6-2.8 13.5-7.5l30.7-48.5 51.8 0c5.8 0 11.2-3.2 14-8.3s2.6-11.3-.5-16.3l-24.9-39.5 24.9-39.5c3.1-4.9 3.3-11.2 .5-16.3s-8.2-8.3-14-8.3l-51.8 0-30.7-48.5zm-35.4 73.1L224 134 245.8 168.5c2.9 4.6 8 7.5 13.5 7.5l31.6 0-14.8 23.5c-3.3 5.2-3.3 11.9 0 17.1l14.8 23.5-31.6 0c-5.5 0-10.6 2.8-13.5 7.5L224 282 202.2 247.5c-2.9-4.6-8-7.5-13.5-7.5l-31.6 0 14.8-23.5c3.3-5.2 3.3-11.9 0-17.1L157 176 188.6 176c5.5 0 10.6-2.8 13.5-7.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookTanakh = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;