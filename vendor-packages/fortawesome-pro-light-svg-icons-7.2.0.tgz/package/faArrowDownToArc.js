'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-down-to-arc';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e4ae';
var svgPathData = 'M256 480c-123.7 0-224-100.3-224-224 0-8.8-7.2-16-16-16S0 247.2 0 256C0 397.4 114.6 512 256 512S512 397.4 512 256c0-8.8-7.2-16-16-16s-16 7.2-16 16c0 123.7-100.3 224-224 224zM132.7 235.3l112 112c6.2 6.2 16.4 6.2 22.6 0l112-112c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L272 297.4 272 16c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 281.4-84.7-84.7c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownToArc = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;