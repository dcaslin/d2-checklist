'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'battery-exclamation';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e0b0';
var svgPathData = 'M236.3 64c-2.9 8.1-4.3 16.9-4.1 26l.2 6-120.5 0c-26.5 0-48 21.5-48 48l0 224c0 26.5 21.5 48 48 48l120.5 0c-.3 2.6-.5 5.3-.5 8 0 8.4 1.5 16.5 4.2 24L112 448c-44.2 0-80-35.8-80-80l0-224c0-44.2 35.8-80 80-80l124.3 0zM304 448a24 24 0 1 1 0-48 24 24 0 1 1 0 48zM496 64c44.2 0 80 35.8 80 80l0 32 32 0c17.7 0 32 14.3 32 32l0 96c0 17.7-14.3 32-32 32l-32 0 0 32c0 44.2-35.8 80-80 80l-124.2 0c2.7-7.5 4.2-15.6 4.2-24 0-2.7-.2-5.4-.5-8L496 416c26.5 0 48-21.5 48-48l0-224c0-26.5-21.5-48-48-48l-120.5 0 .2-6c.3-9.1-1.2-17.9-4.1-26L496 64zM304 64c13.4 0 24.2 11.1 23.8 24.5l-7.8 248c-.3 8.6-7.4 15.5-16 15.5s-15.7-6.9-16-15.5l-7.8-248C279.8 75.1 290.6 64 304 64zM576 304l32 0 0-96-32 0 0 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBatteryExclamation = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;