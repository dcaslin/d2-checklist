'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'ball-yarn';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6ce';
var svgPathData = 'M32.6 272l446.9 0c-1.6 22.4-6.5 43.9-14.1 64L46.7 336c-7.7-20.1-12.6-41.6-14.1-64zM161.8 459.3l24.5-91.3 83.2 0-29.6 111.4c-27.7-2-54-9-78-20.1zM133 443.2c-29.1-19.2-53.5-45-71-75.2l91.2 0-20.2 75.2zM450 368C414 430.3 348.7 473.7 273 479.4L302.6 368 450 368zM380 480C458.7 436.3 512 352.4 512 256 512 114.6 397.4 0 256 0S0 114.6 0 256 114.6 512 256 512l240 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-116 0zm99.4-240L32.6 240c1.6-22.4 6.5-43.9 14.1-64l418.6 0c7.7 20.1 12.6 41.6 14.1 64zM243.4 32.3L213.2 144 62 144C98.7 80.4 165.8 36.6 243.4 32.3zm33 .6c27.4 2.5 53.4 9.9 77.1 21.4l-24 89.7-83.1 0 30.1-111.1zM450 144l-87.4 0 19.6-73.1c27.7 18.9 51 43.9 67.8 73.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBallYarn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;