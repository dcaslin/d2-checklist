'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'anchor-circle-xmark';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4ac';
var svgPathData = 'M288.5 32a48 48 0 1 0 0 96 48 48 0 1 0 0-96zm-80 48c0-44.2 35.8-80 80-80s80 35.8 80 80c0 38.7-27.5 71-64 78.4l0 304.8c4.5-.4 8.9-1.1 13.2-1.9 3.5 10.4 7.9 20.5 13.1 30-13.6 3.1-27.7 4.7-42.3 4.7-106 0-192-86-192-192l0-28.7-37.5 32.8c-6.7 5.8-16.8 5.1-22.6-1.5S31.3 289.8 38 284l64-56c6-5.3 15-5.3 21.1 0l64 56c6.7 5.8 7.3 15.9 1.5 22.6s-15.9 7.3-22.6 1.5l-37.5-32.8 0 28.7c0 83 63.1 151.2 144 159.2l0-304.8c-36.5-7.4-64-39.7-64-78.4zm400 320a112 112 0 1 0 -224 0 112 112 0 1 0 224 0zm-256 0a144 144 0 1 1 288 0 144 144 0 1 1 -288 0zm203.3-36.7l-36.7 36.7 36.7 36.7c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0l-36.7-36.7-36.7 36.7c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l36.7-36.7-36.7-36.7c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l36.7 36.7 36.7-36.7c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAnchorCircleXmark = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;