'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-medical';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f7e6';
var svgPathData = 'M0 64C0 28.7 28.7 0 64 0L400 0c26.5 0 48 21.5 48 48l0 320c0 20.9-13.4 38.7-32 45.3l0 66.7 16 0c8.8 0 16 7.2 16 16s-7.2 16-16 16L64 512c-35.3 0-64-28.7-64-64l0 0 0-384zM64 416c-17.7 0-32 14.3-32 32s14.3 32 32 32l320 0 0-64-320 0zM32 392.6c9.4-5.4 20.3-8.6 32-8.6l336 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 32C46.3 32 32 46.3 32 64l0 328.6zM208 112l32 0c17.7 0 32 14.3 32 32l0 16 16 0c17.7 0 32 14.3 32 32l0 32c0 17.7-14.3 32-32 32l-16 0 0 16c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-16-16 0c-17.7 0-32-14.3-32-32l0-32c0-17.7 14.3-32 32-32l16 0 0-16c0-17.7 14.3-32 32-32zm32 136l0-16c0-4.4 3.6-8 8-8l40 0 0-32-40 0c-4.4 0-8-3.6-8-8l0-40-32 0 0 40c0 4.4-3.6 8-8 8l-40 0 0 32 40 0c4.4 0 8 3.6 8 8l0 40 32 0 0-24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookMedical = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;