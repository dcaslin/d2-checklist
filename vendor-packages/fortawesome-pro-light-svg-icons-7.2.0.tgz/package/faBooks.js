'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'books';
var width = 576;
var height = 512;
var aliases = [128218];
var unicode = 'f5db';
var svgPathData = 'M400.9 28.4L339.1 45c-8.5 2.3-13.6 11.1-11.3 19.6l12.4 46.4 92.7-24.8-12.4-46.4c-2.3-8.5-11.1-13.6-19.6-11.3zm13.8 360.7l92.7-24.8-66.3-247.3-92.7 24.8 66.3 247.3zM423 420l12.4 46.4c2.3 8.5 11.1 13.6 19.6 11.3l61.8-16.6c8.5-2.3 13.6-11.1 11.3-19.6L515.7 395.2 423 420zm123.6-33.1l12.4 46.4c6.9 25.6-8.3 51.9-33.9 58.8l-61.8 16.6c-25.6 6.9-51.9-8.3-58.8-33.9l-84.4-315.1 0 304.4c0 26.5-21.5 48-48 48l-64 0c-12.3 0-23.5-4.6-32-12.2-8.5 7.6-19.7 12.2-32 12.2l-64 0c-26.5 0-48-21.5-48-48l0-416c0-26.5 21.5-48 48-48l64 0c26.5 0 48 21.5 48 48l0 50.7c5-1.8 10.4-2.7 16-2.7l64 0c13.8 0 26.3 5.8 35 15.2L296.9 72.9c-6.9-25.6 8.3-51.9 33.9-58.8L392.6-2.5c25.6-6.9 51.9 8.3 58.8 33.9 10.3 38.6 33.1 123.7 87 324.6l8.3 30.9zM192.1 144l0 320c0 8.8 7.2 16 16 16l64 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16l-64 0c-8.8 0-16 7.2-16 16zm-32 320l0-48-96 0 0 48c0 8.8 7.2 16 16 16l64 0c8.8 0 16-7.2 16-16zm0-80l0-256-96 0 0 256 96 0zM80.1 32c-8.8 0-16 7.2-16 16l0 48 96 0 0-48c0-8.8-7.2-16-16-16l-64 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBooks = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;