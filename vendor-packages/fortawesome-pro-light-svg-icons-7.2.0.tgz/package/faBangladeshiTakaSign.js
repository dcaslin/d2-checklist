'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bangladeshi-taka-sign';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e2e6';
var svgPathData = 'M50 32.1C41.2 31 33.2 37.2 32.1 46S37.2 62.8 46 63.9l7.9 1c24 3 42 23.4 42 47.6l0 79.5-48 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l48 0 0 176c0 44.2 35.8 80 80 80l32 0c97.2 0 176-78.8 176-176l0-32c0-44.2-35.8-80-80-80l-32 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c26.5 0 48 21.5 48 48l0 32c0 79.5-64.5 144-144 144l-32 0c-26.5 0-48-21.5-48-48l0-176 48 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-48 0 0-79.5c0-40.3-30-74.4-70.1-79.4l-7.9-1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBangladeshiTakaSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;