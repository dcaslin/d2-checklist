'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'basketball-hoop';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f435';
var svgPathData = 'M448 240c8.8 0 16 7.2 16 16s-7.2 16-16 16l-.1 0-.1 2.2-32 224c-.9 6.3-5.5 11.6-11.7 13.2s-12.8-.6-16.8-5.6l-42.2-53.6-45 54c-3 3.6-7.5 5.8-12.3 5.8-3.6 0-7-1.2-9.8-3.3l-2.5-2.4-45-54-42.1 53.6c-4 5-10.6 7.3-16.7 5.6-5.4-1.5-9.6-5.6-11.2-10.9l-.5-2.3-32-224-.1-2.2-.1 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l320 0zM250.9 426.5l37.1 44.5 37.1-44.5-37.1-47.2-37.1 47.2zm-64.4 30.1l23.2-29.6-33.1-39.8 9.9 69.3zm179.7-29.6l23.2 29.6 9.9-69.3-33.1 39.8zm-178.1-76l41.9 50.2 37.7-47.9-42.9-54.6-36.6 52.3zm120.2 2.3l37.7 47.9 41.9-50.2-36.6-52.3-42.9 54.6zM288 0c174.5 0 258.9 123.9 281.6 163.8 4.5 7.9 6.4 17 6.4 26.1l0 120.5-.2 4.7c-1.7 23.4-16.1 44.2-37.8 53.8l-58.9 26.2 5.3-37.4 40.6-18 4.1-2.2c9.2-5.8 14.9-16 14.9-27l0-120.5c0-3.6-.6-6.3-1.4-8.4l-.9-1.9C521 143.1 445 32 288 32 140.8 32 64.8 129.6 38.8 171.9l-4.5 7.7c-1.3 2.2-2.2 5.5-2.2 10.3l0 120.5c0 12.6 7.4 24.1 19 29.3l40.6 18 5.3 37.4-58.9-26.2C16.3 359.3 1.9 338.5 .2 315.1L0 310.4 0 189.9c0-8 1.5-15.9 4.8-23.1l1.6-3C29.1 123.9 113.5 0 288 0zm0 327.5l43.7-55.5-87.3 0 43.7 55.5zm-120.3-3l36.8-52.6-44.3 0 7.5 52.6zm240.7 0l7.5-52.6-44.3 0 36.8 52.6zM368 128c26.5 0 48 21.5 48 48l0 16-32 0 0-16c0-8.8-7.2-16-16-16l-160 0c-8.8 0-16 7.2-16 16l0 16-32 0 0-16c0-26.5 21.5-48 48-48l160 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBasketballHoop = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;