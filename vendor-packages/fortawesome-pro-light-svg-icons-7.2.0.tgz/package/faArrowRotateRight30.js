'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-rotate-right-30';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e889';
var svgPathData = 'M496 0c8.8 0 16 7.2 16 16l0 144c0 6.6-4 12.5-10.1 14.9s-13 .9-17.5-3.9l-64.6-68.4C377.2 57.5 318 32 256 32 132.3 32 32 132.3 32 256S132.3 480 256 480c85.9 0 160.6-48.4 198.2-119.5 4.1-7.8 13.8-10.8 21.6-6.7 7.8 4.1 10.8 13.8 6.7 21.6-42.9 81.2-128.2 136.5-226.5 136.5-141.4 0-256-114.6-256-256S114.6 0 256 0c70.8 0 138.4 29.2 187 80.6l37 39.1 0-103.8c0-8.8 7.2-16 16-16zM176 160c30.9 0 56 25.1 56 56 0 15.7-6.5 29.8-16.9 40 10.4 10.2 16.9 24.3 16.9 40 0 30.9-25.1 56-56 56l-40 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l40 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-32 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l32 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-40 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l40 0zm160 0c30.9 0 56 25.1 56 56l0 80c0 30.9-25.1 56-56 56l-16 0c-30.9 0-56-25.1-56-56l0-80c0-30.9 25.1-56 56-56l16 0zm-16 32c-13.3 0-24 10.7-24 24l0 80c0 13.3 10.7 24 24 24l16 0c13.3 0 24-10.7 24-24l0-80c0-13.3-10.7-24-24-24l-16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateRight30 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;