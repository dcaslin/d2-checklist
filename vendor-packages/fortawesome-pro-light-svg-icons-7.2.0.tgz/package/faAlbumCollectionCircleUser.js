'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'album-collection-circle-user';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e48f';
var svgPathData = 'M128.5 16c0 8.8 7.2 16 16 16l224 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-224 0c-8.8 0-16 7.2-16 16zm-48 80c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-320 0c-8.8 0-16 7.2-16 16zm-28 101.4c3-3.4 7.4-5.4 12-5.4l384 0c4.6 0 9 2 12 5.4l0 0c3 3.4 4.5 8 3.9 12.6l-.1 .6c10.7 1.8 21.2 4.5 31.3 8l.6-4.6c1.7-13.7-2.5-27.4-11.6-37.7s-22.2-16.2-36-16.2l-384 0c-13.8 0-26.9 5.9-36 16.2S15.2 200.3 16.9 214l32 256c3 24 23.4 42 47.6 42l180 0c-7.2-10-13.4-20.7-18.6-32L96.5 480c-8.1 0-14.9-6-15.9-14l-32-256c-.6-4.6 .8-9.1 3.9-12.6zm204 26.6c-75.7 0-137.1 50.1-137.1 112 0 59.1 56.1 107.5 127.1 111.7-2.7-10.5-4.5-21.4-5.4-32.5-55.4-6-89.7-43.9-89.7-79.2 0-38.4 40.7-80 105.1-80 15.4 0 29.5 2.4 42 6.5 8.7-8.4 18.1-16.1 28.2-22.8-20.5-10-44.5-15.8-70.2-15.8zm0 88c-16.2 0-29.4 10.7-29.4 24 0 9.9 7.4 18.5 18 22.1 3.6-16.1 9.2-31.5 16.5-45.8-1.7-.2-3.4-.4-5.1-.4zm116 182.6c7.8-9.1 19.4-14.6 31.8-14.6l56.4 0c12.4 0 23.9 5.5 31.8 14.6-17.3 11-37.9 17.4-60 17.4s-42.7-6.4-60-17.4zm144.3-20.8c-13.8-16.1-34.2-25.8-56.1-25.8l-56.4 0c-21.8 0-42.2 9.6-56.1 25.8-17.3-19.7-27.7-45.5-27.7-73.8 0-61.9 50.1-112 112-112s112 50.1 112 112c0 28.2-10.5 54.1-27.7 73.8zM576.5 400a144 144 0 1 0 -288 0 144 144 0 1 0 288 0zm-144-48a24 24 0 1 1 0 48 24 24 0 1 1 0-48zm0 80a56 56 0 1 0 0-112 56 56 0 1 0 0 112z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlbumCollectionCircleUser = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;