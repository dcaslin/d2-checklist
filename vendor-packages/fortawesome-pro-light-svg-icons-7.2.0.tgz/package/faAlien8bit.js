'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'alien-8bit';
var width = 576;
var height = 512;
var aliases = [128126,"alien-monster"];
var unicode = 'f8f6';
var svgPathData = 'M128 32c-17.7 0-32 14.3-32 32l0 32c0 17.7 14.3 32 32 32l32 0 0 32-64 0 0-16c0-17.7-14.3-32-32-32l-32 0c-17.7 0-32 14.3-32 32L0 288c0 17.7 14.3 32 32 32l32 0 0 32c0 17.7 14.3 32 32 32l32 0 0 64c0 17.7 14.3 32 32 32l80 0c17.7 0 32-14.3 32-32l0-32c0-17.7-14.3-32-32-32l96 0c-17.7 0-32 14.3-32 32l0 32c0 17.7 14.3 32 32 32l80 0c17.7 0 32-14.3 32-32l0-64 32 0c17.7 0 32-14.3 32-32l0-32 32 0c17.7 0 32-14.3 32-32l0-144c0-17.7-14.3-32-32-32l-32 0c-17.7 0-32 14.3-32 32l0 16-64 0 0-32 32 0c17.7 0 32-14.3 32-32l0-32c0-17.7-14.3-32-32-32l-32 0c-17.7 0-32 14.3-32 32l-32 0c-17.7 0-32 14.3-32 32l0 32-64 0 0-32c0-17.7-14.3-32-32-32l-32 0c0-17.7-14.3-32-32-32l-32 0zM480 192l0 48c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96 32 0 0 144-48 0c-8.8 0-16 7.2-16 16l0 48-384 0 0-48c0-8.8-7.2-16-16-16l-48 0 0-144 32 0 0 96c0 8.8 7.2 16 16 16s16-7.2 16-16l0-48 80 0c8.8 0 16-7.2 16-16l0-80 32 0 0 48c0 8.8 7.2 16 16 16l96 0c8.8 0 16-7.2 16-16l0-48 32 0 0 80c0 8.8 7.2 16 16 16l80 0zM128 96l0-32 32 0 0 32-32 0zm320 0l-32 0 0-32 32 0 0 32zM160 448l0-64 32 0 0 16c0 8.8 7.2 16 16 16l32 0 0 32-80 0zm224-48l0-16 32 0 0 64-80 0 0-32 32 0c8.8 0 16-7.2 16-16zM224 240c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 64c0 8.8 7.2 16 16 16s16-7.2 16-16l0-64zm160 0c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 64c0 8.8 7.2 16 16 16s16-7.2 16-16l0-64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlien8bit = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;