'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'ampersand';
var width = 384;
var height = 512;
var aliases = [];
var unicode = '26';
var svgPathData = 'M80 112.5c0 21.1 8.2 41.5 22.9 56.5l38.3 39.3 50.3-21.8c29.4-12.8 48.5-42 48.5-74.2 0-44.3-35.9-80.4-80-80.4-44.1 0-80 36.2-80 80.5zM204.2 215.9l-39.1 16.9 121.4 124.6 54.8-49.3c6.6-5.9 16.7-5.4 22.6 1.2s5.4 16.7-1.2 22.6l-53.9 48.5 70.6 72.5c6.2 6.3 6 16.5-.3 22.6s-16.5 6-22.6-.3l-71.5-73.4-34.8 31.3C216.7 463.3 173.2 480 128 480 58 480 0 423.3 0 352.9 0 302.3 30.1 256.5 76.5 236.3l33.2-14.4-29.8-30.6C59.4 170.3 48 141.8 48 112.5 48 50.7 98 0 160 0 221.9 0 272 50.6 272 112.4 272 157.2 245.4 198 204.2 215.9zM128 448c37.2 0 73.2-13.8 100.9-38.7l33.8-30.4-129-132.4-44.4 19.2C54.5 280.8 32 315 32 352.9 32 405.3 75.3 448 128 448z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAmpersand = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;