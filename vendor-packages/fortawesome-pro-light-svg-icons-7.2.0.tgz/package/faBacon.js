'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bacon';
var width = 576;
var height = 512;
var aliases = [129363];
var unicode = 'f7e5';
var svgPathData = 'M312.9 32.7c-44.2 30.2-80 71-104.3 118.7l-23.3 45.8c-21.1 41.5-52 77.2-90 104.1L36 343.2c-23.4 16.6-26.3 50.2-6 70.5L136.7 520.3c15.7 15.7 40.4 18 58.8 5.5l68.1-46.5c44.2-30.2 80-71 104.3-118.7l23.3-45.8c21.1-41.5 52-77.2 90-104.1l59.3-42c23.4-16.6 26.3-50.2 6-70.5L439.8-8.3c-15.7-15.7-40.4-18-58.8-5.5L312.9 32.7zM237.2 165.9C259 123 291.2 86.3 331 59.2l68.1-46.5c5.7-3.9 13.3-3.2 18.1 1.7l44 44-78.2 50.3c-49.1 31.6-89.2 75.4-116.2 127.2L242.7 282c-20.4 39.2-49.2 73.4-84.2 100.3l-64.8 49.8-41.1-41.1c-6.2-6.2-5.4-16.6 1.8-21.7l59.3-42c42.2-29.9 76.6-69.6 100-115.7l23.3-45.8zM116.6 455l61.5-47.3c38.7-29.8 70.4-67.6 93-110.9l24.1-46.2c24.4-46.9 60.7-86.5 105.1-115.1l84.1-54.1 39.4 39.4c6.2 6.2 5.4 16.6-1.8 21.7l-59.3 42c-42.3 29.9-76.6 69.6-100 115.7l-23.3 45.8c-21.8 42.9-54.1 79.6-93.8 106.7l-68.1 46.5c-5.7 3.9-13.3 3.2-18.1-1.7L116.6 455z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBacon = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;