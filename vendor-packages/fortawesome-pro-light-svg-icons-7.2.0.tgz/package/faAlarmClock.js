'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'alarm-clock';
var width = 512;
var height = 512;
var aliases = [9200];
var unicode = 'f34e';
var svgPathData = 'M386.8 39.6c-5.4 2.9-11.9 3.7-17.5 1.1l-.8-.4c-10.4-4.7-13.7-18.3-4.1-24.6 15-9.9 33-15.7 52.3-15.7 52.6 0 95.2 42.6 95.2 95.2 0 13.2-2.7 25.8-7.6 37.3-4.5 10.5-18.4 9.8-24.9 .4l-.5-.7c-3.5-5-4-11.5-2.1-17.4 2-6.2 3.1-12.7 3.1-19.6 0-34.9-28.3-63.2-63.2-63.2-10.9 0-21.1 2.7-30 7.6zM32.5 132.9c-6.5 9.4-20.5 10.1-24.9-.4-4.9-11.5-7.6-24.1-7.6-37.3 0-52.6 42.6-95.2 95.2-95.2 19.3 0 37.3 5.8 52.3 15.7 9.6 6.3 6.3 19.9-4.1 24.6l-.8 .4c-5.6 2.6-12.1 1.8-17.5-1.1-8.9-4.8-19.1-7.6-30-7.6-34.9 0-63.2 28.3-63.2 63.2 0 6.8 1.1 13.4 3.1 19.6 1.9 5.8 1.5 12.4-2.1 17.4l-.5 .7zM448 288a192 192 0 1 0 -384 0 192 192 0 1 0 384 0zM402.7 457.3C363.4 491.4 312.1 512 256 512s-107.4-20.6-146.7-54.7l-50 50c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l50-50C52.6 395.4 32 344.1 32 288 32 164.3 132.3 64 256 64S480 164.3 480 288c0 56.1-20.6 107.4-54.7 146.7l50 50c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0l-50-50zM272 176l0 120 57.6 43.2c7.1 5.3 8.5 15.3 3.2 22.4s-15.3 8.5-22.4 3.2l-64-48c-4-3-6.4-7.8-6.4-12.8l0-128c0-8.8 7.2-16 16-16s16 7.2 16 16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlarmClock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;