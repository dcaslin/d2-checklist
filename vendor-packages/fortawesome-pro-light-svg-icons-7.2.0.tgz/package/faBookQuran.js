'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-quran';
var width = 448;
var height = 512;
var aliases = ["quran"];
var unicode = 'f687';
var svgPathData = 'M384 0c35.3 0 64 28.7 64 64l0 384 0 0c0 35.3-28.7 64-64 64L16 512c-8.8 0-16-7.2-16-16s7.2-16 16-16l16 0 0-66.7C13.4 406.7 0 388.9 0 368L0 48C0 21.5 21.5 0 48 0L384 0zM64 416l0 64 320 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L64 416zm320-32c11.7 0 22.6 3.1 32 8.6L416 64c0-17.7-14.3-32-32-32L48 32c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l336 0zM273.2 160.4c2.5-6.1 11.2-6.1 13.7 0l10.3 24.8 26.8 2.1c6.6 .5 9.2 8.7 4.2 13L307.8 217.9 314 244c1.5 6.4-5.4 11.5-11.1 8.1l-22.9-14-22.9 14c-5.6 3.4-12.6-1.6-11.1-8.1l6.2-26.1-20.4-17.5c-5-4.3-2.3-12.5 4.2-13l26.8-2.1 10.3-24.8zM128 208c0 49.4 37.3 90.1 85.3 95.4-32-19.7-53.3-55.1-53.3-95.4s21.3-75.7 53.3-95.4c-48 5.3-85.3 46-85.3 95.4zM224 80c24.6 0 47.6 6.9 67.1 19 6.4 3.9 9.2 11.7 6.7 18.8s-9.4 11.5-16.9 10.7c-2.9-.3-5.9-.5-8.9-.5-44.2 0-80 35.8-80 80s35.8 80 80 80c3 0 6-.2 8.9-.5 7.4-.8 14.5 3.6 16.9 10.7s-.4 14.9-6.7 18.8c-19.5 12-42.5 19-67.1 19-70.7 0-128-57.3-128-128S153.3 80 224 80z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookQuran = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;