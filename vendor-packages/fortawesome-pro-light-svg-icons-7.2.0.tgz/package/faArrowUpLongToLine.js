'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-up-long-to-line';
var width = 320;
var height = 512;
var aliases = [];
var unicode = 'e6bd';
var svgPathData = 'M16-64l288 0c8.8 0 16 7.2 16 16s-7.2 16-16 16L16-32C7.2-32 0-39.2 0-48S7.2-64 16-64zM148.7 68.7c6.2-6.2 16.4-6.2 22.6 0l144 144c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0L176 118.6 176 560c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-441.4-116.7 116.7c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l144-144z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpLongToLine = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;