'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'binary-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e33e';
var svgPathData = 'M27.3-27.2c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l544 544c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L480 425.5 480 352c0-35.3-28.7-64-64-64l-64 0c-3 0-6 .2-8.9 .6l-78.9-78.9C278.8 198 288 180.1 288 160l0-96c0-35.3-28.7-64-64-64L160 0c-28.5 0-52.7 18.7-61 44.5L27.3-27.2zM128 73.5l0-9.5c0-17.7 14.3-32 32-32l64 0c17.7 0 32 14.3 32 32l0 96c0 11.3-5.8 21.2-14.6 26.9L128 73.5zM374.5 320l41.5 0c17.7 0 32 14.3 32 32l0 41.5-73.5-73.5zm-86.3 26.7c-.1 1.7-.2 3.5-.2 5.3l0 96c0 35.3 28.7 64 64 64l64 0c10.9 0 21.1-2.7 30-7.5l-24.9-24.9c-1.7 .3-3.4 .4-5.1 .4l-64 0c-17.7 0-32-14.3-32-32l0-69.5-31.8-31.8zM409.8 3.4c-3.9-3-8.9-4.1-13.7-2.9l-64 16c-8.6 2.1-13.8 10.8-11.6 19.4s10.8 13.8 19.4 11.6l44.1-11 0 155.5-48 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l128 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-48 0 0-176c0-4.9-2.3-9.6-6.2-12.6zm-224 288c-3.9-3-8.9-4.1-13.7-2.9l-64 16c-8.6 2.1-13.8 10.8-11.6 19.4s10.8 13.8 19.4 11.6l44.1-11 0 155.5-48 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l128 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-48 0 0-176c0-4.9-2.3-9.6-6.2-12.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinarySlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;