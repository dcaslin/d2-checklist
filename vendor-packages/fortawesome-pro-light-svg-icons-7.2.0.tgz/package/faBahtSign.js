'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'baht-sign';
var width = 320;
var height = 512;
var aliases = [];
var unicode = 'e0ac';
var svgPathData = 'M144 0c-8.8 0-16 7.2-16 16l0 48-101.8 0C11.7 64 0 75.7 0 90.2L0 418.9C0 435 13 448 29.1 448l98.9 0 0 48c0 8.8 7.2 16 16 16s16-7.2 16-16l0-48 56 0c57.4 0 104-46.6 104-104 0-44.7-28.2-82.8-67.8-97.5 21.9-19.1 35.8-47.2 35.8-78.5 0-57.4-46.6-104-104-104l-24 0 0-48c0-8.8-7.2-16-16-16zM128 96l0 144-96 0 0-144 96 0zm32 144l0-144 24 0c39.8 0 72 32.2 72 72s-32.2 72-72 72l-24 0zm-32 32l0 144-96 0 0-144 96 0zm32 144l0-144 56 0c39.8 0 72 32.2 72 72s-32.2 72-72 72l-56 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBahtSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;