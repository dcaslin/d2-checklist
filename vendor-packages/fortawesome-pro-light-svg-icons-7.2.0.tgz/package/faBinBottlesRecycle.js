'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bin-bottles-recycle';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e5f6';
var svgPathData = 'M128 64l0 32 64 0 0-32-64 0zM96 96l0-32c0-17.7 14.3-32 32-32l64 0c17.7 0 32 14.3 32 32l0 32c35.3 0 64 28.7 64 64 0-35.3 28.7-64 64-64l0-32c0-17.7 14.3-32 32-32l64 0c17.7 0 32 14.3 32 32l0 32c35.3 0 64 28.7 64 64l0 32 16 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-19.2 0-23 230.4C514.5 487.1 487 512 454.1 512l-332.2 0c-32.9 0-60.4-24.9-63.7-57.6L35.2 224 16 224c-8.8 0-16-7.2-16-16s7.2-16 16-16l16 0 0-32c0-35.3 28.7-64 64-64zm416 64c0-17.7-14.3-32-32-32l-128 0c-17.7 0-32 14.3-32 32l0 32 192 0 0-32zm-256 0c0-17.7-14.3-32-32-32L96 128c-17.7 0-32 14.3-32 32l0 32 192 0 0-32zM384 64l0 32 64 0 0-32-64 0zM67.4 224L90.1 451.2c1.6 16.4 15.4 28.8 31.8 28.8l332.2 0c16.4 0 30.2-12.5 31.8-28.8L508.6 224 67.4 224zM288 288c-5 0-9.6 2.4-12.6 6.4L255 322.3c-5 6.8-14.3 8.5-21.4 4.1-7.9-4.9-9.9-15.5-4.4-23l20.5-27.9c9-12.2 23.2-19.4 38.4-19.4s29.4 7.2 38.4 19.4l20.5 27.9c5.5 7.5 3.5 18.1-4.4 23-7.1 4.4-16.4 2.6-21.4-4.1l-20.5-27.9c-2.9-4-7.6-6.4-12.6-6.4zm-80.2 69.5c7.9 4.9 9.9 15.5 4.4 23l-9.5 13c-1.8 2.4-2.7 5.4-2.7 8.4 0 7.8 6.3 14.1 14.1 14.1l37.9 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-37.9 0c-25.5 0-46.1-20.7-46.1-46.1 0-9.8 3.1-19.4 8.9-27.3l9.5-13c5-6.8 14.3-8.5 21.4-4.1zM308 432c0-8.8 7.2-16 16-16l37.9 0c7.8 0 14.1-6.3 14.1-14.1 0-3-1-5.9-2.7-8.4l-9.5-13c-5.5-7.5-3.5-18.1 4.4-23 7.1-4.4 16.4-2.6 21.4 4.1l9.5 13c5.8 7.9 8.9 17.5 8.9 27.3 0 25.5-20.7 46.1-46.1 46.1L324 448c-8.8 0-16-7.2-16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinBottlesRecycle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;