'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-progress';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e5df';
var svgPathData = 'M251.3 36.7c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6L249.4 80 96 80C43 80 0 123 0 176s43 96 96 96l320 0c35.3 0 64 28.7 64 64 0 25.3-14.7 47.2-36 57.6-9.1-24.3-32.5-41.6-60-41.6-35.3 0-64 28.7-64 64s28.7 64 64 64c31.6 0 57.9-23 63.1-53.1 37.8-12.9 64.9-48.7 64.9-90.9 0-53-43-96-96-96L96 240c-35.3 0-64-28.7-64-64s28.7-64 64-64l153.4 0-20.7 20.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0l48-48c6.2-6.2 6.2-16.4 0-22.6l-48-48zM384 96a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm96 0a64 64 0 1 0 -128 0 64 64 0 1 0 128 0zM96 384a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm62 16c-7.1-27.6-32.2-48-62-48-35.3 0-64 28.7-64 64s28.7 64 64 64c29.8 0 54.9-20.4 62-48l59.4 0-20.7 20.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0l48-48c6.2-6.2 6.2-16.4 0-22.6l-48-48c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l20.7 20.7-59.4 0zm226-16a32 32 0 1 1 0 64 32 32 0 1 1 0-64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowProgress = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;