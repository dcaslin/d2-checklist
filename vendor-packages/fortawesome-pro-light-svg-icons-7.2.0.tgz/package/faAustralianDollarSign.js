'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'australian-dollar-sign';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6fe';
var svgPathData = 'M384 32l0 32.2c-53.6 3.4-96 48-96 102.4 0 50.2 36.3 93 85.8 101.2l47.2 7.9c34.1 5.7 59 35.1 59 69.7 0 39-31.6 70.6-70.6 70.6L328 416c-8.8 0-16 7.2-16 16s7.2 16 16 16l56 0 0 32c0 8.8 7.2 16 16 16s16-7.2 16-16l0-32.2c53.6-3.4 96-48 96-102.4 0-50.2-36.3-93-85.8-101.2L379 236.3c-34.1-5.7-59-35.1-59-69.7 0-39 31.6-70.6 70.6-70.6L456 96c8.8 0 16-7.2 16-16s-7.2-16-16-16l-40 0 0-32c0-8.8-7.2-16-16-16s-16 7.2-16 16zM194.3 351.8L224.5 468c2.2 8.6 11 13.7 19.5 11.5s13.7-11 11.5-19.5L153.5 67.7C150.5 56.1 140 48 128 48s-22.5 8.1-25.5 19.7L.5 460c-2.2 8.6 2.9 17.3 11.5 19.5s17.3-2.9 19.5-11.5L61.7 351.8c.8 .1 1.5 .2 2.3 .2l128 0c.8 0 1.6-.1 2.3-.2zM186 320L70 320 128 96.8 186 320z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAustralianDollarSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;