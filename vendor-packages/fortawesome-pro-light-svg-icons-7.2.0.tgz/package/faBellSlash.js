'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bell-slash';
var width = 576;
var height = 512;
var aliases = [128277,61943];
var unicode = 'f1f6';
var svgPathData = 'M27.3-27.2c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l544 544c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L470.2 415.7c23.5-2.8 41.8-22.8 41.8-47.1 0-10.8-3.7-21.2-10.4-29.6l-10.1-12.6c-28.2-35.2-43.5-79-43.5-124.1l0-10.3c0-83-63.1-151.2-144-159.2L304 16c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 16.8c-48.1 4.8-90 30.9-116 68.7L27.3-27.2zM179.2 124.6C201.7 88.2 242 64 288 64 358.7 64 416 121.3 416 192l0 10.3c0 52.4 17.8 103.2 50.6 144.1L476.6 359c2.2 2.7 3.4 6.1 3.4 9.6 0 8.5-6.9 15.4-15.4 15.4l-26.1 0-259.4-259.4zM128 192l0 10.3c0 45.1-15.4 88.9-43.5 124.1L74.4 339c-6.7 8.4-10.4 18.8-10.4 29.6 0 26.2 21.2 47.4 47.4 47.4l246.1 0-32-32-214.1 0c-8.5 0-15.4-6.9-15.4-15.4 0-3.5 1.2-6.9 3.4-9.6l10.1-12.6c29.4-36.8 46.8-81.7 50-128.4l-31.4-31.4c-.1 1.8-.1 3.6-.1 5.4zm92.1 272c9.9 28 36.6 48 67.9 48s58-20 67.9-48L320 464c-7.3 9.7-18.9 16-32 16s-24.7-6.3-32-16l-35.9 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;