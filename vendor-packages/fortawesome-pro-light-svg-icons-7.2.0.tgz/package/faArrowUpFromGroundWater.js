'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-up-from-ground-water';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4b5';
var svgPathData = 'M308.7 4.7c6.2-6.2 16.4-6.2 22.6 0l96 96c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0L336 54.6 336 360c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-305.4-68.7 68.7c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l96-96zM240 192l0 32-128 0c-8.8 0-16 7.2-16 16l0 170.5c-15.9 10.2-26 12.9-31.6 12.9l-.4 0 0-183.4c0-26.5 21.5-48 48-48l128 0zM571.1 422.9c-6.5-1.2-15.4-5-27.1-12.4L544 240c0-8.8-7.2-16-16-16l-128 0 0-32 128 0c26.5 0 48 21.5 48 48l0 183.4c-1.3 0-2.9-.1-4.9-.5zM402 469.9c-25.6 18.3-52.9 34.1-82 34.1s-56.4-15.8-82-34.1c-26-18.6-61.1-18.6-87.1 0-24.7 17.6-54.6 33.7-86.9 33.5-19.3-.1-38.6-6-57.2-19.3-7.2-5.1-8.9-15.1-3.7-22.3s15.1-8.9 22.3-3.7c13.4 9.6 26.4 13.3 38.8 13.3 22 .1 45-11 68.2-27.5 37.1-26.5 87.1-26.5 124.3 0 25.3 18.1 45.3 28.1 63.5 28.1s38.1-10.1 63.5-28.1c37.1-26.5 87.1-26.5 124.3 0 18.2 13 36.5 22.8 54.4 26.2 17.2 3.3 34.6 .8 52.6-12 7.2-5.1 17.2-3.5 22.3 3.7s3.5 17.2-3.7 22.3c-25.6 18.2-52 22.2-77.2 17.4-24.5-4.7-47.2-17.5-67-31.6-26-18.6-61.1-18.6-87.1 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpFromGroundWater = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;