'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bird';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e469';
var svgPathData = 'M400 200l0-96c0-39.8-32.2-72-72-72s-72 32.2-72 72l0 24c0 35.3-28.7 64-64 64l-160 0 0 8c0 101.6 82.4 184 184 184s184-82.4 184-184zM216 416l-.3 0 38.4 72.5 1.2 3c2.1 7.1-1 15-7.9 18.6s-15.1 1.8-19.8-3.9l-1.8-2.7-48.1-90.9C76.7 394.6 0 306.2 0 200l0-11.6c0-14.7 11.2-26.8 25.5-28.3l2.9-.2 163.6 0c17.7 0 32-14.3 32-32l0-24c0-57.4 46.6-104 104-104 44.3 0 82.2 27.8 97.2 66.9l79 47.4c4.8 2.9 7.8 8.1 7.8 13.7s-3 10.8-7.8 13.7L432 185 432 200c0 88.6-53.4 164.8-129.7 198.1l47.9 90.4 1.2 3c2.1 7.1-1 15-7.9 18.6s-15.1 1.8-19.8-3.9l-1.8-2.7-50.1-94.8c-17.8 4.7-36.4 7.3-55.7 7.3zM464.9 128l-32.9-19.7 0 39.5 32.9-19.7zM328 96a24 24 0 1 1 0 48 24 24 0 1 1 0-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBird = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;