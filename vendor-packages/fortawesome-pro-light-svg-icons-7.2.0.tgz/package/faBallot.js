'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'ballot';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'f732';
var svgPathData = 'M320 32c17.7 0 32 14.3 32 32l0 384c0 17.7-14.3 32-32 32L64 480c-17.7 0-32-14.3-32-32L32 64c0-17.7 14.3-32 32-32l256 0zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-384c0-35.3-28.7-64-64-64L64 0zm96 128c0 8.8 7.2 16 16 16l112 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-112 0c-8.8 0-16 7.2-16 16zm0 128c0 8.8 7.2 16 16 16l112 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-112 0c-8.8 0-16 7.2-16 16zm0 128c0 8.8 7.2 16 16 16l112 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-112 0c-8.8 0-16 7.2-16 16zM96 104a24 24 0 1 0 0 48 24 24 0 1 0 0-48zM72 256a24 24 0 1 0 48 0 24 24 0 1 0 -48 0zM96 360a24 24 0 1 0 0 48 24 24 0 1 0 0-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBallot = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;