'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'b';
var width = 320;
var height = 512;
var aliases = [98];
var unicode = '42';
var svgPathData = 'M16 32C7.2 32 0 39.2 0 48L0 464c0 8.8 7.2 16 16 16l176 0c70.7 0 128-57.3 128-128 0-52.8-32-98.2-77.7-117.7 27.7-20.4 45.7-53.2 45.7-90.3 0-61.9-50.1-112-112-112L16 32zM192 256c53 0 96 43 96 96s-43 96-96 96l-160 0 0-192 160 0zm-16-32l-144 0 0-160 144 0c44.2 0 80 35.8 80 80s-35.8 80-80 80z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faB = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;