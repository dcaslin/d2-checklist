'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'alarm-minus';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e803';
var svgPathData = 'M256 64c123.7 0 224 100.3 224 224 0 56.1-20.6 107.4-54.7 146.7l50 50 2.1 2.5c4.1 6.2 3.4 14.7-2.1 20.1s-13.9 6.2-20.1 2.1l-2.5-2.1-50-50C363.4 491.4 312.1 512 256 512s-107.4-20.6-146.7-54.7l-50 50c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l50-50C52.6 395.4 32 344.1 32 288 32 164.3 132.3 64 256 64zm0 32a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm80 176c8.8 0 16 7.2 16 16s-7.2 16-16 16l-160 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l160 0zM100.2 .1c17.5 .9 33.7 6.5 47.4 15.5 9.5 6.3 6.3 19.9-4.1 24.6l-.8 .4c-5.6 2.6-12.1 1.8-17.5-1.1-8.9-4.8-19.1-7.6-30-7.6-34.9 0-63.2 28.3-63.2 63.2 0 6.8 1.1 13.4 3.1 19.5 1.9 5.8 1.5 12.4-2.1 17.4l-.5 .7c-6.5 9.4-20.5 10.1-25-.4-4.3-10-6.9-20.9-7.4-32.4L0 95.2C0 42.6 42.6 0 95.2 0l4.9 .1zM416.7 0C469.4 0 512 42.6 512 95.2l-.1 4.9c-.6 11.4-3.2 22.3-7.4 32.4-4.5 10.5-18.4 9.8-25 .4l-.5-.7c-3.5-5-4-11.6-2.1-17.4 2-6.2 3.1-12.7 3.1-19.5 0-34.9-28.3-63.2-63.3-63.2-10.8 0-21 2.7-30 7.6-5.4 2.9-11.9 3.6-17.5 1.1l-.8-.4c-10.4-4.7-13.7-18.3-4.1-24.6 13.7-9.1 30-14.6 47.4-15.5l4.9-.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlarmMinus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;