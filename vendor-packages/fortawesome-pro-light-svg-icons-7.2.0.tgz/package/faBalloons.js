'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'balloons';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e2e4';
var svgPathData = 'M231.5 285.4C262 249.1 288 204.5 288 160 288 89.3 230.7 32 160 32S32 89.3 32 160c0 44.5 26 89.1 56.5 125.4 14.8 17.6 29.7 32 40.9 42 9.9 8.9 20.1 16.6 30.6 24.6 10.6-7.9 20.8-15.7 30.6-24.6 11.2-10 26.1-24.5 40.9-42zM134.5 416l51.1 0-25.5-38.3-25.5 38.3zM320 160c0 112-128 208-128 208l27.9 41.8c2.7 4 4.1 8.8 4.1 13.6 0 13.6-11 24.6-24.6 24.6l-78.9 0c-13.6 0-24.6-11-24.6-24.6 0-4.8 1.4-9.6 4.1-13.6L128 368S0 272 0 160C0 71.6 71.6 0 160 0S320 71.6 320 160zm64 272s-52.2-39.2-90-96.7c5.8-7 11.7-14.4 17.3-22.2 1.2-1.6 2.3-3.2 3.5-4.9 8.7 14.5 18.9 28.3 29.6 41.1 14.8 17.6 29.7 32 40.9 42 9.9 8.8 20.1 16.7 30.6 24.6 10.6-7.9 20.8-15.7 30.6-24.6 11.2-10 26.1-24.5 40.9-42 30.5-36.2 56.5-80.9 56.5-125.4 0-70.7-57.3-128-128-128-19.5 0-38 4.4-54.5 12.2-2.7-10.5-6.2-20.7-10.4-30.4 19.8-8.8 41.8-13.7 64.9-13.7 88.4 0 160 71.6 160 160 0 112-128 208-128 208l27.9 41.8c2.7 4 4.1 8.8 4.1 13.6 0 13.6-11 24.6-24.6 24.6l-78.9 0c-13.6 0-24.6-11-24.6-24.6 0-4.8 1.4-9.6 4.1-13.6L384 432zm32 9.7l-25.5 38.3 51.1 0-25.5-38.3zM144 112c-17.7 0-32 14.3-32 32 0 8.8-7.2 16-16 16s-16-7.2-16-16c0-35.3 28.7-64 64-64 8.8 0 16 7.2 16 16s-7.2 16-16 16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBalloons = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;