'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'badminton';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e33a';
var svgPathData = 'M480 376c26.2 0 48.9 18 54.9 43.5l24.7 104.8 .4 3.2c.2 7.4-4.8 14.2-12.3 16s-15.1-2.1-18.2-8.8l-1.1-3.1-8.4-35.7-24 0 0 32c0 8.8-7.2 16-16 16-8.8 0-16-7.2-16-16l0-32-24 0-8.4 35.7c-2 8.6-10.6 13.9-19.2 11.9-8.6-2-13.9-10.6-11.9-19.2l24.7-104.9c6-25.5 28.7-43.5 54.9-43.5zM407.9-15.8c39.8 1.7 77.8 16.4 106.7 45.3 30.8 30.8 45.5 71.9 45.5 114.7l-.3 10.2c-2.7 51.1-26 103.9-67.8 145.7-74.6 74.6-187.1 91.1-258.6 33.2l-59.2 59.2c10.7 14.6 10.4 34.8-1.2 48.9l-2.7 3-70.1 70.1c-14.6 14.6-37.8 15.6-53.5 2.8l-3-2.8-14.1-14.1c-15.6-15.6-15.6-40.9 0-56.6l70.1-70.1 3-2.8c14.1-11.5 34.3-11.9 48.9-1.2l59.1-59.1c-21.8-27-33.1-60.2-34.6-94.7l-.2-8c0-54.2 23.5-111.3 68-155.8S345.8-16 399.9-16l8 .2zM133.7 396.3c-2.7-2.7-7-3.1-10.1-1l-1.2 1-70.1 70.1c-3.1 3.1-3.1 8.2 0 11.3l14.1 14.1 1.2 1c3.1 2 7.3 1.7 10.1-1l70.1-70.1c2.7-2.7 3.1-7 1-10.1l-1-1.3-14.1-14.1zM480 408c-11.3 0-21.2 7.8-23.8 18.8l-8.7 37.2 65 0-8.8-37.2c-2.6-11-12.4-18.8-23.8-18.8zM399.9 16c-45.1 0-94.2 19.7-133.2 58.7S208 162.8 208 207.9l.2 6.6c1.4 32.8 13.4 62.9 36 85.4 54.1 54.1 154.8 47.9 225.2-22.5 36.6-36.6 56.1-82 58.4-124.7l.2-8.5c0-35.4-12.1-68-36.1-92-22.5-22.5-52.6-34.5-85.4-36l-6.6-.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBadminton = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;