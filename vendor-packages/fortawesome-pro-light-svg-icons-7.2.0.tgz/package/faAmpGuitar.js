'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'amp-guitar';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f8a1';
var svgPathData = 'M184 32l144 0c30.9 0 56 25.1 56 56l0 8-256 0 0-8c0-30.9 25.1-56 56-56zM96 88l0 8-32 0C28.7 96 0 124.7 0 160L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64l-32 0 0-8c0-48.6-39.4-88-88-88L184 0C135.4 0 96 39.4 96 88zm352 40c17.7 0 32 14.3 32 32l0 256c0 17.7-14.3 32-32 32L64 448c-17.7 0-32-14.3-32-32l0-256c0-17.7 14.3-32 32-32l384 0zM112 288l288 0 0 80-288 0 0-80zm-32 0l0 80c0 17.7 14.3 32 32 32l288 0c17.7 0 32-14.3 32-32l0-80c0-17.7-14.3-32-32-32l-288 0c-17.7 0-32 14.3-32 32zm40-88a24 24 0 1 0 -48 0 24 24 0 1 0 48 0zm72 24a24 24 0 1 0 0-48 24 24 0 1 0 0 48zm152-24a24 24 0 1 0 -48 0 24 24 0 1 0 48 0zm72 24a24 24 0 1 0 0-48 24 24 0 1 0 0 48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAmpGuitar = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;