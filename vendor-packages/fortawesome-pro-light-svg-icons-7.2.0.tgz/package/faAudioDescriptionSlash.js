'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'audio-description-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0a8';
var svgPathData = 'M27.3-27.2c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l544 544c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L499.5 445c25.8-8.2 44.5-32.4 44.5-61l0-256c0-35.3-28.7-64-64-64L118.5 64 27.3-27.2zM150.5 96L480 96c17.7 0 32 14.3 32 32l0 256c0 17.7-14.3 32-32 32l-9.5 0-68.8-68.8c27-10.4 46.2-36.6 46.2-67.2l0-48c0-39.8-32.2-72-72-72l-56 0c-8.8 0-16 7.2-16 16L304 249.5 150.5 96zm224 224l-38.5-38.5 0-89.5 40 0c22.1 0 40 17.9 40 40l0 48c0 22.1-17.9 40-40 40l-1.5 0zM39.5 98c-4.8 9-7.5 19.2-7.5 30l0 256c0 35.3 28.7 64 64 64l293.5 0-32-32-261.5 0c-17.7 0-32-14.3-32-32l0-256c0-1.7 .1-3.4 .4-5.1L39.5 98zm96 96c-4.8 9-7.5 19.2-7.5 30l0 112c0 8.8 7.2 16 16 16s16-7.2 16-16l0-48 69.5 0-32-32-37.5 0 0-32c0-1.7 .1-3.4 .4-5.1L135.5 194zM240 298.5l0 37.5c0 8.8 7.2 16 16 16s16-7.2 16-16l0-5.5-32-32z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAudioDescriptionSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;