'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-journal-whills';
var width = 448;
var height = 512;
var aliases = ["journal-whills"];
var unicode = 'f66a';
var svgPathData = 'M0 64C0 28.7 28.7 0 64 0L400 0c26.5 0 48 21.5 48 48l0 320c0 20.9-13.4 38.7-32 45.3l0 66.7 16 0c8.8 0 16 7.2 16 16s-7.2 16-16 16L64 512c-35.3 0-64-28.7-64-64l0 0 0-384zM64 416c-17.7 0-32 14.3-32 32s14.3 32 32 32l320 0 0-64-320 0zM32 392.6c9.4-5.4 20.3-8.6 32-8.6l336 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 32C46.3 32 32 46.3 32 64l0 328.6zM304.4 71c43 26.8 71.6 74.6 71.6 129 0 83.9-68.1 152-152 152S72 283.9 72 200c0-54.5 28.7-102.2 71.6-129 6.3-3.9 14.4-3 19.7 2.2s6.3 13.3 2.4 19.7c-6.2 10.3-9.8 22.3-9.8 35.2 0 20.5 9 38.8 23.4 51.3 5.8 5.1 7.2 13.6 3.3 20.2-4.2 7.1-6.7 15.5-6.7 24.4 0 21.1 13.6 38.9 32.4 45.4l.7-17.1c-10.2-5.4-17.1-16-17.1-28.3 0-13.2 8-24.5 19.4-29.4L216 79.7c.2-4.3 3.7-7.7 8-7.7s7.8 3.4 8 7.7l4.6 114.9c11.4 4.9 19.4 16.2 19.4 29.4 0 12.3-6.9 23-17.1 28.3l.7 17.1c18.9-6.5 32.4-24.4 32.4-45.4 0-9-2.4-17.3-6.7-24.4-3.9-6.6-2.6-15.2 3.3-20.2 14.4-12.5 23.4-30.8 23.4-51.3 0-12.9-3.6-24.9-9.8-35.2-3.8-6.3-2.8-14.5 2.4-19.7S298.1 67 304.4 71zm-5.9 123.8c3.6 9.1 5.5 19 5.5 29.3 0 44.2-35.8 80-80 80s-80-35.8-80-80c0-10.3 2-20.2 5.5-29.3-14.7-16.4-24.1-37.8-25.4-61.3-12.7 19.1-20.1 42-20.1 66.6 0 66.3 53.7 120 120 120s120-53.7 120-120c0-24.6-7.4-47.5-20.1-66.6-1.3 23.5-10.6 44.9-25.4 61.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookJournalWhills = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;