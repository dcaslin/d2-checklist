'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = '8';
var width = 320;
var height = 512;
var aliases = [];
var unicode = '38';
var svgPathData = 'M304 152c0-66.3-53.7-120-120-120l-48 0C69.7 32 16 85.7 16 152 16 193.4 36.9 229.9 68.8 251.4 28.1 270.6 0 312 0 360 0 426.3 53.7 480 120 480l80 0c66.3 0 120-53.7 120-120 0-48-28.1-89.4-68.8-108.6 31.9-21.6 52.8-58.1 52.8-99.4zM184.1 272l15.9 0c48.6 0 88 39.4 88 88s-39.4 88-88 88l-80 0c-48.6 0-88-39.4-88-88s39.4-88 88-88l64.1 0zm0-32l-48.1 0c-48.6 0-87.9-39.4-87.9-88 0-48.6 39.4-88 88-88l48 0c48.6 0 88 39.4 88 88 0 48.6-39.4 88-87.9 88z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.fa8 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;