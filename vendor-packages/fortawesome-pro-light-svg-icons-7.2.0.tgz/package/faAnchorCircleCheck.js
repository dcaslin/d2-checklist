'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'anchor-circle-check';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4aa';
var svgPathData = 'M288 32a48 48 0 1 0 0 96 48 48 0 1 0 0-96zM208 80c0-44.2 35.8-80 80-80s80 35.8 80 80c0 38.7-27.5 71-64 78.4l0 304.8c4.5-.4 8.9-1.1 13.2-1.9 3.5 10.4 7.9 20.5 13.1 30-13.6 3.1-27.7 4.7-42.3 4.7-106 0-192-86-192-192l0-28.7-37.5 32.8c-6.7 5.8-16.8 5.1-22.6-1.5s-5.1-16.8 1.5-22.6l64-56c6-5.3 15-5.3 21.1 0l64 56c6.7 5.8 7.3 15.9 1.5 22.6s-15.9 7.3-22.6 1.5L128 275.3 128 304c0 83 63.1 151.2 144 159.2l0-304.8c-36.5-7.4-64-39.7-64-78.4zM496 512a112 112 0 1 0 0-224 112 112 0 1 0 0 224zm0-256a144 144 0 1 1 0 288 144 144 0 1 1 0-288zm57.4 83.1c7.1 5.2 8.7 15.2 3.5 22.4l-64 88c-2.8 3.8-7 6.2-11.7 6.5s-9.3-1.3-12.6-4.6l-40-40c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l26.8 26.8 53-72.9c5.2-7.1 15.2-8.7 22.4-3.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAnchorCircleCheck = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;