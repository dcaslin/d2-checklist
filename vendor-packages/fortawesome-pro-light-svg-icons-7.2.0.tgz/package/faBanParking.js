'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'ban-parking';
var width = 512;
var height = 512;
var aliases = ["parking-circle-slash"];
var unicode = 'f616';
var svgPathData = 'M425.3 402.7L332 309.4c30.9-16 52-48.2 52-85.4 0-53-43-96-96-96l-88 0c-13.3 0-24 10.7-24 24l0 1.4-66.7-66.7c39.3-34.1 90.6-54.7 146.7-54.7 123.7 0 224 100.3 224 224 0 56.1-20.6 107.4-54.7 146.7zm-22.6 22.6C363.4 459.4 312.1 480 256 480 132.3 480 32 379.7 32 256 32 199.9 52.6 148.6 86.7 109.3L176 198.6 176 368c0 8.8 7.2 16 16 16s16-7.2 16-16l0-48 80 0c3 0 6-.1 9-.4L402.7 425.3zM307.6 285l-99.6-99.6 0-25.4 80 0c35.3 0 64 28.7 64 64 0 28.5-18.7 52.7-44.4 61zM208 230.6l57.4 57.4-57.4 0 0-57.4zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanParking = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;