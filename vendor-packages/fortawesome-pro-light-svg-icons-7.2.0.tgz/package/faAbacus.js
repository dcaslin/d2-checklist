'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'abacus';
var width = 576;
var height = 512;
var aliases = [129518];
var unicode = 'f640';
var svgPathData = 'M512 64c17.7 0 32 14.3 32 32l0 96-96 0 0-32 16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0 0-64 64 0zm-96 64l-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l16 0 0 32-128 0 0-32 16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0 0-64 128 0 0 64zm-160 0l-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l16 0 0 32-96 0 0-32 16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0 0-64 96 0 0 64zm-128 0l-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l16 0 0 32-96 0 0-96c0-17.7 14.3-32 32-32l64 0 0 64zM32 416l0-192 96 0 0 64-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l16 0 0 32-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l16 0 0 64-64 0c-17.7 0-32-14.3-32-32zm128-32l16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0 0-32 16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0 0-64 96 0 0 64-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l16 0 0 32-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l16 0 0 64-96 0 0-64zm128-64l16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0 0-64 128 0 0 128-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l16 0 0 64-128 0 0-64 16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0 0-32zm160 64l16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0 0-128 96 0 0 192c0 17.7-14.3 32-32 32l-64 0 0-64zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAbacus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;