'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-archery';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e839';
var svgPathData = 'M556.6-31.5c5.4-1.4 11.2 .2 15.2 4.2s5.6 9.7 4.2 15.2l-32 128c-1.4 5.6-5.7 10-11.3 11.5s-11.5 0-15.6-4.1L480.5 86.6 170.2 396.9 184 452.1c1.4 5.4-.2 11.2-4.2 15.2l-64 64c-4.1 4.1-10 5.6-15.6 4.1s-9.9-5.9-11.3-11.5l-13.7-54.7-54.7-13.7c-5.6-1.4-10-5.7-11.5-11.2s0-11.5 4.1-15.6l64-64 1.6-1.4c3.8-3 8.9-4 13.6-2.8L147.6 374.3 457.8 64 421.2 27.3c-4.1-4.1-5.6-10-4.1-15.6S423 1.9 428.6 .5l128-32zM55.8 431.3l36.6 9.2c5.7 1.4 10.2 5.9 11.7 11.7l9.1 36.6 37.6-37.6-11.5-45.9-45.9-11.5-37.6 37.6zm408-406.7l56 56 18.7-74.7-74.7 18.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowArchery = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;