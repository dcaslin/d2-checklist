'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'basket-shopping-simple';
var width = 576;
var height = 512;
var aliases = ["shopping-basket-alt"];
var unicode = 'e0af';
var svgPathData = 'M299.9 5.3C296.9 1.9 292.6 0 288 0s-8.9 1.9-11.9 5.3L137.7 160 32 160 32 160c-8.8 0-16 7.2-16 16s7.2 16 16 16l6.4 0 47.3 236.6c6 29.9 32.2 51.4 62.8 51.4l279.1 0c30.5 0 56.8-21.5 62.8-51.4l47.3-236.6 6.4 0c8.8 0 16-7.2 16-16s-7.2-16-16-16L438.3 160 299.9 5.3zM395.4 160L180.6 160 288 40 395.4 160zM117.1 422.3L71 192 505 192 458.9 422.3c-3 15-16.1 25.7-31.4 25.7l-279.1 0c-15.3 0-28.4-10.8-31.4-25.7zM168 288a24 24 0 1 0 0-48 24 24 0 1 0 0 48zm264-24a24 24 0 1 0 -48 0 24 24 0 1 0 48 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBasketShoppingSimple = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;