'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bin-recycle';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e5f7';
var svgPathData = 'M0 80c0-8.8 7.2-16 16-16l544 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-16 0-26.7 293.8c-3 33-30.6 58.2-63.7 58.2l-331.1 0c-33.1 0-60.7-25.2-63.7-58.2L32 96 16 96C7.2 96 0 88.8 0 80zM64.1 96L90.6 386.9c1.5 16.5 15.3 29.1 31.9 29.1l331.1 0c16.6 0 30.4-12.6 31.9-29.1L511.9 96 64.1 96zM288 176c-4.8 0-9.4 2.3-12.2 6.3L252 216.1c-4.9 6.9-14.4 8.8-21.6 4.3-7.8-4.9-9.9-15.3-4.6-22.8l23.9-33.8c8.8-12.4 23.1-19.8 38.3-19.8s29.5 7.4 38.3 19.8l23.9 33.8c5.3 7.5 3.2 17.9-4.6 22.8-7.2 4.5-16.7 2.6-21.6-4.3l-23.9-33.8c-2.8-3.9-7.3-6.3-12.2-6.3zm-82.2 76.2c7.8 4.9 9.9 15.3 4.6 22.8l-15.8 22.3c-1.7 2.4-2.6 5.3-2.6 8.3 0 7.9 6.4 14.4 14.4 14.4l45.6 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-45.6 0c-25.6 0-46.4-20.8-46.4-46.4 0-9.6 3-18.9 8.5-26.7l15.8-22.3c4.9-6.9 14.4-8.8 21.6-4.3zM308 336c0-8.8 7.2-16 16-16l45.6 0c7.9 0 14.4-6.4 14.4-14.4 0-3-.9-5.9-2.6-8.3L365.6 275c-5.3-7.5-3.2-17.9 4.6-22.8 7.2-4.5 16.7-2.6 21.5 4.3l15.8 22.3c5.5 7.8 8.5 17.2 8.5 26.7 0 25.6-20.8 46.4-46.4 46.4L324 352c-8.8 0-16-7.2-16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinRecycle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;