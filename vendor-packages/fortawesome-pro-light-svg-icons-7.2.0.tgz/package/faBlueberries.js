'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'blueberries';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e2e8';
var svgPathData = 'M382.7 312.3c56.6-19.4 97.3-73.1 97.3-136.3 0-79.5-64.5-144-144-144-63.2 0-116.9 40.7-136.3 97.3-7.8-.9-15.7-1.3-23.7-1.3-3.2 0-6.3 .1-9.4 .2 20.8-74 88.8-128.2 169.4-128.2 97.2 0 176 78.8 176 176 0 80.6-54.2 148.6-128.2 169.4 .1-3.1 .2-6.3 .2-9.4 0-8-.5-15.9-1.3-23.7zM320 336a144 144 0 1 0 -288 0 144 144 0 1 0 288 0zM0 336a176 176 0 1 1 352 0 176 176 0 1 1 -352 0zm176-96l0 32 32 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-32 0 0 32c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-32-32 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l32 0 0-32c0-8.8 7.2-16 16-16s16 7.2 16 16zM368 80l0 32 32 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-32 0 0 32c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-32-32 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l32 0 0-32c0-8.8 7.2-16 16-16s16 7.2 16 16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlueberries = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;