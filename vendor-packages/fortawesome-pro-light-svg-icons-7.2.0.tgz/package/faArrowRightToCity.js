'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-right-to-city';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4b3';
var svgPathData = 'M320 64l0 384c0 17.7 14.3 32 32 32l224 0c17.7 0 32-14.3 32-32l0-288c0-17.7-14.3-32-32-32l-80 0c-8.8 0-16-7.2-16-16l0-48c0-17.7-14.3-32-32-32l-96 0c-17.7 0-32 14.3-32 32zM512 96l32 0 0-80c0-8.8 7.2-16 16-16s16 7.2 16 16l0 80c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64l-224 0c-35.3 0-64-28.7-64-64l0-384c0-35.3 28.7-64 64-64l96 0c35.3 0 64 28.7 64 64l0 32zM388 88l24 0c6.6 0 12 5.4 12 12l0 24c0 6.6-5.4 12-12 12l-24 0c-6.6 0-12-5.4-12-12l0-24c0-6.6 5.4-12 12-12zM376 196c0-6.6 5.4-12 12-12l24 0c6.6 0 12 5.4 12 12l0 24c0 6.6-5.4 12-12 12l-24 0c-6.6 0-12-5.4-12-12l0-24zm12 84l24 0c6.6 0 12 5.4 12 12l0 24c0 6.6-5.4 12-12 12l-24 0c-6.6 0-12-5.4-12-12l0-24c0-6.6 5.4-12 12-12zm116-84c0-6.6 5.4-12 12-12l24 0c6.6 0 12 5.4 12 12l0 24c0 6.6-5.4 12-12 12l-24 0c-6.6 0-12-5.4-12-12l0-24zm12 84l24 0c6.6 0 12 5.4 12 12l0 24c0 6.6-5.4 12-12 12l-24 0c-6.6 0-12-5.4-12-12l0-24c0-6.6 5.4-12 12-12zM219.3 244.7c6.2 6.2 6.2 16.4 0 22.6l-72 72c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6L169.4 272 48 272c-8.8 0-16-7.2-16-16s7.2-16 16-16l121.4 0-44.7-44.7c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l72 72z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRightToCity = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;