'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-sparkles';
var width = 448;
var height = 512;
var aliases = ["book-spells"];
var unicode = 'f6b8';
var svgPathData = 'M64 0C28.7 0 0 28.7 0 64l0 384 0 0c0 35.3 28.7 64 64 64l368 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0 0-66.7c18.6-6.6 32-24.4 32-45.3l0-320c0-26.5-21.5-48-48-48L64 0zM384 416l0 64-320 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l320 0zM64 384c-11.7 0-22.6 3.1-32 8.6L32 64c0-17.7 14.3-32 32-32l336 0c8.8 0 16 7.2 16 16l0 320c0 8.8-7.2 16-16 16L64 384zM288 192.6l14.1 32.9c1.6 3.8 4.6 6.8 8.4 8.4l32.9 14.1-32.9 14.1c-3.8 1.6-6.8 4.6-8.4 8.4l-14.1 32.9-14.1-32.9c-1.6-3.8-4.6-6.8-8.4-8.4l-32.9-14.1 32.9-14.1c3.8-1.6 6.8-4.6 8.4-8.4L288 192.6zm-22.1-29.8L247 207 202.9 225.9c-19.4 8.3-19.4 35.8 0 44.1L247 289 265.9 333.1c8.3 19.4 35.8 19.4 44.1 0L329 289 373.1 270.1c19.4-8.3 19.4-35.8 0-44.1L329 207 310.1 162.9c-8.3-19.4-35.8-19.4-44.1 0zm-113-41l7-14 7 14c1.5 3.1 4.1 5.6 7.2 7.2l14 7-14 7c-3.1 1.5-5.6 4.1-7.2 7.2l-7 14-7-14c-1.5-3.1-4.1-5.6-7.2-7.2l-14-7 14-7c3.1-1.5 5.6-4.1 7.2-7.2zm28.5-42.7c-8.8-17.7-34.1-17.7-42.9 0l-11.8 23.6-23.6 11.8c-17.7 8.8-17.7 34.1 0 42.9l23.6 11.8 11.8 23.6c8.8 17.7 34.1 17.7 42.9 0l11.8-23.6 23.6-11.8c17.7-8.8 17.7-34.1 0-42.9l-23.6-11.8-11.8-23.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookSparkles = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;