'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-down-up-lock';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e4b0';
var svgPathData = 'M267.3 411.3l-96 96c-6.2 6.2-16.4 6.2-22.6 0l-96-96c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l68.7 68.7 0-185.4-88 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l280 0 0-185.4-68.7 68.7c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l96-96c6.2-6.2 16.4-6.2 22.6 0l96 96c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0L368 54.6 368 219.3c-13.1 14.9-22.9 32.8-28 52.7l-164 0 0 185.4 68.7-68.7c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6zM176 16l0 176-32 0 0-176c0-8.8 7.2-16 16-16s16 7.2 16 16zM384 352.1l0-48c0-44.2 35.8-80 80-80s80 35.8 80 80l0 50.6c18.6 6.6 32 24.4 32 45.3l0 96c0 26.5-21.5 48-48 48l-128 0c-26.5 0-48-21.5-48-48l0-96c0-20.9 13.4-38.7 32-45.3l0-2.6zm0 47.9l0 96c0 8.8 7.2 16 16 16l128 0c8.8 0 16-7.2 16-16l0-96c0-8.2-6.2-15-14.3-15.9l-131.5 0c-8 .9-14.3 7.7-14.3 15.9zm128-95.9c0-26.5-21.5-48-48-48s-48 21.5-48 48l0 47.9 96 0 0-47.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownUpLock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;