'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bone-break';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f5d8';
var svgPathData = 'M336-16c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96zM187.3 36.7c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l64 64c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6l-64-64zm288 22.6c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0l-64 64c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0l64-64zM104 128c-57.4 0-104 46.6-104 104 0 20.6 6 39.8 16.4 56-10.3 16.2-16.4 35.4-16.4 56 0 57.4 46.6 104 104 104 49.2 0 90.4-34.1 101.2-80l229.6 0c10.8 45.9 52 80 101.2 80 57.4 0 104-46.6 104-104 0-20.6-6-39.8-16.4-56 10.3-16.2 16.4-35.4 16.4-56 0-57.4-46.6-104-104-104-49.2 0-90.4 34.1-101.2 80l-30.4 0c-8.3 0-16 4.3-20.4 11.3L320 321.8 255.9 219.3c-4.4-7-12.1-11.3-20.4-11.3l-30.4 0c-10.8-45.9-52-80-101.2-80zM231.1 240l60 96-92.2 0c-12.7 0-22.1 9.6-24 20.5-5.9 33.8-35.4 59.5-70.9 59.5-39.8 0-72-32.2-72-72 0-15.5 4.9-29.8 13.2-41.5 6.1-8.7 6.1-20.3 0-29-8.3-11.7-13.2-26-13.2-41.5 0-39.8 32.2-72 72-72 35.5 0 65 25.7 70.9 59.5 1.9 10.9 11.3 20.5 24 20.5l32.2 0zm177.7 0l32.2 0c12.7 0 22.1-9.6 24-20.5 5.9-33.8 35.4-59.5 70.9-59.5 39.8 0 72 32.2 72 72 0 15.5-4.9 29.8-13.2 41.5-6.1 8.7-6.1 20.3 0 29 8.3 11.7 13.2 26 13.2 41.5 0 39.8-32.2 72-72 72-35.5 0-65-25.7-70.9-59.5-1.9-10.9-11.3-20.5-24-20.5l-92.2 0 60-96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoneBreak = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;