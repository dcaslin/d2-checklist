'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-skull';
var width = 448;
var height = 512;
var aliases = ["book-dead"];
var unicode = 'f6b7';
var svgPathData = 'M0 64C0 28.7 28.7 0 64 0L400 0c26.5 0 48 21.5 48 48l0 320c0 20.9-13.4 38.7-32 45.3l0 66.7 16 0c8.8 0 16 7.2 16 16s-7.2 16-16 16L64 512c-35.3 0-64-28.7-64-64l0 0 0-384zM64 416c-17.7 0-32 14.3-32 32s14.3 32 32 32l320 0 0-64-320 0zM32 392.6c9.4-5.4 20.3-8.6 32-8.6l336 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 32C46.3 32 32 46.3 32 64l0 328.6zM224 96c-38.9 0-64 24.6-64 48 0 15.9 10.9 31.7 30.7 40.9 5.7 2.6 9.3 8.3 9.3 14.5l0 .6 48 0 0-.6c0-6.2 3.6-11.9 9.3-14.5 19.9-9.2 30.7-25.1 30.7-40.9 0-23.4-25.1-48-64-48zm-96 48c0-47.3 46.5-80 96-80s96 32.7 96 80c0 28.6-17.5 52.2-41.6 66-4.2 12.8-16.2 22-30.4 22l-48 0c-14.2 0-26.2-9.2-30.4-22-24.1-13.8-41.6-37.4-41.6-66zm48 0a16 16 0 1 1 32 0 16 16 0 1 1 -32 0zm80-16a16 16 0 1 1 0 32 16 16 0 1 1 0-32zm70.6 121.4c3.7 8 .1 17.5-7.9 21.2l-56 25.4 56 25.4c8 3.7 11.6 13.1 7.9 21.2s-13.1 11.6-21.2 7.9l-81.4-37-81.4 37c-8 3.7-17.5 .1-21.2-7.9s-.1-17.5 7.9-21.2l56-25.4-56-25.4c-8-3.7-11.6-13.1-7.9-21.2s13.1-11.6 21.2-7.9l81.4 37 81.4-37c8-3.7 17.5-.1 21.2 7.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookSkull = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;