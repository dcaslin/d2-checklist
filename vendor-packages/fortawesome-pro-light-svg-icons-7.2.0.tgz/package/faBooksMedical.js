'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'books-medical';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f7e8';
var svgPathData = 'M432.8 28.4L371 45c-8.5 2.3-13.6 11.1-11.3 19.6l12.4 46.4 92.7-24.8-12.4-46.4c-2.3-8.5-11.1-13.6-19.6-11.3zm98.7 182.8c-11-2.1-22.4-3.2-34-3.3l-24.4-91-92.7 24.8 24 89.4c-9.9 5.4-19.3 11.7-28.1 18.7L352 159.6 352 273c-13.1 14.9-24 31.7-32 50.1L320 144c0-8.8-7.2-16-16-16l-64 0c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l64 0c6 0 11.2-3.3 13.9-8.1 4.3 10.5 9.4 20.6 15.4 30.1-8.1 6.3-18.3 10-29.3 10l-64 0c-12.3 0-23.5-4.6-32-12.2-8.5 7.6-19.7 12.2-32 12.2l-64 0c-26.5 0-48-21.5-48-48L64 48C64 21.5 85.5 0 112 0l64 0c26.5 0 48 21.5 48 48l0 50.7c5-1.8 10.4-2.7 16-2.7l64 0c13.8 0 26.3 5.8 35 15.2L328.8 72.9c-6.9-25.6 8.3-51.9 33.9-58.8L424.5-2.5c25.6-6.9 51.9 8.3 58.8 33.9 16.8 62.8 26.7 99.5 48.2 179.8zM192 464l0-48-96 0 0 48c0 8.8 7.2 16 16 16l64 0c8.8 0 16-7.2 16-16zm0-80l0-256-96 0 0 256 96 0zM112 32c-8.8 0-16 7.2-16 16l0 48 96 0 0-48c0-8.8-7.2-16-16-16l-64 0zM496 512a112 112 0 1 0 0-224 112 112 0 1 0 0 224zm0-256a144 144 0 1 1 0 288 144 144 0 1 1 0-288zm-10.7 72l21.3 0c8.8 0 16 7.2 16 16l0 29.3 29.3 0c8.8 0 16 7.2 16 16l0 21.3c0 8.8-7.2 16-16 16l-29.3 0 0 29.3c0 8.8-7.2 16-16 16l-21.3 0c-8.8 0-16-7.2-16-16l0-29.3-29.3 0c-8.8 0-16-7.2-16-16l0-21.3c0-8.8 7.2-16 16-16l29.3 0 0-29.3c0-8.8 7.2-16 16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBooksMedical = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;