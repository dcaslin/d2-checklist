'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bell-ring';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e62c';
var svgPathData = 'M240 16c0-8.8 7.2-16 16-16s16 7.2 16 16l0 16.8c80.9 8 144 76.2 144 159.2l0 10.3c0 45.1 15.4 88.9 43.5 124.1L469.6 339c6.7 8.4 10.4 18.8 10.4 29.6 0 26.2-21.2 47.4-47.4 47.4L79.4 416c-26.2 0-47.4-21.2-47.4-47.4 0-10.8 3.7-21.2 10.4-29.6l10.1-12.6C80.6 291.2 96 247.4 96 202.3L96 192c0-83 63.1-151.2 144-159.2L240 16zM128 192l0 10.3c0 52.4-17.8 103.2-50.6 144.1L67.4 359c-2.2 2.7-3.4 6.1-3.4 9.6 0 8.5 6.9 15.4 15.4 15.4l353.2 0c8.5 0 15.4-6.9 15.4-15.4 0-3.5-1.2-6.9-3.4-9.6l-10.1-12.6C401.8 305.5 384 254.7 384 202.3l0-10.3c0-70.7-57.3-128-128-128S128 121.3 128 192zM256 512c-31.3 0-58-20-67.9-48l35.9 0c7.3 9.7 18.9 16 32 16s24.7-6.3 32-16l35.9 0c-9.9 28-36.6 48-67.9 48zM99 35.6c-41.3 39.4-67 94.9-67 156.4 0 8.8-7.2 16-16 16S0 200.8 0 192C0 121.3 29.6 57.6 77 12.4 83.4 6.3 93.5 6.6 99.6 13s5.8 16.5-.5 22.6zM435 12.4c47.4 45.2 77 108.9 77 179.6 0 8.8-7.2 16-16 16s-16-7.2-16-16c0-61.5-25.7-117.1-67-156.4-6.4-6.1-6.6-16.2-.5-22.6s16.2-6.6 22.6-.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellRing = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;