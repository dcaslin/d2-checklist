'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bahai';
var width = 512;
var height = 512;
var aliases = ["haykal"];
var unicode = 'f666';
var svgPathData = 'M256.4 8c6.6 0 12.5 4 14.9 10.2l38.5 99 93.1-51c5.8-3.2 12.9-2.5 18 1.8s7 11.1 4.9 17.4l-34.1 100.6 104.2 20.8c6.5 1.3 11.5 6.4 12.6 12.9s-1.8 13-7.5 16.5l-90.8 55.1 66.4 82.9c4.1 5.1 4.7 12.3 1.4 18s-9.8 8.8-16.3 7.8l-105-16.1-2.4 106.2c-.1 6.6-4.3 12.4-10.5 14.7s-13.1 .5-17.5-4.5l-70.1-79.8-70.1 79.8c-4.4 5-11.3 6.7-17.5 4.5s-10.4-8.1-10.5-14.7l-2.4-106.2-105 16.1c-6.5 1-13-2.1-16.3-7.8s-2.8-12.9 1.4-18l66.4-82.9-90.8-55.1c-5.6-3.4-8.6-10-7.5-16.5s6.2-11.6 12.6-12.9L121 185.9 86.9 85.3c-2.1-6.2-.2-13.2 4.9-17.4s12.2-4.9 18-1.8l93.1 51 38.5-99C243.8 12 249.8 8 256.4 8zm0 60.1l-30.2 77.7c-1.7 4.3-5.1 7.7-9.4 9.2s-9.1 1.2-13.2-1l-73.1-40.1 26.8 78.9c1.5 4.4 1 9.1-1.3 13.1s-6.2 6.8-10.7 7.7L63.4 230 134.7 273.2c3.9 2.4 6.7 6.4 7.5 10.9s-.4 9.2-3.3 12.8l-52.1 65 82.4-12.6c4.6-.7 9.2 .6 12.7 3.6s5.6 7.3 5.7 11.9l1.9 83.3 55-62.6c3-3.5 7.4-5.4 12-5.4s9 2 12 5.4l55 62.6 1.8-83.3c.1-4.6 2.2-8.9 5.7-11.9s8.2-4.3 12.7-3.6l82.4 12.6-52.1-65c-2.9-3.6-4.1-8.3-3.3-12.8s3.5-8.5 7.5-10.9l71.2-43.3-81.7-16.3c-4.5-.9-8.4-3.7-10.7-7.7s-2.8-8.8-1.3-13.1l26.8-78.9-73.1 40.1c-4 2.2-8.8 2.6-13.2 1s-7.8-4.9-9.4-9.2L256.4 68.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBahai = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;