'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'airplay-audio';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e77b';
var svgPathData = 'M32 256c0 57.5 21.7 109.9 57.3 149.6L71.4 423.4C69.8 425.1 68.3 426.7 66.8 428.5 25.3 383 0 322.4 0 256 0 114.6 114.6 0 256 0S512 114.6 512 256c0 66.4-25.3 127-66.8 172.5-1.5-1.7-3-3.4-4.6-5l-17.8-17.8C458.3 365.9 480 313.5 480 256 480 132.3 379.7 32 256 32S32 132.3 32 256zm384 0c0 39.8-14.5 76.2-38.6 104.2l-22.7-22.7C373 315.4 384 287 384 256 384 185.3 326.7 128 256 128S128 185.3 128 256c0 31 11 59.4 29.3 81.5l-22.7 22.7C110.5 332.2 96 295.8 96 256 96 167.6 167.6 96 256 96s160 71.6 160 160zm-96 0c0 13.3-4.1 25.6-11 35.9l-23.5-23.5c1.6-3.8 2.5-8 2.5-12.4 0-17.7-14.3-32-32-32s-32 14.3-32 32c0 4.4 .9 8.6 2.5 12.4L203 291.9c-6.9-10.2-11-22.6-11-35.9 0-35.3 28.7-64 64-64s64 28.7 64 64zM128 512c-12.9 0-24.6-7.8-29.6-19.8s-2.2-25.7 6.9-34.9l128-128c12.5-12.5 32.8-12.5 45.3 0l128 128c9.2 9.2 11.9 22.9 6.9 34.9S396.9 512 384 512l-256 0zm0-32l256 0-128-128-128 128z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAirplayAudio = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;