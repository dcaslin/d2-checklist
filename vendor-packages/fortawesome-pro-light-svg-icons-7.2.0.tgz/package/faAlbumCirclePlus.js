'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'album-circle-plus';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e48c';
var svgPathData = 'M416 64L96 64C78.3 64 64 78.3 64 96l0 320c0 17.7 14.3 32 32 32l150 0c2.9 11.1 6.7 21.8 11.4 32L96 480c-35.3 0-64-28.7-64-64L32 96c0-35.3 28.7-64 64-64l320 0c35.3 0 64 28.7 64 64l0 118c-10.4-2.7-21-4.5-32-5.4L448 96c0-17.7-14.3-32-32-32zM256 96c72.1 0 133.1 47.7 153.1 113.4-10.8 1.3-21.3 3.5-31.5 6.5-16.8-51-64.9-87.8-121.6-87.8-70.7 0-128 57.3-128 128 0 65.5 49.2 119.6 112.7 127.1-1 11.4-.9 22.4-.1 32.2-81.1-7.7-144.6-76.1-144.6-159.3 0-88.4 71.6-160 160-160zm0 136a24 24 0 1 1 0 48 24 24 0 1 1 0-48zM544 400a112 112 0 1 0 -224 0 112 112 0 1 0 224 0zm-256 0a144 144 0 1 1 288 0 144 144 0 1 1 -288 0zm160-64l0 48 48 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-48 0 0 48c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-48-48 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l48 0 0-48c0-8.8 7.2-16 16-16s16 7.2 16 16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlbumCirclePlus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;