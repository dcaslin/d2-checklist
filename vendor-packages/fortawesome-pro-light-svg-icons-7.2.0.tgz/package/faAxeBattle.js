'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'axe-battle';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f6b3';
var svgPathData = 'M509.3 154.7c-8.5 8.5-20.9 20.9-37.3 37.3 16.4 16.4 28.8 28.8 37.3 37.3-9 61.4-39.7 115.6-84.1 154.8-8.2 7.2-20.8 3.2-25.6-6.6-23.8-48.5-71.5-83.1-127.7-88.7L272 528c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-239.2c-56.2 5.6-103.8 40.2-127.7 88.7-4.8 9.8-17.4 13.8-25.6 6.6-53.2-46.9-86.8-115.6-86.8-192.1S33.6 46.8 86.8-.1c8.2-7.2 20.8-3.2 25.6 6.6 23.8 48.5 71.5 83.1 127.7 88.7L240 16c0-8.8 7.2-16 16-16s16 7.2 16 16l0 79.2c56.2-5.6 103.8-40.2 127.7-88.7 4.8-9.8 17.4-13.8 25.6-6.6 44.4 39.1 75.1 93.4 84.1 154.8zM240 127.3C178.1 122.2 124.6 87.8 93.3 38 55.3 78.2 32 132.4 32 192S55.3 305.8 93.3 346c31.3-49.8 84.8-84.2 146.7-89.3l0-129.3zm32 129.3c61.9 5.1 115.4 39.6 146.7 89.3 27.5-29.1 47.3-65.5 56.2-105.9l-25.5-25.5c-6-6-9.4-14.1-9.4-22.6s3.4-16.6 9.4-22.6l25.5-25.5c-8.8-40.4-28.6-76.8-56.2-105.9-31.3 49.8-84.8 84.2-146.7 89.3l0 129.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAxeBattle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;