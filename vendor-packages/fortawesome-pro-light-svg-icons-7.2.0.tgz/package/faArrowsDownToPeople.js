'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrows-down-to-people';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e4b9';
var svgPathData = 'M107.3 155.3l72-72c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L112 105.4 112-16c0-8.8-7.2-16-16-16S80-24.8 80-16l0 121.4-44.7-44.7c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l72 72c6.2 6.2 16.4 6.2 22.6 0zm320 0l72-72c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L432 105.4 432-16c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 121.4-44.7-44.7c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l72 72c6.2 6.2 16.4 6.2 22.6 0zM224 256a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm96 0a64 64 0 1 0 -128 0 64 64 0 1 0 128 0zm-64 96c-70.7 0-128 57.3-128 128l0 16c0 8.8 7.2 16 16 16s16-7.2 16-16l0-16c0-53 43-96 96-96s96 43 96 96l0 16c0 8.8 7.2 16 16 16s16-7.2 16-16l0-16c0-70.7-57.3-128-128-128zM96 256a24 24 0 1 1 0 48 24 24 0 1 1 0-48zm0 80a56 56 0 1 0 0-112 56 56 0 1 0 0 112zm320-80a24 24 0 1 1 0 48 24 24 0 1 1 0-48zm0 80a56 56 0 1 0 0-112 56 56 0 1 0 0 112zM96 384c-53 0-96 43-96 96l0 16c0 8.8 7.2 16 16 16s16-7.2 16-16l0-16c0-34 26.5-61.8 59.9-63.9 4.3-11 9.7-21.6 16-31.4-3.9-.5-7.9-.7-12-.7zm324.1 32.1C453.5 418.2 480 446 480 480l0 16c0 8.8 7.2 16 16 16s16-7.2 16-16l0-16c0-53-43-96-96-96-4.1 0-8.1 .3-12 .7 6.3 9.8 11.7 20.3 16 31.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsDownToPeople = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;