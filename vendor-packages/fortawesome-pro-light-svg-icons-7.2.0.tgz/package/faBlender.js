'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'blender';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f517';
var svgPathData = 'M0 48C0 21.5 21.5 0 48 0l72 0 0 .1c.8-.1 1.5-.1 2.3-.1L438.1 0c21.1 0 36.4 20.1 30.9 40.4L391.1 325.9c14.8 8.2 24.9 23.9 24.9 42.1l0 96c0 26.5-21.5 48-48 48l-224 0c-26.5 0-48-21.5-48-48l0-96c0-19.9 12.1-37 29.4-44.3L116.4 224 48 224c-26.5 0-48-21.5-48-48L0 48zM48 32c-8.8 0-16 7.2-16 16l0 128c0 8.8 7.2 16 16 16l65.5 0-14.5-160-50.9 0zm96 320c-8.8 0-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16l224 0c8.8 0 16-7.2 16-16l0-96c0-8.8-7.2-16-16-16l-224 0zM385.7 224L312 224c-8.8 0-16-7.2-16-16s7.2-16 16-16l82.5 0 17.5-64-99.9 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l108.6 0 17.5-64-307.1 0 26.2 288 202.3 0 26.2-96zM256 392a24 24 0 1 1 0 48 24 24 0 1 1 0-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlender = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;