'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrows-repeat-1';
var width = 512;
var height = 512;
var aliases = ["repeat-1-alt"];
var unicode = 'f366';
var svgPathData = 'M475.3 84.7c6.2 6.2 6.2 16.4 0 22.6l-96 96c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6L425.4 112 192 112c-88.4 0-160 71.6-160 160 0 8.8-7.2 16-16 16S0 280.8 0 272C0 166 86 80 192 80l233.4 0-68.7-68.7c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l96 96zM36.7 427.3c-6.2-6.2-6.2-16.4 0-22.6l96-96c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6L86.6 400 320 400c88.4 0 160-71.6 160-160 0-8.8 7.2-16 16-16s16 7.2 16 16c0 106-86 192-192 192l-233.4 0 68.7 68.7c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0l-96-96zM288 208l0 96c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-64-6.4 4.8c-7.1 5.3-17.1 3.9-22.4-3.2s-3.9-17.1 3.2-22.4l32-24c4.8-3.6 11.3-4.2 16.8-1.5s8.8 8.3 8.8 14.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsRepeat1 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;