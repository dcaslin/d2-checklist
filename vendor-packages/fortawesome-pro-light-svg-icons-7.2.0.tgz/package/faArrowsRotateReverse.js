'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrows-rotate-reverse';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e630';
var svgPathData = 'M479.5 241.1C476 188.8 454.3 137.6 414.4 97.6 370.7 53.9 313.4 32 256 32 194 32 134.8 57.5 92.2 102.6L53.1 144 160 144c8.8 0 16 7.2 16 16s-7.2 16-16 16L16 176c-8.8 0-16-7.2-16-16L0 16C0 7.2 7.2 0 16 0S32 7.2 32 16l0 103.8 37-39.1c48.6-51.5 116.3-80.6 187-80.6 65.5 0 131 25 181 75 45.6 45.6 70.5 104.3 74.4 164 .6 8.8-6.1 16.4-14.9 17s-16.4-6.1-17-14.9zm-447 29.9c3.5 52.3 25.2 103.5 65.1 143.4 43.7 43.7 101 65.6 158.4 65.6 62 0 121.2-25.5 163.8-70.6L458.9 368 352 368c-8.8 0-16-7.2-16-16s7.2-16 16-16l144 0c8.8 0 16 7.2 16 16l0 144c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-103.8-37 39.1c-48.6 51.5-116.3 80.6-187 80.6-65.5 0-131-25-181-75-45.6-45.6-70.4-104.3-74.4-164-.6-8.8 6.1-16.4 14.9-17s16.4 6.1 17 14.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsRotateReverse = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;