'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'badge-check';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f336';
var svgPathData = 'M256 0c36.1 0 68 18.1 87.1 45.6 33-6 68.4 3.8 93.9 29.3s35.3 60.9 29.3 93.9C493.9 188 512 219.9 512 256s-18.1 68-45.6 87.1c6 33-3.8 68.4-29.3 93.9s-60.9 35.3-93.9 29.3C324 493.9 292.1 512 256 512s-68-18.1-87.1-45.6c-33 6-68.4-3.8-93.9-29.3s-35.3-60.9-29.3-93.9C18.1 324 0 292.1 0 256s18.1-68 45.6-87.1c-6-33 3.8-68.4 29.3-93.9s60.9-35.3 93.9-29.3C188 18.1 219.9 0 256 0zm0 32c-28.3 0-53 15.9-65.4 39.4-3.6 6.8-11.5 10-18.8 7.8-25.4-7.8-54.1-1.6-74.2 18.4s-26.2 48.8-18.4 74.2c2.2 7.3-1 15.2-7.8 18.8-23.5 12.4-39.4 37.1-39.4 65.4s15.9 53 39.4 65.4c6.8 3.6 10 11.5 7.8 18.8-7.8 25.4-1.6 54.1 18.4 74.2s48.8 26.2 74.2 18.4c7.3-2.2 15.2 1 18.8 7.8 12.4 23.5 37.1 39.4 65.4 39.4s53-15.9 65.4-39.4c3.6-6.8 11.5-10 18.8-7.8 25.4 7.8 54.1 1.6 74.2-18.4s26.2-48.7 18.4-74.1c-2.3-7.3 1-15.2 7.8-18.8 23.5-12.4 39.4-37.1 39.4-65.4s-15.9-53-39.4-65.4c-6.8-3.6-10-11.5-7.8-18.8 7.8-25.4 1.6-54.1-18.4-74.1s-48.8-26.2-74.2-18.4c-7.3 2.2-15.2-1-18.8-7.8-12.4-23.5-37.1-39.4-65.4-39.4zm67.1 138.2c5.2-7.1 15.2-8.7 22.3-3.5s8.7 15.2 3.5 22.3L243.3 334.2c-2.8 3.8-7.1 6.2-11.8 6.5s-9.3-1.4-12.6-4.8l-54.4-56.3c-6.1-6.4-6-16.5 .4-22.6s16.5-5.9 22.6 .4l41.2 42.6 94.4-129.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBadgeCheck = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;