'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-rotate-right-15';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e888';
var svgPathData = 'M496 0c8.8 0 16 7.2 16 16l0 144c0 6.6-4 12.5-10.1 14.9s-13 .9-17.5-3.9l-64.6-68.4C377.2 57.5 318 32 256 32 132.3 32 32 132.3 32 256S132.3 480 256 480c85.9 0 160.6-48.4 198.2-119.5 4.1-7.8 13.8-10.8 21.6-6.7 7.8 4.1 10.8 13.8 6.7 21.6-42.9 81.2-128.2 136.5-226.5 136.5-141.4 0-256-114.6-256-256S114.6 0 256 0c70.8 0 138.4 29.2 187 80.6l37 39.1 0-103.8c0-8.8 7.2-16 16-16zM184.8 161.7c5-2.5 10.8-2.2 15.6 .7s7.6 8.1 7.6 13.6l0 160c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-134.1-24.8 12.4c-7.9 4-17.5 .7-21.5-7.2s-.7-17.5 7.2-21.5l48-24zM344 160c8.8 0 16 7.2 16 16s-7.2 16-16 16l-72 0 0 48 40 0c30.9 0 56 25.1 56 56s-25.1 56-56 56l-56 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l56 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-56 0c-8.8 0-16-7.2-16-16l0-80c0-8.8 7.2-16 16-16l88 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateRight15 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;