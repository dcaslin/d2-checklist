'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bomb';
var width = 576;
var height = 512;
var aliases = [128163];
var unicode = 'f1e2';
var svgPathData = 'M480-8c-8.8 0-16 7.2-16 16l0 40-40 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l40 0 0 40c0 8.8 7.2 16 16 16s16-7.2 16-16l0-40 40 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-40 0 0-40c0-8.8-7.2-16-16-16zM358 95.4c-12-12-31.2-12.5-43.9-1.3 10.6 12 10.6 12 0 0l-12.6 11.2c-19.5-6-40.1-9.2-61.5-9.2-114.9 0-208 93.1-208 208s93.1 208 208 208 208-93.1 208-208c0-22.1-3.5-43.5-9.9-63.5l9.9-9.9c12.5-12.5 12.5-32.8 0-45.3l-33.4-33.4 12.7-12.7c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0l-12.7 12.7-34-34zm-42.1 40l19.5-17.3 90 90-17 17c-4.4 4.4-5.9 11.1-3.7 17 7.3 19.3 11.3 40.2 11.3 62.1 0 97.2-78.8 176-176 176S64 401.2 64 304 142.8 128 240 128c21 0 41.1 3.7 59.8 10.4 5.5 2 11.7 .8 16.1-3.1zM144 304c0-53 43-96 96-96 8.8 0 16-7.2 16-16s-7.2-16-16-16c-70.7 0-128 57.3-128 128 0 8.8 7.2 16 16 16s16-7.2 16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBomb = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;