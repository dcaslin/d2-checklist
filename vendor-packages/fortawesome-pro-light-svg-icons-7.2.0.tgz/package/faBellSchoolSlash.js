'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bell-school-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f5d6';
var svgPathData = 'M27.3-27.2c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l544 544c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6l-59.2-59.2C522.2 440.7 528 421 528 400l0-2.7c18.6-6.6 32-24.4 32-45.3 0-26.5-21.5-48-48-48s-48 21.5-48 48c0 20.9 13.4 38.7 32 45.3l0 2.7c0 12.1-2.7 23.6-7.5 33.9l-74.2-74.2C454.7 321.8 480 267.8 480 208 480 93.1 386.9 0 272 0 212.2 0 158.2 25.3 120.3 65.7l-93-93zM142.9 88.4c32.1-34.7 78.1-56.4 129.1-56.4 97.2 0 176 78.8 176 176 0 51-21.7 97-56.4 129.1l-68-68c17.3-14.7 28.4-36.6 28.4-61.1 0-44.2-35.8-80-80-80-24.5 0-46.4 11-61.1 28.4l-68-68zm158 158l-67.2-67.2c8.8-11.6 22.7-19.1 38.3-19.1 26.5 0 48 21.5 48 48 0 15.7-7.5 29.6-19.1 38.3zM512 336a16 16 0 1 1 0 32 16 16 0 1 1 0-32zM77 135.5c-8.4 22.6-13 47-13 72.5 0 114.9 93.1 208 208 208 25.5 0 49.9-4.6 72.5-13l-25.4-25.4c-15 4.2-30.8 6.4-47.1 6.4-97.2 0-176-78.8-176-176 0-16.3 2.2-32.1 6.4-47.1L77 135.5zM416 480c1.8 0 3.6-.1 5.3-.2l27.3 27.3c-10.3 3.1-21.3 4.8-32.7 4.8l-224 0c-35.3 0-64-28.7-64-64l0-28.3c10.2 6.9 20.9 13.1 32 18.6l0 9.7c0 17.7 14.3 32 32 32l224 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellSchoolSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;