'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bell-plus';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f849';
var svgPathData = 'M208 16c0-8.8 7.2-16 16-16s16 7.2 16 16l0 16.8c80.9 8 144 76.2 144 159.2l0 10.3c0 45.1 15.4 88.9 43.5 124.1L437.6 339c6.7 8.4 10.4 18.8 10.4 29.6 0 26.2-21.2 47.4-47.4 47.4L47.4 416C21.2 416 0 394.8 0 368.6 0 357.9 3.7 347.4 10.4 339l10.1-12.6C48.6 291.2 64 247.4 64 202.3L64 192c0-83 63.1-151.2 144-159.2L208 16zM96 192l0 10.3c0 52.4-17.8 103.2-50.6 144.1L35.4 359c-2.2 2.7-3.4 6.1-3.4 9.6 0 8.5 6.9 15.4 15.4 15.4l353.2 0c8.5 0 15.4-6.9 15.4-15.4 0-3.5-1.2-6.9-3.4-9.6l-10.1-12.6C369.8 305.5 352 254.7 352 202.3l0-10.3c0-70.7-57.3-128-128-128S96 121.3 96 192zM224 512c-31.3 0-58-20-67.9-48l35.9 0c7.3 9.7 18.9 16 32 16s24.7-6.3 32-16l35.9 0c-9.9 28-36.6 48-67.9 48zM208 296l0-56-56 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l56 0 0-56c0-8.8 7.2-16 16-16s16 7.2 16 16l0 56 56 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-56 0 0 56c0 8.8-7.2 16-16 16s-16-7.2-16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellPlus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;