'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrows-to-eye';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e4bf';
var svgPathData = 'M0 144c0 8.8 7.2 16 16 16l96 0c8.8 0 16-7.2 16-16l0-96c0-8.8-7.2-16-16-16S96 39.2 96 48l0 57.4-68.7-68.7c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6L73.4 128 16 128c-8.8 0-16 7.2-16 16zm186.7 61.2C210.2 178 244.2 152 288 152s77.8 26 101.3 53.2c13.6 15.7 25.4 33 33.8 50.8-8.4 17.8-20.3 35.1-33.8 50.8-23.6 27.3-57.5 53.2-101.3 53.2s-77.8-26-101.3-53.2c-13.6-15.7-25.4-33-33.8-50.8 8.4-17.8 20.3-35.1 33.8-50.8zM413.6 327.7c16-18.5 30.3-39.5 40.4-62 2.7-6.2 2.7-13.3 0-19.5-10-22.4-24.4-43.5-40.4-62-26.2-30.3-68.2-64.3-125.6-64.3s-99.4 34-125.6 64.3c-16 18.5-30.3 39.5-40.4 62-2.7 6.2-2.7 13.3 0 19.5 10 22.4 24.4 43.5 40.4 62 26.2 30.3 68.2 64.3 125.6 64.3s99.4-34 125.6-64.3zM16 352c-8.8 0-16 7.2-16 16s7.2 16 16 16l57.4 0-68.7 68.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L96 406.6 96 464c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96c0-8.8-7.2-16-16-16l-96 0zm544 32c8.8 0 16-7.2 16-16s-7.2-16-16-16l-96 0c-8.8 0-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16s16-7.2 16-16l0-57.4 68.7 68.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L502.6 384 560 384zm16-240c0-8.8-7.2-16-16-16l-57.4 0 68.7-68.7c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0L480 105.4 480 48c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16l96 0c8.8 0 16-7.2 16-16zM256 256a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm96 0a64 64 0 1 0 -128 0 64 64 0 1 0 128 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsToEye = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;