'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'boombox';
var width = 576;
var height = 512;
var aliases = [128254];
var unicode = 'f8a5';
var svgPathData = 'M64 88l0 72 96 0 0-16c0-8.8 7.2-16 16-16s16 7.2 16 16l0 16 80 0 0-16c0-8.8 7.2-16 16-16s16 7.2 16 16l0 16 80 0 0-16c0-8.8 7.2-16 16-16s16 7.2 16 16l0 16 96 0 0-72c0-30.9-25.1-56-56-56L120 32C89.1 32 64 57.1 64 88zM32 168.6L32 88C32 39.4 71.4 0 120 0L456 0c48.6 0 88 39.4 88 88l0 80.6c19.1 11.1 32 31.7 32 55.4l0 192c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 224c0-23.7 12.9-44.4 32-55.4zM176 192L64 192c-17.7 0-32 14.3-32 32l0 192c0 17.7 14.3 32 32 32l448 0c17.7 0 32-14.3 32-32l0-192c0-17.7-14.3-32-32-32l-336 0zm0 176a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm0-128a80 80 0 1 1 0 160 80 80 0 1 1 0-160zm272 80a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm-128 0a80 80 0 1 1 160 0 80 80 0 1 1 -160 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoombox = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;