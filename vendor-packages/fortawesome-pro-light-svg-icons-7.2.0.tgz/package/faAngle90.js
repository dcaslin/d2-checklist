'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'angle-90';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e08d';
var svgPathData = 'M32 48c0-8.8-7.2-16-16-16S0 39.2 0 48L0 416c0 35.3 28.7 64 64 64l368 0c8.8 0 16-7.2 16-16s-7.2-16-16-16L64 448c-17.7 0-32-14.3-32-32L32 48zm143 99.5c7.5 3 16.2 .4 20.5-6.5 5.1-8.2 1.9-19-7-22.6-33.7-13.6-70.2-21.4-108.5-22.4l0 32c33.5 .9 65.5 7.7 95 19.4zm163.9 137c-6.9 4.3-9.4 13-6.5 20.5 11.7 29.5 18.5 61.5 19.4 95l32 0c-1-38.3-8.8-74.8-22.4-108.5-3.6-9-14.4-12.1-22.6-7zM316.4 242c7.7-4.8 9.9-15.1 4.4-22.3-17.3-22.8-37.6-43.2-60.4-60.4-7.2-5.5-17.5-3.3-22.3 4.4-4.6 7.3-2.5 16.8 4.3 22.1 19.5 15 37 32.5 52 52 5.2 6.8 14.8 8.9 22.1 4.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAngle90 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;