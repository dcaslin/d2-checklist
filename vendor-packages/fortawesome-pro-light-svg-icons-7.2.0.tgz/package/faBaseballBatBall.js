'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'baseball-bat-ball';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f432';
var svgPathData = 'M496.1 544a80 80 0 1 1 0-160 80 80 0 1 1 0 160zM512.4-48c14.2 0 27.8 5.5 38.1 15.2l58.8 55.8 4.4 4.7c8.2 9.9 12.6 22.4 12.4 35.2l-.5 6.4c-1.6 11.7-7 22.7-15.3 31L403.7 307c-4.8 4.8-10.1 9.2-15.8 13.1l-5.8 3.7-139.7 83.8c-5.6 3.4-10.8 7.4-15.4 12L126.2 520.5c3.2 6 2.3 13.7-2.8 18.8-5.5 5.5-13.9 6.2-20.1 2.1l-2.5-2.1-64-64-2.1-2.5c-4.1-6.2-3.4-14.7 2.1-20.1 5.1-5.1 12.7-6 18.8-2.8L156.4 349c4.6-4.6 8.7-9.8 12-15.4l83.8-139.7c4.7-7.8 10.4-15.1 16.8-21.6l204.1-204.1 4.1-3.7c9.8-8.1 22.3-12.5 35.1-12.5zM496.1 416a48 48 0 1 0 0 96 48 48 0 1 0 0-96zM78.7 472l25.4 25.4 89.4-89.4-25.4-25.4-89.4 89.4zM512.4-16c-4.6 0-9.2 1.4-13 3.9L495.9-9.2 291.7 195c-4.6 4.6-8.7 9.8-12 15.4L195.9 350.1c-1.9 3.1-3.9 6.1-6.1 9L217 386.2c2.9-2.2 5.9-4.2 9-6.1l139.7-83.8 4.1-2.7c4-2.8 7.8-5.9 11.3-9.4L587.7 77.8c3.4-3.4 5.6-7.9 6.2-12.7l.2-2.6c.1-5.2-1.7-10.3-5.1-14.3l-1.8-1.9-58.8-55.8c-4.3-4.1-10.1-6.4-16.1-6.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBaseballBatBall = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;