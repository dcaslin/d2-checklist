'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'binary-lock';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e33d';
var svgPathData = 'M384 16c0-4.9-2.3-9.6-6.2-12.6S368.9-.7 364.1 .5l-64 16c-8.6 2.1-13.8 10.8-11.6 19.4s10.8 13.8 19.4 11.6l44.1-11 0 155.5-48 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l60.1 0c10.4-13 23.3-23.9 37.9-32l-18 0 0-176zM320 288c-35.3 0-64 28.7-64 64l0 96c0 30.2 20.9 55.5 49.1 62.2-.7-4.7-1.1-9.5-1.1-14.3l0-20.2c-9.6-5.5-16-15.9-16-27.7l0-96c0-17.7 14.3-32 32-32l16 0 0-16c0-5.4 .3-10.8 1-16l-17 0zM160 304c0-4.9-2.3-9.6-6.2-12.6s-8.9-4.1-13.7-2.9l-64 16c-8.6 2.1-13.8 10.8-11.6 19.4s10.8 13.8 19.4 11.6l44.1-11 0 155.5-48 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l128 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-48 0 0-176zM64 64l0 96c0 35.3 28.7 64 64 64l64 0c35.3 0 64-28.7 64-64l0-96c0-35.3-28.7-64-64-64L128 0C92.7 0 64 28.7 64 64zm64-32l64 0c17.7 0 32 14.3 32 32l0 96c0 17.7-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32l0-96c0-17.7 14.3-32 32-32zM384 352.1l0 2.6c-18.6 6.6-32 24.4-32 45.3l0 96c0 26.5 21.5 48 48 48l128 0c26.5 0 48-21.5 48-48l0-96c0-20.9-13.4-38.7-32-45.3l0-50.6c0-44.2-35.8-80-80-80s-80 35.8-80 80l0 48zm0 47.9c0-8.2 6.2-15 14.3-15.9l131.5 0c8 .9 14.3 7.7 14.3 15.9l0 96c0 8.8-7.2 16-16 16l-128 0c-8.8 0-16-7.2-16-16l0-96zm128-95.9l0 47.9-96 0 0-47.9c0-26.5 21.5-48 48-48s48 21.5 48 48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinaryLock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;