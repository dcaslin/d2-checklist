'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-open';
var width = 512;
var height = 512;
var aliases = [128214,128366];
var unicode = 'f518';
var svgPathData = 'M240 100l-21.4-8.9C175.7 73.2 129.7 64 83.2 64L48 64c-8.8 0-16 7.2-16 16l0 352c0 8.8 7.2 16 16 16l35.2 0c53.8 0 107 10.4 156.8 30.7L240 100zm32 378.7C321.8 458.4 375 448 428.8 448l35.2 0c8.8 0 16-7.2 16-16l0-352c0-8.8-7.2-16-16-16l-35.2 0c-46.5 0-92.5 9.2-135.4 27.1L272 100 272 478.7zM230.9 61.5L256 72 281.1 61.5C327.9 42 378.1 32 428.8 32L464 32c26.5 0 48 21.5 48 48l0 352c0 26.5-21.5 48-48 48l-35.2 0c-50.7 0-100.9 10-147.7 29.5l-12.8 5.3c-7.9 3.3-16.7 3.3-24.6 0l-12.8-5.3C184.1 490 133.9 480 83.2 480L48 480c-26.5 0-48-21.5-48-48L0 80C0 53.5 21.5 32 48 32l35.2 0c50.7 0 100.9 10 147.7 29.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookOpen = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;