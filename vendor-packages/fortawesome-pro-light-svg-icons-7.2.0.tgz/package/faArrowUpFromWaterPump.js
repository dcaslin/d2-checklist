'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-up-from-water-pump';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4b6';
var svgPathData = 'M491.3 36.7c-6.2-6.2-16.4-6.2-22.6 0l-96 96c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0l68.7-68.7 0 169.4-144 0 0-176c0-26.5-21.5-48-48-48L144 32c-26.5 0-48 21.5-48 48l0 176-16 0c-26.5 0-48 21.5-48 48l0 105.1c7.4 1.9 14.6 5.2 21.2 9.9 3.1 2.2 5.4 3.2 6.9 3.7 1.3 .4 2.6 .6 4 .7L64 304c0-8.8 7.2-16 16-16l480 0c8.8 0 16 7.2 16 16l0 119.4c.9 0 1.7-.1 2.4-.3 1.5-.3 4.3-1.2 8.4-4.1 6.6-4.7 13.8-8 21.2-9.9L608 304c0-26.5-21.5-48-48-48l-64 0 0-169.4 68.7 68.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6l-96-96zM144 64l128 0c8.8 0 16 7.2 16 16l0 176-160 0 0-176c0-8.8 7.2-16 16-16zM489.1 469.9c19.7 14.1 42.4 26.9 67 31.6 25.2 4.8 51.7 .9 77.2-17.4 7.2-5.1 8.9-15.1 3.7-22.3s-15.1-8.9-22.3-3.7c-18 12.8-35.4 15.3-52.6 12-17.9-3.4-36.2-13.2-54.4-26.2-37.1-26.5-87.1-26.5-124.3 0-25.3 18.1-45.3 28.1-63.5 28.1s-38.1-10.1-63.5-28.1c-37.1-26.5-87.1-26.5-124.3 0-23.2 16.5-46.1 27.7-68.2 27.5-12.5-.1-25.4-3.7-38.8-13.3-7.2-5.1-17.2-3.5-22.3 3.7S-.5 479 6.7 484.1c18.7 13.3 38 19.2 57.2 19.3 32.4 .2 62.2-15.8 86.9-33.5 26-18.6 61.1-18.6 87.1 0 25.6 18.3 52.9 34.1 82 34.1s56.4-15.8 82-34.1c26-18.6 61.1-18.6 87.1 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpFromWaterPump = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;