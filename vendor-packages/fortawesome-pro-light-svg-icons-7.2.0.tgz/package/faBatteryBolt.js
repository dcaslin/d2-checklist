'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'battery-bolt';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f376';
var svgPathData = 'M296 299.4l-37 97.2 159.8-140.6-76.9 0c-10.5 0-20.4-5.2-26.4-13.8s-7.3-19.7-3.6-29.6l37-97.2-159.8 140.6 76.9 0c10.5 0 20.4 5.2 26.3 13.8s7.3 19.7 3.6 29.5zM440 224c10 0 18.9 6.2 22.5 15.5s.9 19.9-6.6 26.5l-200 176c-8.3 7.3-20.5 8-29.5 1.7s-12.7-18-8.7-28.3C245.8 341.2 262 298.8 266.1 288L168 288c-10 0-18.9-6.2-22.5-15.5s-.9-19.9 6.6-26.5l200-176c8.3-7.3 20.5-8 29.5-1.7s12.7 18 8.7 28.3C362.2 170.8 346 213.2 341.9 224l98.1 0zm-.4-128c1.2-10.9-.1-21.8-3.7-32L496 64c44.2 0 80 35.8 80 80l0 32 32 0c17.7 0 32 14.3 32 32l0 96c0 17.7-14.3 32-32 32l-32 0 0 32c0 44.2-35.8 80-80 80l-174.3 0 36.4-32 137.9 0c26.5 0 48-21.5 48-48l0-224c0-26.5-21.5-48-48-48l-56.4 0zM112 448c-44.2 0-80-35.8-80-80l0-224c0-44.2 35.8-80 80-80l174.3 0-36.4 32-137.9 0c-26.5 0-48 21.5-48 48l0 224c0 26.5 21.5 48 48 48l56.4 0c-1.2 10.9 .1 21.8 3.7 32L112 448zM576 208l0 96 32 0 0-96-32 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBatteryBolt = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;