'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'anchor-lock';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4ad';
var svgPathData = 'M336 80a48 48 0 1 1 -96 0 48 48 0 1 1 96 0zM288 0c-44.2 0-80 35.8-80 80 0 38.7 27.5 71 64 78.4l0 304.8c-80.9-8-144-76.2-144-159.2l0-28.7 37.5 32.8c6.7 5.8 16.8 5.1 22.6-1.5s5.1-16.8-1.5-22.6l-64-56c-6-5.3-15-5.3-21.1 0l-64 56c-6.7 5.8-7.3 15.9-1.5 22.6s15.9 7.3 22.6 1.5L96 275.3 96 304c0 106 86 192 192 192 28.6 0 55.6-6.2 80-17.4l0-36c-19.2 11.1-40.9 18.3-64 20.6l0-304.8c36.5-7.4 64-39.7 64-78.4 0-44.2-35.8-80-80-80zM448 352.1l0 2.6c-18.6 6.6-32 24.4-32 45.3l0 96c0 26.5 21.5 48 48 48l128 0c26.5 0 48-21.5 48-48l0-96c0-20.9-13.4-38.7-32-45.3l0-50.6c0-44.2-35.8-80-80-80s-80 35.8-80 80l0 48zm0 47.9c0-8.2 6.2-15 14.3-15.9l131.5 0c8 .9 14.3 7.7 14.3 15.9l0 96c0 8.8-7.2 16-16 16l-128 0c-8.8 0-16-7.2-16-16l0-96zm128-95.9l0 47.9-96 0 0-47.9c0-26.5 21.5-48 48-48s48 21.5 48 48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAnchorLock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;