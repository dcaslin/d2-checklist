'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bolt-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0b8';
var svgPathData = 'M27.3-27.3c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l544 544c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6l-161-161 90.2-75.1c10.3-8.6 14.2-22.8 9.6-35.5S493.5 224 480 224l-144.7 0 12.8-32 65.6-164.1c5.4-13.6 .9-29.2-10.9-37.8s-28-8.1-39.3 1.3l-173.2 144.3-163-163zM213.1 158.4L384 16 305.6 212.1c-3.9 9.9-2.7 21 3.2 29.8S324.6 256 335.3 256l144.7 0-92.4 77-174.5-174.5zm-137.6 73c-10.4 8.6-14.2 22.8-9.6 35.5S82.5 288 96 288l133.6 0-32-32-101.6 0 55.4-46.2-22.7-22.7-53.2 44.3zM192 496l70.2-175.4-24.6-24.6-9.6 24-65.6 164.1c-5.4 13.6-.9 29.2 10.9 37.8s28 8.1 39.3-1.3L348.7 407.1 326 384.4 192 496z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoltSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;