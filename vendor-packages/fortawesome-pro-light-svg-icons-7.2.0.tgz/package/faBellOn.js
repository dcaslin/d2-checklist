'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bell-on';
var width = 640;
var height = 512;
var aliases = [128365];
var unicode = 'f8fa';
var svgPathData = 'M606.3 8.8c-4-7.9-13.6-11.1-21.5-7.2l-64 32c-7.9 4-11.1 13.6-7.2 21.5s13.6 11.1 21.5 7.2l64-32c7.9-4 11.1-13.6 7.2-21.5zM320 0c-8.8 0-16 7.2-16 16l0 16.8C223.1 40.8 160 109 160 192l0 10.3c0 45.1-15.4 88.9-43.5 124.1L106.4 339c-6.7 8.4-10.4 18.8-10.4 29.6 0 26.2 21.2 47.4 47.4 47.4l353.2 0c26.2 0 47.4-21.2 47.4-47.4 0-10.8-3.7-21.2-10.4-29.6l-10.1-12.6c-28.2-35.2-43.5-79-43.5-124.1l0-10.3c0-83-63.1-151.2-144-159.2L336 16c0-8.8-7.2-16-16-16zm0 64c70.7 0 128 57.3 128 128l0 10.3c0 52.4 17.8 103.2 50.6 144.1L508.6 359c2.2 2.7 3.4 6.1 3.4 9.6 0 8.5-6.9 15.4-15.4 15.4l-353.2 0c-8.5 0-15.4-6.9-15.4-15.4 0-3.5 1.2-6.9 3.4-9.6l10.1-12.6c32.7-40.9 50.6-91.7 50.6-144.1l0-10.3c0-70.7 57.3-128 128-128zM252.1 464c9.9 28 36.6 48 67.9 48s58-20 67.9-48L352 464c-7.3 9.7-18.9 16-32 16s-24.7-6.3-32-16l-35.9 0zM0 176c0 8.8 7.2 16 16 16l80 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-80 0c-8.8 0-16 7.2-16 16zm544-16c-8.8 0-16 7.2-16 16s7.2 16 16 16l80 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-80 0zM40.8 30.3l64 32c7.9 4 17.5 .7 21.5-7.2s.7-17.5-7.2-21.5l-64-32c-7.9-4-17.5-.7-21.5 7.2s-.7 17.5 7.2 21.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellOn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;