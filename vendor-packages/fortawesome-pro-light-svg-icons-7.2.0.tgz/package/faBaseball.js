'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'baseball';
var width = 512;
var height = 512;
var aliases = [129358,9918,"baseball-ball"];
var unicode = 'f433';
var svgPathData = 'M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM270 32.5c-1.3 11.1-3.2 22-5.8 32.6-2.1 8.6-10.8 13.8-19.3 11.7S231 66.1 233.1 57.5c2-8.1 3.4-16.3 4.6-24.7-109.1 8.8-196 95.8-204.9 204.9 8.4-1.1 16.6-2.6 24.7-4.6 8.6-2.1 17.2 3.1 19.3 11.7S73.7 262 65.1 264.2c-10.6 2.6-21.5 4.5-32.6 5.8 6.9 112.5 96.9 202.5 209.5 209.5 1.3-11.1 3.3-22 5.9-32.6 2.1-8.6 10.8-13.8 19.3-11.7s13.8 10.8 11.7 19.3c-2 8.1-3.5 16.3-4.6 24.7 109.1-8.8 196.1-95.8 204.9-204.9-8.4 1.1-16.6 2.6-24.7 4.6-8.6 2.1-17.2-3.1-19.3-11.7s3.1-17.2 11.7-19.3c10.6-2.6 21.5-4.6 32.6-5.9-7-112.5-97-202.5-209.5-209.5zm36.6 355.4c-4.6 7.6-14.4 10-22 5.4s-10-14.4-5.4-22l27.4 16.6zm64.7-108.7c7.6-4.6 17.4-2.1 22 5.4s2.2 17.4-5.4 22c-33.2 20.1-61.2 48.1-81.3 81.3-9.1-5.5-18.3-11.1-27.4-16.6 22.8-37.6 54.4-69.3 92.1-92.1zM140.8 232.8c-7.6 4.6-17.4 2.1-22-5.4s-2.2-17.4 5.4-22l16.6 27.4zm64.7-108.7c4.6-7.6 14.4-10 22-5.4s10 14.4 5.4 22c-22.8 37.6-54.4 69.3-92.1 92.1-5.5-9.1-11-18.3-16.6-27.4 33.2-20.1 61.2-48.1 81.3-81.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBaseball = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;