'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bat';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f6b5';
var svgPathData = 'M216.6 49.8c4.6-2.4 10-2.4 14.6-.1l56.8 28.4 56.8-28.4 3.6-1.3c3.7-.8 7.6-.4 11 1.4 4.6 2.4 7.7 6.9 8.4 11.9l12.4 86.8 46.6-31.1c22.9-15.2 53.5-11 71.4 9.9 50.2 58.5 77.7 133.1 77.7 210.1l0 20.2c0 20.3-21.4 33.5-39.5 24.4l-51.7-25.8-28.9 38.6c-11.7 15.6-34.4 17.2-48.2 3.4l-37.6-37.6-56 78.4c-12 16.8-36.1 17.8-49.5 3.2l-2.5-3.2-56-78.4-37.6 37.6c-12.9 12.9-33.7 12.3-45.9-.7l-2.3-2.7-28.9-38.6-51.7 25.8C21.4 391.2 0 378 0 357.7l0-20.2c0-77.1 27.6-151.6 77.7-210.1l3.5-3.7c18.2-17.6 46.5-20.4 67.9-6.2l46.6 31.1 12.4-86.8 1-3.7c1.4-3.5 4-6.5 7.4-8.2zm78.6 60.5c-3.4 1.7-7.2 2.1-10.8 1.3l-3.5-1.3-44.2-22.1-12.8 90c-.8 5.4-4.3 10.1-9.3 12.3s-10.8 1.8-15.4-1.3l-67.7-45.2c-9.4-6.3-22-4.5-29.4 4.1-45.2 52.7-70 119.9-70 189.3l0 12.6 44.9-22.4 2.6-1.2c13.3-5.2 28.6-1 37.3 10.6l28.9 38.6 37.6-37.6c14-14 37.2-12 48.7 4l56 78.4 56-78.4c11.5-16.1 34.7-18 48.7-4l37.6 37.6 28.9-38.6c9.3-12.4 26.1-16.3 39.9-9.4l44.9 22.4 0-12.6c0-69.4-24.8-136.6-70-189.3-7.4-8.6-20-10.3-29.4-4.1l-67.7 45.2c-4.6 3-10.4 3.5-15.4 1.3s-8.5-6.9-9.3-12.3l-12.9-90-44.1 22.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBat = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;