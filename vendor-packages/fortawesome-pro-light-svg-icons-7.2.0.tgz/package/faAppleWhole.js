'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'apple-whole';
var width = 448;
var height = 512;
var aliases = [127822,127823,"apple-alt"];
var unicode = 'f5d1';
var svgPathData = 'M228.6 96l-4.6 0 0-4.6C224 58.6 250.6 32 283.4 32l4.6 0 0 4.6C288 69.4 261.4 96 228.6 96zm-18.3 32l18.3 0c50.5 0 91.4-40.9 91.4-91.4l0-18.3C320 8.2 311.8 0 301.7 0L283.4 0C232.9 0 192 40.9 192 91.4l0 18.3c0 10.1 8.2 18.3 18.3 18.3zM32 288c0-33.8 8-67.7 22.8-92 14.2-23.5 33-36 57.2-36 21 0 48.7 8.4 71.1 17.1 26.2 10.2 55.6 10.2 81.9 0 22.4-8.7 50.1-17.1 71.1-17.1 24.3 0 43 12.5 57.2 36 14.7 24.3 22.8 58.2 22.8 92 0 57.5-18 106.6-43.6 140.8-26 34.7-57.4 51.2-84.4 51.2-13.2 0-32-2.7-45.3-5-12.3-2.2-25-2.2-37.3 0-13.3 2.3-32.1 5-45.3 5-27 0-58.4-16.5-84.4-51.2-25.6-34.2-43.6-83.3-43.6-140.8zM160 512c16.2 0 37.4-3.2 50.8-5.5 8.7-1.5 17.6-1.5 26.3 0 13.5 2.4 34.6 5.5 50.8 5.5 80 0 160-96 160-224 0-76.3-35.7-160-112-160-27.3 0-59.7 10.3-82.7 19.3-18.8 7.3-39.9 7.3-58.7 0-22.9-8.9-55.4-19.3-82.7-19.3-76.3 0-112 83.7-112 160 0 128 80 224 160 224z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAppleWhole = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;