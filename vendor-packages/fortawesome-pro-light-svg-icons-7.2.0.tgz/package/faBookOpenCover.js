'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-open-cover';
var width = 576;
var height = 512;
var aliases = ["book-open-alt"];
var unicode = 'e0c0';
var svgPathData = 'M304 100.3l44.1-15.8c38-13.6 78-20.5 118.4-20.5L528 64c8.8 0 16 7.2 16 16l0 288c0 8.8-7.2 16-16 16l-37.4 0c-64.6 0-128.3 15-186 43.9l-.6 .3 0-328zm-32 328l-.6-.3C213.6 399 149.9 384 85.3 384L48 384c-8.8 0-16-7.2-16-16L32 80c0-8.8 7.2-16 16-16l61.5 0c40.3 0 80.4 6.9 118.4 20.5l44.1 15.8 0 328zM288 72L238.6 54.4C197.2 39.6 153.5 32 109.5 32L48 32C21.5 32 0 53.5 0 80L0 368c0 26.5 21.5 48 48 48l37.3 0c59.6 0 118.4 13.9 171.7 40.5l16.6 8.3c9 4.5 19.6 4.5 28.6 0l16.6-8.3C372.2 429.9 431 416 490.6 416l37.4 0c26.5 0 48-21.5 48-48l0-288c0-26.5-21.5-48-48-48l-61.5 0c-44 0-87.7 7.6-129.2 22.4L288 72zM0 480c0 8.8 7.2 16 16 16l65.7 0c39.6 0 78.8 6.4 116.4 18.9l73.3 24.4c11.2 3.7 23.3 3.2 34.1-1.4l28.4-12.2c45.8-19.6 95.1-29.8 145-29.8l81.2 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-81.2 0c-54.2 0-107.8 11-157.6 32.3l-28.4 12.2c-3.6 1.5-7.6 1.7-11.4 .5l-73.3-24.4C167.4 470.9 124.7 464 81.7 464L16 464c-8.8 0-16 7.2-16 16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookOpenCover = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;