'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'blender-phone';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f6b6';
var svgPathData = 'M534.6 32l-307.1 0 26.2 288 202.3 0 26.2-96-73.7 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l82.5 0 17.5-64-99.9 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l108.6 0 17.5-64zM221.9 323.7l-27-297.6C193.6 12.1 204.6 0 218.8 0L534.6 0c21.1 0 36.4 20.1 30.9 40.4L487.6 325.9c14.8 8.2 24.9 23.9 24.9 42.1l0 96c0 26.5-21.5 48-48 48l-224 0c-26.5 0-48-21.5-48-48l0-96c0-19.9 12.1-37 29.4-44.3zM240.5 352c-8.8 0-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16l224 0c8.8 0 16-7.2 16-16l0-96c0-8.8-7.2-16-16-16l-224 0zm88 64a24 24 0 1 1 48 0 24 24 0 1 1 -48 0zM131.1 39.1l-2-.9c-20.3-9-44.5-4.8-56.9 13.3-46.2 67.3-46.2 156.8 0 224.1 12.5 18.1 36.6 22.3 56.9 13.3l2-.9c7.9-3.5 11.6-12.7 8.3-20.7l-8.8-21.5c-2.7-6.4-9.2-10.4-16.1-9.9l-17.4 1.4c-7.2 .6-13.9-3.7-16.4-10.6-14.7-41.1-13.9-86.4 2.2-127 2.6-6.5 9.2-10.6 16.2-10l15.4 1.3c6.9 .6 13.5-3.4 16.1-9.9l8.8-21.5c3.3-8-.4-17.2-8.3-20.7zM169 72.1l-8.8 21.5c-8 19.3-27.5 31.3-48.4 29.6l-3.1-.3c-8.2 26.5-8.7 55-1.5 81.7l4.6-.4c20.8-1.7 40.4 10.2 48.4 29.6l8.8 21.5c9.9 24.1-1.2 51.7-25 62.2l-2 .9C111.3 331.9 69 327.7 45.8 293.8-7.9 215.6-7.9 111.7 45.8 33.5 69-.4 111.3-4.6 142 9l2 .9c23.8 10.5 34.9 38.1 25 62.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlenderPhone = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;