'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bolt-lightning';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e0b7';
var svgPathData = 'M32 30.9C32 13.8 45.9 0 62.9 0L226.2 0c16.4 0 29.8 13.3 29.8 29.8 0 3.2-.5 6.4-1.5 9.4L214.2 160 355.8 160c15.6 0 28.2 12.6 28.2 28.2 0 5.7-1.7 11.2-4.9 15.9l-203.2 297c-4.6 6.8-12.3 10.8-20.5 10.8-16.2 0-28-15.2-24.1-30.9L179.5 288 30.9 288c-17.1 0-30.9-13.9-30.9-30.9 0-1.5 .1-2.9 .3-4.4L32 30.9zM64 32c0 1.1-.1 2.2-.3 3.3L32.2 256 200 256c4.9 0 9.6 2.3 12.6 6.2s4.1 8.9 2.9 13.7L171.9 450.2 348.6 192 192 192c-5.1 0-10-2.5-13-6.6s-3.8-9.5-2.2-14.4L223.1 32 64 32z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoltLightning = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;