'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-turn-down-right';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e3d6';
var svgPathData = 'M32 80c0-8.8-7.2-16-16-16S0 71.2 0 80l0 96c0 53 43 96 96 96l361.4 0-116.7 116.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0l144-144c3-3 4.7-7.1 4.7-11.3s-1.7-8.3-4.7-11.3l-144-144c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6L457.4 240 96 240c-35.3 0-64-28.7-64-64l0-96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowTurnDownRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;