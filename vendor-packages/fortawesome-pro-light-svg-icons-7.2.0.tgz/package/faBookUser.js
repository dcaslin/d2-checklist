'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-user';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f7e7';
var svgPathData = 'M0 64C0 28.7 28.7 0 64 0L400 0c26.5 0 48 21.5 48 48l0 320c0 20.9-13.4 38.7-32 45.3l0 66.7 16 0c8.8 0 16 7.2 16 16s-7.2 16-16 16L64 512c-35.3 0-64-28.7-64-64l0 0 0-384zM64 416c-17.7 0-32 14.3-32 32s14.3 32 32 32l320 0 0-64-320 0zM32 392.6c9.4-5.4 20.3-8.6 32-8.6l336 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 32C46.3 32 32 46.3 32 64l0 328.6zM256 160a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm-96 0a64 64 0 1 1 128 0 64 64 0 1 1 -128 0zM134.6 320c-10.8 0-19-10.1-14.2-19.8 13.1-26.2 40.2-44.2 71.6-44.2l64 0c31.3 0 58.4 18 71.6 44.2 4.9 9.7-3.3 19.8-14.2 19.8-7.3 0-13.5-4.8-17.6-10.8-8.6-12.8-23.2-21.2-39.8-21.2l-64 0c-16.6 0-31.2 8.4-39.8 21.2-4.1 6-10.3 10.8-17.6 10.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookUser = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;