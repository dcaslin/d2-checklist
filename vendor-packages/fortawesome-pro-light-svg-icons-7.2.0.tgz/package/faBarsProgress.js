'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bars-progress';
var width = 448;
var height = 512;
var aliases = ["tasks-alt"];
var unicode = 'f828';
var svgPathData = 'M288 64l0 128 112 0c8.8 0 16-7.2 16-16l0-96c0-8.8-7.2-16-16-16L288 64zM185.4 64L48 64c-8.8 0-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16l9.4 0 128-128zm45.3 0l-128 128 153.4 0 0-128-25.4 0zM0 80C0 53.5 21.5 32 48 32l352 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48L48 224c-26.5 0-48-21.5-48-48L0 80zM160 320l0 128 240 0c8.8 0 16-7.2 16-16l0-96c0-8.8-7.2-16-16-16l-240 0zm-32 0l-80 0c-8.8 0-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16l80 0 0-128zM0 336c0-26.5 21.5-48 48-48l352 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48L48 480c-26.5 0-48-21.5-48-48l0-96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarsProgress = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;