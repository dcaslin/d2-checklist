'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-circle-arrow-right';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0bc';
var svgPathData = 'M96 0C60.7 0 32 28.7 32 64l0 384 0 0c0 35.3 28.7 64 64 64l180 0c-7.2-10-13.4-20.7-18.6-32L96 480c-17.7 0-32-14.3-32-32s14.3-32 32-32l144.7 0c-.9-10.5-.9-21.5 0-32L96 384c-11.7 0-22.6 3.1-32 8.6L64 64c0-17.7 14.3-32 32-32l336 0c8.8 0 16 7.2 16 16l0 160.7c11 .9 21.6 2.7 32 5.4l0-166c0-26.5-21.5-48-48-48L96 0zM432 288a112 112 0 1 1 0 224 112 112 0 1 1 0-224zm0 256a144 144 0 1 0 0-288 144 144 0 1 0 0 288zm-3.3-211.3c-6.2 6.2-6.2 16.4 0 22.6l28.7 28.7-89.4 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l89.4 0-28.7 28.7c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0l56-56c6.2-6.2 6.2-16.4 0-22.6l-56-56c-6.2-6.2-16.4-6.2-22.6 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookCircleArrowRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;