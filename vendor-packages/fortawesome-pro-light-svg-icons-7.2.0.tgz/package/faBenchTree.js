'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bench-tree';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e2e7';
var svgPathData = 'M575.2 106.1c-1.9 11.9 3.1 23.9 12.9 30.9 12.1 8.8 19.9 22.9 19.9 38.9 0 26.5-21.5 48-48 48l-96 0c-26.5 0-48-21.5-48-48 0-16 7.8-30.2 19.9-38.9 9.8-7.1 14.7-19 12.9-30.9-.5-3.3-.8-6.7-.8-10.1 0-35.3 28.7-64 64-64s64 28.7 64 64c0 3.5-.3 6.8-.8 10.1zm31.6 5c.8-4.9 1.2-10 1.2-15.1 0-53-43-96-96-96s-96 43-96 96c0 5.1 .4 10.2 1.2 15.1-20.1 14.5-33.2 38.2-33.2 64.9 0 44.2 35.8 80 80 80l32 0 0 240c0 8.8 7.2 16 16 16s16-7.2 16-16l0-240 32 0c44.2 0 80-35.8 80-80 0-26.7-13.1-50.3-33.2-64.9zM64 224l256 0 0 64-256 0 0-64zm0 96l0 48-48 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l16 0 0 96c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96 256 0 0 96c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96 16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-48 0 0-48c17.7 0 32-14.3 32-32l0-64c0-17.7-14.3-32-32-32L64 192c-17.7 0-32 14.3-32 32l0 64c0 17.7 14.3 32 32 32zm224 0l0 48-192 0 0-48 192 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBenchTree = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;