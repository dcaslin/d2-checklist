'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-left-to-arc';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e616';
var svgPathData = 'M32 256c0 123.7 100.3 224 224 224 8.8 0 16 7.2 16 16s-7.2 16-16 16C114.6 512 0 397.4 0 256S114.6 0 256 0c8.8 0 16 7.2 16 16s-7.2 16-16 16C132.3 32 32 132.3 32 256zM276.7 379.3l-112-112c-6.2-6.2-6.2-16.4 0-22.6l112-112c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6L214.6 240 496 240c8.8 0 16 7.2 16 16s-7.2 16-16 16l-281.4 0 84.7 84.7c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowLeftToArc = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;