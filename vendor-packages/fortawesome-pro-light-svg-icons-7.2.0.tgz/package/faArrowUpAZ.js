'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-up-a-z';
var width = 512;
var height = 512;
var aliases = ["sort-alpha-up"];
var unicode = 'f15e';
var svgPathData = 'M139.3 36.7c-6.2-6.2-16.4-6.2-22.6 0l-96 96c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L112 86.6 112 464c0 8.8 7.2 16 16 16s16-7.2 16-16l0-377.4 68.7 68.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6l-96-96zm259 4.2c-2.7-5.4-8.2-8.8-14.3-8.8s-11.6 3.4-14.3 8.8L305.8 168.6c-.1 .2-.2 .4-.3 .6l-15.8 31.7c-4 7.9-.7 17.5 7.2 21.5s17.5 .7 21.5-7.2l11.6-23.2 108.2 0 11.6 23.2c4 7.9 13.6 11.1 21.5 7.2s11.1-13.6 7.2-21.5l-15.8-31.7c-.1-.2-.2-.4-.3-.6L398.3 40.8zM384 83.8l38.1 76.2-76.2 0 38.1-76.2zM312 288c-8.8 0-16 7.2-16 16s7.2 16 16 16l108.1 0-120 133.3c-4.2 4.7-5.3 11.4-2.7 17.2s8.3 9.5 14.6 9.5l144 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-108.1 0 120-133.3c4.2-4.7 5.3-11.4 2.7-17.2S462.3 288 456 288l-144 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpAZ = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;