'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-down-a-z';
var width = 512;
var height = 512;
var aliases = ["sort-alpha-asc","sort-alpha-down"];
var unicode = 'f15d';
var svgPathData = 'M235.3 379.3l-96 96c-6.2 6.2-16.4 6.2-22.6 0l-96-96c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0L112 425.4 112 48c0-8.8 7.2-16 16-16s16 7.2 16 16l0 377.4 68.7-68.7c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6zm163-338.5l63.9 127.7c.1 .2 .2 .4 .3 .6l15.8 31.7c4 7.9 .7 17.5-7.2 21.5s-17.5 .7-21.5-7.2l-11.6-23.2-108.2 0-11.6 23.2c-4 7.9-13.6 11.1-21.5 7.2s-11.1-13.6-7.2-21.5l15.8-31.7c.1-.2 .2-.4 .3-.6L369.7 40.8c2.7-5.4 8.2-8.8 14.3-8.8s11.6 3.4 14.3 8.8zM384 83.8l-38.1 76.2 76.2 0-38.1-76.2zM312 288l144 0c6.3 0 12 3.7 14.6 9.5s1.5 12.5-2.7 17.2L347.9 448 456 448c8.8 0 16 7.2 16 16s-7.2 16-16 16l-144 0c-6.3 0-12-3.7-14.6-9.5s-1.5-12.5 2.7-17.2L420.1 320 312 320c-8.8 0-16-7.2-16-16s7.2-16 16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownAZ = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;