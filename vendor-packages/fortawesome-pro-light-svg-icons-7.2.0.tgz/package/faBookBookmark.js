'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-bookmark';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e0bb';
var svgPathData = 'M0 64C0 28.7 28.7 0 64 0L400 0c26.5 0 48 21.5 48 48l0 320c0 20.9-13.4 38.7-32 45.3l0 66.7 16 0c8.8 0 16 7.2 16 16s-7.2 16-16 16L64 512c-35.3 0-64-28.7-64-64l0 0 0-384zM320 32l-96 0 0 144 38.4-28.8c5.7-4.3 13.5-4.3 19.2 0L320 176 320 32zM192 32L64 32C46.3 32 32 46.3 32 64l0 328.6c9.4-5.4 20.3-8.6 32-8.6l336 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16l-48 0 0 176c0 6.1-3.4 11.6-8.8 14.3s-11.9 2.1-16.8-1.5L272 180 217.6 220.8c-4.8 3.6-11.3 4.2-16.8 1.5S192 214.1 192 208l0-176zM64 416c-17.7 0-32 14.3-32 32s14.3 32 32 32l320 0 0-64-320 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookBookmark = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;