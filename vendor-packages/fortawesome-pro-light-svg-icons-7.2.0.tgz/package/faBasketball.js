'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'basketball';
var width = 512;
var height = 512;
var aliases = [127936,"basketball-ball"];
var unicode = 'f434';
var svgPathData = 'M290.7 477.3c-1.8-9.5-2.7-19.3-2.7-29.3 0-38.4 13.5-73.7 36.1-101.3l78.6 78.6c-31 26.9-69.5 45.4-112 52zm-32 2.7c-.9 0-1.8 0-2.7 0-56.1 0-107.4-20.6-146.7-54.7L256 278.6 301.4 324c-28.3 33.5-45.4 76.7-45.4 124 0 10.9 .9 21.6 2.7 32zM324 301.4L278.6 256 425.3 109.3c34.1 39.3 54.7 90.6 54.7 146.7 0 .9 0 1.8 0 2.7-10.4-1.7-21.1-2.7-32-2.7-47.3 0-90.5 17.1-124 45.4zm22.7 22.7c27.6-22.6 62.8-36.1 101.3-36.1 10 0 19.8 .9 29.3 2.7-6.6 42.5-25.1 81-52 112l-78.6-78.6zM256 233.4L210.6 188c28.3-33.5 45.4-76.7 45.4-124 0-10.9-.9-21.6-2.7-32 .9 0 1.8 0 2.7 0 56.1 0 107.4 20.6 146.7 54.7L256 233.4zm-68.1-68.1L109.3 86.7c31-26.9 69.5-45.4 112-52 1.8 9.5 2.7 19.3 2.7 29.3 0 38.4-13.5 73.7-36.1 101.3zm-22.6 22.6c-27.6 22.6-62.8 36.1-101.3 36.1-10 0-19.8-.9-29.3-2.7 6.6-42.5 25.1-81 52-112l78.6 78.6zM32 253.3c10.4 1.7 21.1 2.7 32 2.7 47.3 0 90.5-17.1 124-45.4L233.4 256 86.7 402.7c-34.1-39.3-54.7-90.6-54.7-146.7 0-.9 0-1.8 0-2.7zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBasketball = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;