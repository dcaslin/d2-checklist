'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrows-turn-to-dots';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e4c1';
var svgPathData = 'M260.7 4.7c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6L230.6 80 352 80c53 0 96 43 96 96l0 32c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-32c0-35.3-28.7-64-64-64l-121.4 0 52.7 52.7c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0l-80-80c-6.2-6.2-6.2-16.4 0-22.6l80-80zm-73.4 272l80 80c6.2 6.2 6.2 16.4 0 22.6l-80 80c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6L217.4 384 96 384c-35.3 0-64 28.7-64 64l0 32c0 8.8-7.2 16-16 16S0 488.8 0 480l0-32c0-53 43-96 96-96l121.4 0-52.7-52.7c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0zM384 400a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm0-96a64 64 0 1 1 0 128 64 64 0 1 1 0-128zM32 96a32 32 0 1 0 64 0 32 32 0 1 0 -64 0zm96 0A64 64 0 1 1 0 96 64 64 0 1 1 128 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsTurnToDots = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;