'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-turn-left';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e632';
var svgPathData = 'M480 432c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96c0-53-43-96-96-96L54.6 240 171.3 123.3c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0l-144 144c-3 3-4.7 7.1-4.7 11.3s1.7 8.3 4.7 11.3l144 144c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L54.6 272 416 272c35.3 0 64 28.7 64 64l0 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowTurnLeft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;