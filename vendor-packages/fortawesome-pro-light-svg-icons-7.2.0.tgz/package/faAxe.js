'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'axe';
var width = 640;
var height = 512;
var aliases = [129683];
var unicode = 'f6b2';
var svgPathData = 'M503 180.3L363.3 40.6c-6.2-6.2-16.4-6.2-22.6 0l-76.1 76.1c-6.2 6.2-6.2 16.4 0 22.6L404.3 279c7.5 7.5 11.7 17.7 11.7 28.3l0 76.7c106 0 192-86 192-192l-76.7 0c-10.6 0-20.8-4.2-28.3-11.7zM385.9 17.9L525.7 157.7c1.5 1.5 3.5 2.3 5.7 2.3l84.7 0c13.3 0 24 10.7 24 24l0 8c0 123.7-100.3 224-224 224l-8 0c-13.3 0-24-10.7-24-24l0-84.7c0-2.1-.8-4.2-2.3-5.7l-34.3-34.3-232 232c-19.5 19.5-51.1 19.5-70.6 0s-19.5-51.1 0-70.6l232-232-34.7-34.7c-18.7-18.7-18.7-49.1 0-67.9l76.1-76.1c18.7-18.7 49.1-18.7 67.9 0zM299.3 219.3l-232 232c-7 7-7 18.4 0 25.4s18.4 7 25.4 0l232-232-25.4-25.4zm184-206.6l48 48c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0l-48-48c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAxe = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;