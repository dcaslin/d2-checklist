'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'ban-bug';
var width = 512;
var height = 512;
var aliases = ["debug"];
var unicode = 'f7f9';
var svgPathData = 'M256 480c-123.7 0-224-100.3-224-224 0-56.1 20.6-107.4 54.7-146.7l316 316C363.4 459.4 312.1 480 256 480zm80-166.6l0-15.2 46 5.8c8.8 1.1 16.8-5.1 17.9-13.9s-5.1-16.8-13.9-17.9l-50-6.2 0-21.4 51.9-13c8.6-2.1 13.8-10.8 11.6-19.4s-10.8-13.8-19.4-11.6l-44.1 11 0-3.5c0-7.4-1-14.7-2.9-21.5l43.8-29.2c7.4-4.9 9.3-14.8 4.4-22.2s-14.8-9.3-22.2-4.4l-40.8 27.2c-14.7-18.2-37.1-29.9-62.3-29.9-28.6 0-53.7 15-67.8 37.6L109.3 86.7c39.3-34.1 90.6-54.7 146.7-54.7 123.7 0 224 100.3 224 224 0 56.1-20.6 107.4-54.7 146.7L336 313.4zM211.8 189.2c7.3-17.2 24.3-29.2 44.2-29.2 26.5 0 48 21.5 48 48l0 73.4-92.2-92.2zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM208 304l0-5.5-32.6-32.6-49.4 6.2c-8.8 1.1-15 9.1-13.9 17.9s9.1 15 17.9 13.9l46-5.8 0 5.9c0 7.4 1 14.7 2.9 21.5l-43.8 29.2c-7.4 4.9-9.3 14.8-4.4 22.2s14.8 9.3 22.2 4.4l40.8-27.2c14.7 18.2 37.1 29.9 62.3 29.9 11.1 0 21.6-2.2 31.2-6.3l-26-26c-1.7 .2-3.5 .3-5.2 .3-26.5 0-48-21.5-48-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanBug = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;