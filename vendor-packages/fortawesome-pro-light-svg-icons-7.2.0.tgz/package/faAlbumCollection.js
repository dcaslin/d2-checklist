'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'album-collection';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f8a0';
var svgPathData = 'M128 16c0 8.8 7.2 16 16 16l224 0c8.8 0 16-7.2 16-16S376.8 0 368 0L144 0c-8.8 0-16 7.2-16 16zM80 96c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16s-7.2-16-16-16L96 80c-8.8 0-16 7.2-16 16zM52 197.4c3-3.4 7.4-5.4 12-5.4l384 0c4.6 0 9 2 12 5.4l0 0c3 3.4 4.5 8 3.9 12.6l-32 256c-1 8-7.8 14-15.9 14L96 480c-8.1 0-14.9-6-15.9-14l-32-256c-.6-4.6 .8-9.1 3.9-12.6zM64 160c-13.8 0-26.9 5.9-36 16.2S14.7 200.3 16.4 214l32 256c3 24 23.4 42 47.6 42l320 0c24.2 0 44.6-18 47.6-42l32-256c1.7-13.7-2.5-27.4-11.6-37.7S461.8 160 448 160L64 160zM256 416c-64.4 0-105.1-41.6-105.1-80s40.7-80 105.1-80 105.1 41.6 105.1 80-40.7 80-105.1 80zm0 32c75.7 0 137.1-50.1 137.1-112S331.7 224 256 224 118.9 274.1 118.9 336 180.3 448 256 448zm0-88c16.2 0 29.4-10.7 29.4-24s-13.2-24-29.4-24-29.4 10.7-29.4 24 13.2 24 29.4 24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlbumCollection = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;