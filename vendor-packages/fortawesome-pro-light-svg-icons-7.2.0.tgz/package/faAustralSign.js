'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'austral-sign';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e0a9';
var svgPathData = 'M284.4 240L163.6 240 224 76.2 284.4 240zm34.1 0L248 48.7c-3.7-10-13.3-16.7-24-16.7s-20.3 6.7-24 16.7L129.5 240 32 240c-8.8 0-16 7.2-16 16s7.2 16 16 16l85.7 0-23.6 64-62.1 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l50.3 0-33.3 90.5c-3.1 8.3 1.2 17.5 9.5 20.5S76 477.8 79 469.5L116.4 368 331.6 368 369 469.5c3.1 8.3 12.3 12.5 20.5 9.5s12.5-12.3 9.5-20.5L365.7 368 416 368c8.8 0 16-7.2 16-16s-7.2-16-16-16l-62.1 0-23.6-64 85.7 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-97.5 0zm-22.3 32l23.6 64-191.5 0 23.6-64 144.4 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAustralSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;