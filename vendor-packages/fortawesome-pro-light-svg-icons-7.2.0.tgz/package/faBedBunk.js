'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bed-bunk';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f8f8';
var svgPathData = 'M16 0c8.8 0 16 7.2 16 16l0 144 192 0 0-128c0-17.7 14.3-32 32-32L400 0c61.9 0 112 50.1 112 112l0 376c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-40.3-448 0 0 40.3c0 8.8-7.2 16-16 16S0 496.8 0 488L0 16C0 7.2 7.2 0 16 0zM224 415.7L224 288c0-17.7 14.3-32 32-32l224 0 0-64-448 0 0 223.7 192 0zM480 160l0-48c0-44.2-35.8-80-80-80l-144 0 0 128 224 0zm0 128l-224 0 0 127.7 224 0 0-127.7zM128 352a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm0-96a64 64 0 1 1 0 128 64 64 0 1 1 0-128zM160 64a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zM64 64A64 64 0 1 1 192 64 64 64 0 1 1 64 64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBedBunk = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;