'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bicycle';
var width = 640;
var height = 512;
var aliases = [128690];
var unicode = 'f206';
var svgPathData = 'M322.3 39.7c2.9-4.8 8.1-7.7 13.7-7.7l112 0c8.8 0 16 7.2 16 16s-7.2 16-16 16L362.5 64 451 232.1c14-5.3 29.2-8.1 45-8.1 70.7 0 128 57.3 128 128s-57.3 128-128 128-128-57.3-128-128c0-43.4 21.6-81.8 54.7-104.9L402 207.8 326.3 359.2c-2.7 5.4-8.2 8.8-14.3 8.8l-41 0c-7.9 63.1-61.7 112-127 112-70.7 0-128-57.3-128-128S73.3 224 144 224c12.4 0 24.3 1.8 35.6 5l26.5-53-24-48-38.1 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l48 0c6.1 0 11.6 3.4 14.3 8.8l27.6 55.2 143 0-55-104.5c-2.6-5-2.4-10.9 .5-15.7zM224 211.8L161.9 336 286.1 336 224 211.8zm88 104.4L374.1 192 249.9 192 312 316.2zm169.8 43.2l-44.1-83.8c-23 17.5-37.8 45.2-37.8 76.3 0 53 43 96 96 96s96-43 96-96-43-96-96-96c-10.5 0-20.5 1.7-29.9 4.8l44.1 83.8c4.1 7.8 1.1 17.5-6.7 21.6s-17.5 1.1-21.6-6.7zM144 448c47.6 0 87.1-34.6 94.7-80l-97.5 0c-14.3 0-23.6-15-17.2-27.8l41-81.9c-6.7-1.5-13.8-2.3-21-2.3-53 0-96 43-96 96s43 96 96 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBicycle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;