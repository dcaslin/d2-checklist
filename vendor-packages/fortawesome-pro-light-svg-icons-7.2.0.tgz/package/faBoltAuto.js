'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bolt-auto';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0b6';
var svgPathData = 'M245 210.6L320 48 64 256 174 256c10.9 0 21.1 5.6 27 14.8s6.7 20.7 2.1 30.7L128 464 384 256 274 256c-10.9 0-21.1-5.6-27-14.8s-6.7-20.7-2.1-30.7zM349.1 61.4C301.3 164.9 276.3 219.1 274 224l110 0c13.5 0 25.6 8.5 30.2 21.3s.5 27-10 35.5l-256 208c-11.6 9.4-28.1 9.6-39.8 .4s-15.7-25.2-9.4-38.7c47.8-103.5 72.8-157.7 75-162.6L64 288c-13.5 0-25.6-8.5-30.2-21.3s-.5-27 10-35.5l256-208c11.6-9.4 28.1-9.6 39.8-.4s15.7 25.2 9.4 38.7zM448 288c6.1 0 11.6 3.4 14.3 8.8l96 192c4 7.9 .7 17.5-7.2 21.5s-17.5 .7-21.5-7.2l-19.6-39.2-124.2 0-19.6 39.2c-4 7.9-13.6 11.1-21.5 7.2s-11.1-13.6-7.2-21.5l96-192c2.7-5.4 8.2-8.8 14.3-8.8zm0 51.8l-46.1 92.2 92.2 0-46.1-92.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoltAuto = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;