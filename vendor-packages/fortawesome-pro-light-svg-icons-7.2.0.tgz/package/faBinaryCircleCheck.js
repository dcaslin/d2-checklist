'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'binary-circle-check';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e33c';
var svgPathData = 'M384 16c0-4.9-2.3-9.6-6.2-12.6S368.9-.7 364.1 .5l-64 16c-8.6 2.1-13.8 10.8-11.6 19.4s10.8 13.8 19.4 11.6l44.1-11 0 155.5-48 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l51.1 0c23.5-10.3 49.5-16 76.9-16 5.4 0 10.7 .2 16 .7 0-.2 0-.4 0-.7 0-8.8-7.2-16-16-16l-48 0 0-176zM160 304c0-4.9-2.3-9.6-6.2-12.6s-8.9-4.1-13.7-2.9l-64 16c-8.6 2.1-13.8 10.8-11.6 19.4s10.8 13.8 19.4 11.6l44.1-11 0 155.5-48 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l128 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-48 0 0-176zM64 64l0 96c0 35.3 28.7 64 64 64l64 0c35.3 0 64-28.7 64-64l0-96c0-35.3-28.7-64-64-64L128 0C92.7 0 64 28.7 64 64zm64-32l64 0c17.7 0 32 14.3 32 32l0 96c0 17.7-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32l0-96c0-17.7 14.3-32 32-32zM432 288a112 112 0 1 1 0 224 112 112 0 1 1 0-224zm0 256a144 144 0 1 0 0-288 144 144 0 1 0 0 288zm57.4-204.9c-7.1-5.2-17.2-3.6-22.4 3.5l-53 72.9-26.8-26.8c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l40 40c3.3 3.3 7.9 5 12.6 4.6s8.9-2.8 11.7-6.5l64-88c5.2-7.1 3.6-17.2-3.5-22.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinaryCircleCheck = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;