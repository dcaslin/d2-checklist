'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'battery-quarter';
var width = 640;
var height = 512;
var aliases = ["battery-2"];
var unicode = 'f243';
var svgPathData = 'M496 96c26.5 0 48 21.5 48 48l0 224c0 26.5-21.5 48-48 48l-384 0c-26.5 0-48-21.5-48-48l0-224c0-26.5 21.5-48 48-48l384 0zm80 272l0-32 32 0c17.7 0 32-14.3 32-32l0-96c0-17.7-14.3-32-32-32l-32 0 0-32c0-44.2-35.8-80-80-80L112 64c-44.2 0-80 35.8-80 80l0 224c0 44.2 35.8 80 80 80l384 0c44.2 0 80-35.8 80-80zm0-64l0-96 32 0 0 96-32 0zM160 320l0-128 64 0 0 128-64 0zM128 184l0 144c0 13.3 10.7 24 24 24l80 0c13.3 0 24-10.7 24-24l0-144c0-13.3-10.7-24-24-24l-80 0c-13.3 0-24 10.7-24 24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBatteryQuarter = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;