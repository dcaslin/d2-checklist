'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bed-pulse';
var width = 576;
var height = 512;
var aliases = ["procedures"];
var unicode = 'f487';
var svgPathData = 'M460.8-25.6L504 32 560 32c8.8 0 16 7.2 16 16s-7.2 16-16 16l-64 0c-5 0-9.8-2.4-12.8-6.4l-32-42.7-52.7 111.9c-2.5 5.2-7.5 8.7-13.3 9.1s-11.3-2.3-14.5-7.1L327.4 64 272 64c-8.8 0-16-7.2-16-16s7.2-16 16-16l64 0c5.4 0 10.3 2.7 13.3 7.1l32.3 48.4 51.9-110.4c2.4-5.1 7.3-8.5 12.9-9.1s11.1 1.8 14.4 6.3zM288 192c0-23.9 17.5-43.7 40.3-47.4l5.8 8.7c7 10.5 17 18.3 28.4 22.7L336 176c-8.8 0-16 7.2-16 16l0 160 224 0 0-96c0-44.2-35.8-80-80-80l-58.5 0c14.2-5.5 26.1-16.3 32.8-30.5l.7-1.5 25 0c61.9 0 112 50.1 112 112l0 208c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-80-512 0 0 80c0 8.8-7.2 16-16 16S0 472.8 0 464L0 48c0-8.8 7.2-16 16-16s16 7.2 16 16l0 304 256 0 0-160zm-80 32a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM80 224a80 80 0 1 1 160 0 80 80 0 1 1 -160 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBedPulse = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;