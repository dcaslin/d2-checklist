'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-rotate-left-10';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e836';
var svgPathData = 'M256 0C397.4 0 512 114.6 512 256S397.4 512 256 512c-98.3 0-183.6-55.4-226.5-136.5-4.1-7.8-1.1-17.5 6.7-21.6s17.5-1.1 21.6 6.7C95.4 431.6 170.1 480 256 480 379.7 480 480 379.7 480 256S379.7 32 256 32c-62 0-121.2 25.5-163.8 70.6L27.6 171c-4.5 4.8-11.4 6.3-17.5 3.9S0 166.6 0 160L0 16C0 7.2 7.2 0 16 0S32 7.2 32 16l0 103.8 37-39.1C117.6 29.2 185.2 0 256 0zM184.8 161.7c5-2.5 10.8-2.2 15.6 .7s7.6 8.1 7.6 13.6l0 160c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-134.1-24.8 12.4c-7.9 4-17.5 .7-21.5-7.2s-.7-17.5 7.2-21.5l48-24zM312 160c30.9 0 56 25.1 56 56l0 80c0 30.9-25.1 56-56 56l-16 0c-30.9 0-56-25.1-56-56l0-80c0-30.9 25.1-56 56-56l16 0zm-16 32c-13.3 0-24 10.7-24 24l0 80c0 13.3 10.7 24 24 24l16 0c13.3 0 24-10.7 24-24l0-80c0-13.3-10.7-24-24-24l-16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateLeft10 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;