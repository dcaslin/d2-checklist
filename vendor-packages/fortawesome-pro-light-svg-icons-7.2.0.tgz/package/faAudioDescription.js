'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'audio-description';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f29e';
var svgPathData = 'M448 96c17.7 0 32 14.3 32 32l0 256c0 17.7-14.3 32-32 32L64 416c-17.7 0-32-14.3-32-32l0-256c0-17.7 14.3-32 32-32l384 0zM64 64C28.7 64 0 92.7 0 128L0 384c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L64 64zM96 224l0 112c0 8.8 7.2 16 16 16s16-7.2 16-16l0-48 80 0 0 48c0 8.8 7.2 16 16 16s16-7.2 16-16l0-112c0-35.3-28.7-64-64-64l-16 0c-35.3 0-64 28.7-64 64zm32 32l0-32c0-17.7 14.3-32 32-32l16 0c17.7 0 32 14.3 32 32l0 32-80 0zm160-96c-8.8 0-16 7.2-16 16l0 160c0 8.8 7.2 16 16 16l56 0c39.8 0 72-32.2 72-72l0-48c0-39.8-32.2-72-72-72l-56 0zm56 160l-40 0 0-128 40 0c22.1 0 40 17.9 40 40l0 48c0 22.1-17.9 40-40 40z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAudioDescription = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;