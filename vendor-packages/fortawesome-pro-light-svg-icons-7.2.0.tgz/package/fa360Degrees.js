'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = '360-degrees';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e2dc';
var svgPathData = 'M608 64a32 32 0 1 0 0-64 32 32 0 1 0 0 64zM16 64C7.2 64 0 71.2 0 80S7.2 96 16 96l111.3 0-91.9 118.2c-3.8 4.8-4.4 11.4-1.7 16.9s8.3 9 14.4 9l32 0c44.2 0 80 35.8 80 80l0 16c0 44.2-35.8 80-80 80l-5.5 0c-12.7 0-24.9-5.1-33.9-14.1L27.3 388.7c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l13.3 13.3c15 15 35.4 23.4 56.6 23.4l5.5 0c61.9 0 112-50.1 112-112l0-16c0-61.6-49.8-111.6-111.3-112L172.6 89.8c3.8-4.8 4.4-11.4 1.7-16.9s-8.3-9-14.4-9L16 64zm432 80c0-26.5 21.5-48 48-48s48 21.5 48 48l0 224c0 26.5-21.5 48-48 48s-48-21.5-48-48l0-224zM576 368l0-224c0-44.2-35.8-80-80-80s-80 35.8-80 80l0 224c0 44.2 35.8 80 80 80s80-35.8 80-80zM256 176c0-44.2 35.8-80 80-80 8.8 0 16-7.2 16-16s-7.2-16-16-16c-61.9 0-112 50.1-112 112l0 112 0 .2 0 79.8c0 44.2 35.8 80 80 80s80-35.8 80-80l0-96c0-44.2-35.8-80-80-80-18 0-34.6 6-48 16l0-32zm48 48c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48s-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.fa360Degrees = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;