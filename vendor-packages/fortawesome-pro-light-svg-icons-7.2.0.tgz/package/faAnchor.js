'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'anchor';
var width = 512;
var height = 512;
var aliases = [9875];
var unicode = 'f13d';
var svgPathData = 'M256 32a48 48 0 1 0 0 96 48 48 0 1 0 0-96zM176 80c0-44.2 35.8-80 80-80s80 35.8 80 80c0 38.7-27.5 71-64 78.4l0 304.8c80.9-8 144-76.2 144-159.2l0-28.7-37.5 32.8c-6.7 5.8-16.8 5.1-22.6-1.5s-5.1-16.8 1.5-22.6l64-56c6-5.3 15-5.3 21.1 0l64 56c6.6 5.8 7.3 15.9 1.5 22.6s-15.9 7.3-22.6 1.5L448 275.3 448 304c0 106-86 192-192 192S64 410 64 304l0-28.7-37.5 32.8c-6.7 5.8-16.8 5.1-22.6-1.5S-1.2 289.8 5.5 284l64-56c6-5.3 15-5.3 21.1 0l64 56c6.7 5.8 7.3 15.9 1.5 22.6s-15.9 7.3-22.6 1.5L96 275.3 96 304c0 83 63.1 151.2 144 159.2l0-304.8c-36.5-7.4-64-39.7-64-78.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAnchor = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;