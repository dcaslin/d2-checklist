'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bells';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f77f';
var svgPathData = 'M356.2 54.6c-7.8 2.1-15.4 4.8-22.8 7.8-13.5-27.7-38.4-49.8-70.3-58.5-58.2-15.9-117.6 18.4-132.9 76.7l-5.8 21.9c-12.7 48.4-41.3 91.1-81.2 121.1-1.2 .9-10.9 8.9-10.9 8.9l23 6.3 165.4 45.2c.3 1.3 .6 2.5 .9 3.8l5.8 21.9c.9 3.3 1.6 6.6 2.2 10L23.9 263.3c-17.1-4.7-27.3-22.4-22.8-39.5 1.8-7 5.9-13.1 11.6-17.4L24 198c34.1-25.6 58.6-62.1 69.5-103.6l5.8-21.9c19.8-75.5 97-120.1 172.3-99.5 42.8 11.7 75.7 41.9 92.6 79.6-2.7 .6-5.3 1.3-8 2zM224.8 391c-9.6 5.7-20.8 9-32.8 9-33.4 0-60.9-25.7-63.8-58.4l35.7 9.8c5.4 9.9 16 16.6 28.1 16.6 6 0 11.5-1.6 16.3-4.5l21.7 5.9c-1.2 7.3-3 14.4-5.3 21.5zM616 326l11.3 8.5c5.7 4.3 9.8 10.4 11.6 17.4 4.5 17.1-5.7 34.8-22.8 39.5l-320 87.5c-17.1 4.7-34.6-5.4-39.1-22.6-1.8-7-1.3-14.3 1.6-21l5.6-13.1c17-39.6 20.3-83.7 9.4-125.2l-5.8-21.9C248.1 199.6 293.1 121.6 368.4 101S520.9 125 540.7 200.5l5.8 21.9c10.9 41.5 35.4 78 69.5 103.6zM293.7 434.8l-5.6 13.1 319.7-87.4-11-8.8c-39.9-30-68.5-72.6-81.2-121.1l-5.8-21.9c-15.3-58.3-74.8-92.6-132.9-76.7-58.4 16-93.3 76.5-78 135.1l5.8 21.9c12.7 48.4 8.8 99.8-11 145.9zm66.4 76.3l32.8-9c5.8 6.1 14 9.8 23.1 9.8 15.2 0 27.9-10.5 31.2-24.7l32.8-9c0 .6 0 1.1 0 1.7 0 35.3-28.7 64-64 64-24 0-45-13.3-55.9-32.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBells = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;