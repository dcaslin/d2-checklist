'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bath';
var width = 512;
var height = 512;
var aliases = [128705,"bathtub"];
var unicode = 'f2cd';
var svgPathData = 'M64 61.3c0-16.2 13.1-29.3 29.3-29.3 7.8 0 15.2 3.1 20.7 8.6L139 65.7c-7 11.1-11 24.2-11 38.3 0 20.2 8.3 38.5 21.8 51.6l-1.1 1.1c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0l104-104c6.2-6.2 6.2-16.4 0-22.6s-16.4-6.2-22.6 0l-1.1 1.1c-13.1-13.4-31.4-21.8-51.6-21.8-14.1 0-27.2 4-38.3 11L136.6 17.9C125.1 6.5 109.5 0 93.3 0 59.4 0 32 27.4 32 61.3l0 194.7-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l16 0 0 80c0 30.5 12.2 58.2 32 78.4L64 496c0 8.8 7.2 16 16 16s16-7.2 16-16l0-26.8c14.5 6.9 30.8 10.8 48 10.8l224 0c17.2 0 33.5-3.9 48-10.8l0 26.8c0 8.8 7.2 16 16 16s16-7.2 16-16l0-49.6c19.8-20.2 32-47.9 32-78.4l0-80 16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16L64 256 64 61.3zM229 76.4L172.4 133c-7.6-7.3-12.4-17.6-12.4-29 0-22.1 17.9-40 40-40 11.4 0 21.7 4.8 29 12.4zM64 288l384 0 0 80c0 44.2-35.8 80-80 80l-224 0c-44.2 0-80-35.8-80-80l0-80z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBath = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;