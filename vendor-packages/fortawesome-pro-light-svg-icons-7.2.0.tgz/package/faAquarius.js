'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'aquarius';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e845';
var svgPathData = 'M416.4 306.2c5-2.9 11.2-2.9 16.3 0l136 80c7.6 4.5 10.1 14.3 5.7 21.9-4.5 7.6-14.3 10.1-21.9 5.7l-127.9-75.3-127.9 75.3c-5 2.9-11.2 2.9-16.3 0L152.5 338.5 24.6 413.8c-7.6 4.5-17.4 1.9-21.9-5.7-4.5-7.6-1.9-17.4 5.7-21.9l136-80c5-2.9 11.2-2.9 16.2 0l127.9 75.2 127.9-75.2zm0-208c5-2.9 11.2-2.9 16.3 0l136 80c7.6 4.5 10.1 14.3 5.7 21.9-4.5 7.6-14.3 10.1-21.9 5.7l-127.9-75.2-127.9 75.2c-5 2.9-11.2 2.9-16.3 0L152.5 130.5 24.6 205.8c-7.6 4.5-17.4 1.9-21.9-5.7-4.5-7.6-1.9-17.4 5.7-21.9l136-80c5-2.9 11.2-2.9 16.2 0l127.9 75.2 127.9-75.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAquarius = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;