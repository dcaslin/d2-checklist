'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'beer-mug-empty';
var width = 576;
var height = 512;
var aliases = ["beer"];
var unicode = 'f0fc';
var svgPathData = 'M400 64c8.8 0 16 7.2 16 16l0 271.7c0 .2 0 .4 0 .7l0 31.7c0 35.3-28.7 64-64 64l-192 0c-35.3 0-64-28.7-64-64L96 80c0-8.8 7.2-16 16-16l288 0zm48 320l0-22.1 101.5-50.7c16.3-8.1 26.5-24.8 26.5-42.9L576 144c0-26.5-21.5-48-48-48l-80 0 0-16c0-26.5-21.5-48-48-48L112 32C85.5 32 64 53.5 64 80l0 304c0 53 43 96 96 96l192 0c53 0 96-43 96-96zm87.2-101.5l-87.2 43.6 0-198.1 80 0c8.8 0 16 7.2 16 16l0 124.2c0 6.1-3.4 11.6-8.8 14.3zM176 128c-8.8 0-16 7.2-16 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16zm144 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16s-16 7.2-16 16zm-64-16c-8.8 0-16 7.2-16 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBeerMugEmpty = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;