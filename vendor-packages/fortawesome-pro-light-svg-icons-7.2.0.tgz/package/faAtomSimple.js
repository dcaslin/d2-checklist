'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'atom-simple';
var width = 448;
var height = 512;
var aliases = ["atom-alt"];
var unicode = 'f5d3';
var svgPathData = 'M143.6 438.1c-50.8 16.9-82.3 10.1-96.7-4.4s-21.3-46-4.4-96.7c5.4-16.2 12.9-33.3 22.5-50.9 16.8 23.8 36.7 47.4 59.4 70.1s46.3 42.6 70.1 59.4c-17.6 9.6-34.7 17.2-50.9 22.5zM24.2 55.7C-15 94.9-3.9 173.9 45.3 256-3.9 338.1-15 417.1 24.2 456.3s118.2 28.1 200.3-21.1c82.1 49.2 161.1 60.3 200.3 21.1S452.9 338.1 403.7 256C452.9 173.9 464 94.9 424.8 55.7S306.6 27.6 224.5 76.8C142.4 27.6 63.4 16.5 24.2 55.7zM147 333.5c-25.3-25.3-46.6-51.6-63.8-77.5 17.2-25.9 38.6-52.3 63.8-77.5s51.6-46.6 77.5-63.8c25.9 17.2 52.3 38.6 77.5 63.8s46.6 51.6 63.8 77.5c-17.2 25.9-38.6 52.3-63.8 77.5s-51.6 46.6-77.5 63.8c-25.9-17.2-52.3-38.6-77.5-63.8zM124.3 155.8c-22.7 22.7-42.6 46.3-59.4 70.1-9.6-17.6-17.2-34.7-22.5-50.9-16.9-50.8-10-82.3 4.4-96.7s46-21.3 96.7-4.4c16.2 5.4 33.3 12.9 50.9 22.5-23.8 16.8-47.4 36.7-70.1 59.4zm200.3 0c-22.7-22.7-46.3-42.6-70.1-59.4 17.6-9.6 34.7-17.2 50.9-22.5 50.8-16.9 82.3-10 96.7 4.4s21.3 46 4.4 96.7c-5.4 16.2-12.9 33.3-22.5 50.9-16.8-23.8-36.7-47.4-59.4-70.1zm0 200.3c22.7-22.7 42.6-46.3 59.4-70.1 9.6 17.6 17.2 34.7 22.5 50.9 16.9 50.8 10.1 82.3-4.4 96.7s-46 21.3-96.7 4.4c-16.2-5.4-33.3-12.9-50.9-22.5 23.8-16.8 47.4-36.7 70.1-59.4zM224.5 280a24 24 0 1 0 -1-48 24 24 0 1 0 1 48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAtomSimple = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;