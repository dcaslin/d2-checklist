'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'apple-core';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e08f';
var svgPathData = 'M196.7 96c32.8 0 59.4-26.6 59.4-59.4l0-4.6-4.6 0c-32.8 0-59.4 26.6-59.4 59.4l0 4.6 4.6 0zm-18.3 32c-10.1 0-18.3-8.2-18.3-18.3l0-18.3C160.1 40.9 201.1 0 251.6 0l18.3 0c10.1 0 18.3 8.2 18.3 18.3l0 18.3c0 50.5-40.9 91.4-91.4 91.4l-18.3 0zM128.1 480c13.2 0 32-2.7 45.3-5 12.3-2.2 25-2.2 37.3 0 13.3 2.3 32.1 5 45.3 5 19.7 0 41.8-8.8 62.6-27.3-38.6-37.7-62.6-90.4-62.6-148.7 0-55.6 21.8-106.1 57.3-143.4-3-.4-6.1-.6-9.3-.6-21 0-48.7 8.4-71.1 17.1-26.2 10.2-55.6 10.2-81.9 0-22.4-8.7-50.1-17.1-71.1-17.1-3.2 0-6.3 .2-9.3 .6 35.5 37.3 57.3 87.8 57.3 143.4 0 58.3-24 111-62.6 148.7 20.8 18.5 42.9 27.3 62.6 27.3zM30 462.4c-6.2-6.8-4.4-17.3 2.7-23.1 38.8-32.3 63.4-80.9 63.4-135.3 0-55.4-25.6-104.7-65.5-137-8-6.5-9.3-18.7-.7-24.3 14.2-9.3 30.9-14.7 50.3-14.7 27.3 0 59.7 10.3 82.7 19.3 18.8 7.3 39.9 7.3 58.7 0 22.9-8.9 55.4-19.3 82.7-19.3 19.3 0 36.1 5.4 50.3 14.7 8.6 5.6 7.3 17.9-.7 24.3-40 32.3-65.5 81.7-65.5 137 0 54.4 24.7 103 63.4 135.3 7 5.9 8.8 16.3 2.7 23.1-28.3 31.3-63.2 49.6-98.1 49.6-16.2 0-37.4-3.2-50.9-5.5-8.7-1.5-17.6-1.5-26.3 0-13.5 2.4-34.6 5.5-50.8 5.5-34.9 0-69.8-18.3-98.1-49.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAppleCore = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;