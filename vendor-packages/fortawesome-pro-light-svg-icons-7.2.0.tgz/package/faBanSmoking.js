'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'ban-smoking';
var width = 512;
var height = 512;
var aliases = [128685,"smoking-ban"];
var unicode = 'f54d';
var svgPathData = 'M86.7 109.3c304.7 304.7 190 190 316 316-39.3 34.1-90.6 54.7-146.7 54.7-123.7 0-224-100.3-224-224 0-56.1 20.6-107.4 54.7-146.7zM278.6 256l105.4 0 0 32-73.4 0-32-32zm64 64l57.4 0c8.8 0 16-7.2 16-16l0-64c0-8.8-7.2-16-16-16L246.6 224 109.3 86.7c39.3-34.1 90.6-54.7 146.7-54.7 123.7 0 224 100.3 224 224 0 56.1-20.6 107.4-54.7 146.7L342.6 320zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM272 96c-8.8 0-16 7.2-16 16 0 26.5 21.5 48 48 48l32 0c8.8 0 16 7.2 16 16s7.2 16 16 16 16-7.2 16-16c0-26.5-21.5-48-48-48l-32 0c-8.8 0-16-7.2-16-16s-7.2-16-16-16zM220.1 288l-92.1 0 0-32 60.1 0-32-32-44.1 0c-8.8 0-16 7.2-16 16l0 64c0 8.8 7.2 16 16 16l140.1 0-32-32z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanSmoking = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;