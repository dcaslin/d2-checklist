'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-open-reader';
var width = 512;
var height = 512;
var aliases = ["book-reader"];
var unicode = 'f5da';
var svgPathData = 'M192 64a64 64 0 1 1 128 0 64 64 0 1 1 -128 0zm160 0a96 96 0 1 0 -192 0 96 96 0 1 0 192 0zM218.6 251.1l21.4 8.9 0 218.7C190.2 458.4 137 448 83.2 448L48 448c-8.8 0-16-7.2-16-16l0-192c0-8.8 7.2-16 16-16l35.2 0c46.5 0 92.5 9.2 135.4 27.1zM428.8 448c-53.8 0-107 10.4-156.8 30.7l0-218.7 21.4-8.9c42.9-17.9 88.9-27.1 135.4-27.1l35.2 0c8.8 0 16 7.2 16 16l0 192c0 8.8-7.2 16-16 16l-35.2 0zM256 232l-25.1-10.5C184.1 202 133.9 192 83.2 192L48 192c-26.5 0-48 21.5-48 48L0 432c0 26.5 21.5 48 48 48l35.2 0c50.7 0 100.9 10 147.7 29.5l12.8 5.3c7.9 3.3 16.7 3.3 24.6 0l12.8-5.3c46.8-19.5 97-29.5 147.7-29.5l35.2 0c26.5 0 48-21.5 48-48l0-192c0-26.5-21.5-48-48-48l-35.2 0c-50.7 0-100.9 10-147.7 29.5L256 232z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookOpenReader = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;