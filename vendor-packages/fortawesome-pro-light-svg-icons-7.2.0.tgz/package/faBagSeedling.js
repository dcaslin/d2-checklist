'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bag-seedling';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e5f2';
var svgPathData = 'M57 96l334 0 12.6 50.3c8.2 33 12.4 66.9 12.4 100.9l0 17.7c0 34-4.2 67.9-12.4 100.9L391 416 57 416 44.4 365.7C36.2 332.7 32 298.9 32 264.8l0-17.7c0-34 4.2-67.9 12.4-100.9L57 96zM398.9 64L49.1 64 32.8 39.5c-.5-.8-.8-1.7-.8-2.7 0-2.7 2.2-4.8 4.8-4.8l374.3 0c2.7 0 4.8 2.2 4.8 4.8 0 1-.3 1.9-.8 2.7L398.9 64zM49.1 448l349.7 0 16.3 24.5c.5 .8 .8 1.7 .8 2.7 0 2.7-2.2 4.8-4.8 4.8L36.8 480c-2.7 0-4.8-2.2-4.8-4.8 0-1 .3-1.9 .8-2.7L49.1 448zM6.2 57.3l20 30-12.8 51.2C4.5 174 0 210.5 0 247.2l0 17.7C0 301.5 4.5 338 13.4 373.5l12.8 51.2-20 30C2.2 460.8 0 467.9 0 475.2 0 495.5 16.5 512 36.8 512l374.3 0c20.3 0 36.8-16.5 36.8-36.8 0-7.3-2.2-14.4-6.2-20.4l-20-30 12.8-51.2c8.9-35.5 13.4-72 13.4-108.7l0-17.7c0-36.6-4.5-73.1-13.4-108.7l-12.8-51.2 20-30c4-6.1 6.2-13.2 6.2-20.4 0-20.3-16.5-36.8-36.8-36.8L36.8 0C16.5 0 0 16.5 0 36.8 0 44.1 2.2 51.2 6.2 57.3zM240 319c63.1-7.9 112-61.7 112-127l0-1.6c0-16.8-13.6-30.4-30.4-30.4l-8.9 0c-37.2 0-68.9 17.9-88.7 44.5-19.8-26.6-51.5-44.5-88.7-44.5l-8.9 0C109.6 160 96 173.6 96 190.4l0 1.6c0 65.3 48.9 119.1 112 127l0 33c0 8.8 7.2 16 16 16s16-7.2 16-16l0-33zm-32-32.3c-45.4-7.6-80-47.1-80-94.7l7.3 0c33.6 0 61 20.5 72.7 48.4l0 46.2zm32 0l0-46.2c11.7-27.9 39.1-48.4 72.7-48.4l7.3 0c0 47.6-34.6 87.1-80 94.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBagSeedling = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;