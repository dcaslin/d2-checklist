'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'album-circle-user';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e48d';
var svgPathData = 'M416 64L96 64C78.3 64 64 78.3 64 96l0 320c0 17.7 14.3 32 32 32l150 0c2.9 11.1 6.7 21.8 11.4 32L96 480c-35.3 0-64-28.7-64-64L32 96c0-35.3 28.7-64 64-64l320 0c35.3 0 64 28.7 64 64l0 118c-10.4-2.7-21-4.5-32-5.4L448 96c0-17.7-14.3-32-32-32zM256 96c72.1 0 133.1 47.7 153.1 113.4-10.8 1.3-21.3 3.5-31.5 6.5-16.8-51-64.9-87.8-121.6-87.8-70.7 0-128 57.3-128 128 0 65.5 49.2 119.6 112.7 127.1-1 11.4-.9 22.4-.1 32.2-81.1-7.7-144.6-76.1-144.6-159.3 0-88.4 71.6-160 160-160zm0 136a24 24 0 1 1 0 48 24 24 0 1 1 0-48zM492 494.6c-7.8-9.1-19.4-14.6-31.8-14.6l-56.4 0c-12.4 0-23.9 5.5-31.8 14.6 17.3 11 37.9 17.4 60 17.4s42.7-6.4 60-17.4zm24.3-20.8c17.3-19.7 27.7-45.5 27.7-73.8 0-61.9-50.1-112-112-112S320 338.1 320 400c0 28.2 10.5 54.1 27.7 73.8 13.8-16.1 34.2-25.8 56.1-25.8l56.4 0c21.8 0 42.2 9.6 56.1 25.8zM288 400a144 144 0 1 1 288 0 144 144 0 1 1 -288 0zm144 0a24 24 0 1 0 0-48 24 24 0 1 0 0 48zm0-80a56 56 0 1 1 0 112 56 56 0 1 1 0-112z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlbumCircleUser = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;