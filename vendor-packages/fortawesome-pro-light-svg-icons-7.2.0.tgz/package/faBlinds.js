'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'blinds';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f8fb';
var svgPathData = 'M.2 48c0 8.8 7.2 16 16 16l112 0 0 272c0 8.8 7.2 16 16 16s16-7.2 16-16l0-272 272 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-416 0c-8.8 0-16 7.2-16 16zm17.1 64L-.6 170c-1.2 4-1.9 8.1-1.9 12.3 0 17.4 10.6 32.3 25.7 38.5L-.6 298c-1.2 4-1.9 8.1-1.9 12.3 0 17.4 10.6 32.3 25.7 38.5L-.6 426c-1.2 4-1.9 8.1-1.9 12.3 0 23 18.7 41.7 41.7 41.7l366.9 0c23.3 0 42.1-18.9 42.1-42.1 0-3.9-.5-7.8-1.6-11.6l-22.4-78.4c14.2-6.8 24-21.3 24-38 0-3.9-.5-7.8-1.6-11.6l-22.4-78.4c14.2-6.8 24-21.3 24-38 0-3.9-.5-7.8-1.6-11.6l-16.7-58.3-33.3 0 19.2 67.1c.3 .9 .4 1.8 .4 2.8 0 5.6-4.5 10.1-10.1 10.1l-197.9 0 0 32 183.9 0 23.8 83.1c.3 .9 .4 1.8 .4 2.8 0 5.6-4.5 10.1-10.1 10.1l-197.9 0 0 32 183.9 0 23.8 83.1c.3 .9 .4 1.8 .4 2.8 0 5.6-4.5 10.1-10.1 10.1L39.2 448c-5.4 0-9.7-4.3-9.7-9.7 0-1 .1-1.9 .4-2.9l25.8-83.4 24.4 0 0-32-41 0c-5.4 0-9.7-4.3-9.7-9.7 0-1 .1-1.9 .4-2.9l25.8-83.4 24.4 0 0-32-41 0c-5.4 0-9.7-4.3-9.7-9.7 0-1 .1-1.9 .4-2.9l20.9-67.4-33.5 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlinds = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;