'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bone';
var width = 640;
var height = 512;
var aliases = [129460];
var unicode = 'f5d7';
var svgPathData = 'M0 200c0-57.4 46.6-104 104-104 49.2 0 90.4 34.1 101.2 80l229.6 0c10.8-45.9 52-80 101.2-80 57.4 0 104 46.6 104 104 0 20.6-6 39.8-16.4 56 10.3 16.2 16.4 35.4 16.4 56 0 57.4-46.6 104-104 104-49.2 0-90.4-34.1-101.2-80l-229.6 0C194.4 381.9 153.2 416 104 416 46.6 416 0 369.4 0 312 0 291.4 6 272.2 16.4 256 6 239.8 0 220.6 0 200zm104-72c-39.8 0-72 32.2-72 72 0 15.5 4.9 29.8 13.2 41.5 6.1 8.7 6.1 20.3 0 29-8.3 11.7-13.2 26-13.2 41.5 0 39.8 32.2 72 72 72 35.5 0 65-25.7 70.9-59.5 1.9-10.9 11.3-20.5 24-20.5L441 304c12.7 0 22.1 9.6 24 20.5 5.9 33.8 35.4 59.5 70.9 59.5 39.8 0 72-32.2 72-72 0-15.5-4.9-29.8-13.2-41.5-6.1-8.7-6.1-20.3 0-29 8.3-11.7 13.2-26 13.2-41.5 0-39.8-32.2-72-72-72-35.5 0-65 25.7-70.9 59.5-1.9 10.9-11.3 20.5-24 20.5L199 208c-12.7 0-22.1-9.6-24-20.5-5.9-33.8-35.4-59.5-70.9-59.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBone = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;