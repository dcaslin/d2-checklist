'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bong';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f55c';
var svgPathData = 'M160 32l-16 0c-8.8 0-16-7.2-16-16s7.2-16 16-16L368 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-16 0 0 185.7c16.5 9.5 31.4 21.5 44.4 35.3l53-53-12.7-12.7c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l48 48c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0l-12.7-12.7-55.7 55.7c20 30.3 31.7 66.6 31.7 105.7 0 46.4-16.5 89-43.9 122.2-3 3.7-7.6 5.8-12.3 5.8l-271.5 0c-4.8 0-9.3-2.1-12.3-5.8-27.4-33.2-43.9-75.8-43.9-122.2 0-71.1 38.6-133.1 96-166.3L160 32zm32 0l0 195.2c0 6-3.4 11.5-8.7 14.2-32.9 16.8-59.1 44.6-74 78.6l293.4 0c-14.8-33.9-41.1-61.8-74-78.6-5.4-2.7-8.7-8.2-8.7-14.2L320 32 192 32zM412.8 352L99.2 352c-2.1 10.3-3.2 21-3.2 32 0 36 11.9 69.3 32 96l256 0c20.1-26.7 32-60 32-96 0-11-1.1-21.7-3.2-32z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBong = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;