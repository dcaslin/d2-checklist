'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bee';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e0b2';
var svgPathData = 'M327.2 2.6c6.2-4.1 14.7-3.4 20.1 2.1s6.2 13.9 2.1 20.1l-2.1 2.5-24.6 24.6C331.1 64.5 336 79.7 336 96l0 21.6C427.7 139.3 496 221.7 496 320l0 48-.3 3.2c-1.5 7.3-8 12.8-15.7 12.8l-32 0c-21.4 0-42.1-3.3-61.6-9.3-28.8 59.8-95.4 115.9-116.2 132.4l-3.2 2.1c-3.4 1.8-7.2 2.8-11.1 2.8s-7.7-.9-11.1-2.8l-3.2-2.1c-20.7-16.5-87.4-72.6-116.2-132.4-19.4 6-40.1 9.3-61.5 9.3l-32 0c-7.7 0-14.2-5.5-15.7-12.8l-.3-3.2 0-48c0-98.4 68.3-180.7 160-202.4L176 96c0-16.3 4.9-31.5 13.2-44.1l-24.6-24.6-2.1-2.5c-4.1-6.2-3.4-14.7 2.1-20.1s13.9-6.2 20.1-2.1l2.5 2.1 24.6 24.6c12.6-8.4 27.8-13.2 44.1-13.2 16.3 0 31.4 4.9 44.1 13.2l24.6-24.6 2.5-2.1zM206.9 432c18.9 19.8 37.5 35.9 49.1 45.4 11.5-9.5 30.1-25.6 49.1-45.4l-98.1 0zm-48.8-64c5.6 10.3 12.8 21.1 21.2 32l153.5 0c8.4-10.9 15.5-21.7 21.2-32l-195.8 0zM224 144c-97.2 0-176 78.8-176 176l0 32 16 0c97.2 0 176-78.8 176-176l0-32-16 0zm48 32c0 97.2 78.8 176 176 176l16 0 0-32c0-97.2-78.8-176-176-176l-16 0 0 32zm-16 80.1c-13 31.2-33.5 58.6-59.1 79.9l118.3 0c-25.7-21.3-46.1-48.7-59.1-79.9zM256 48c-26.5 0-48 21.5-48 48l0 16.7c5.3-.4 10.6-.7 16-.7l64 0c5.4 0 10.7 .3 16 .7L304 96c0-26.5-21.5-48-48-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBee = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;