'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-up-from-square';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e09c';
var svgPathData = 'M240 22.6l52.7 52.7c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6l-80-80c-6.2-6.2-16.4-6.2-22.6 0l-80 80c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L208 22.6 208 304c0 8.8 7.2 16 16 16s16-7.2 16-16l0-281.4zM32 192c0-17.7 14.3-32 32-32l48 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-48 0c-35.3 0-64 28.7-64 64L0 448c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64l-48 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l48 0c17.7 0 32 14.3 32 32l0 256c0 17.7-14.3 32-32 32L64 480c-17.7 0-32-14.3-32-32l0-256z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpFromSquare = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;