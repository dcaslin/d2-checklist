'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'book-heart';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f499';
var svgPathData = 'M0 64C0 28.7 28.7 0 64 0L400 0c26.5 0 48 21.5 48 48l0 320c0 20.9-13.4 38.7-32 45.3l0 66.7 16 0c8.8 0 16 7.2 16 16s-7.2 16-16 16L64 512c-35.3 0-64-28.7-64-64l0 0 0-384zM64 416c-17.7 0-32 14.3-32 32s14.3 32 32 32l320 0 0-64-320 0zM32 392.6c9.4-5.4 20.3-8.6 32-8.6l336 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 32C46.3 32 32 46.3 32 64l0 328.6zM244.4 154.2l-9.1 9.1c-3 3-7.1 4.7-11.3 4.7s-8.3-1.7-11.3-4.7l-9.1-9.1c-6.5-6.5-15.4-10.2-24.7-10.2l-2.9 0c-17.7 0-32 14.3-32 32 0 21.4 14.5 42.5 34.6 61 16.8 15.5 35.4 27 45.4 32.7 10-5.7 28.5-17.2 45.4-32.7 20.1-18.5 34.6-39.7 34.6-61 0-17.7-14.3-32-32-32l-2.9 0c-9.3 0-18.1 3.7-24.7 10.2zM269.1 112l2.9 0c35.3 0 64 28.7 64 64 0 35.3-23.1 64.5-45 84.6-22.4 20.6-46.8 34.7-55.9 39.6-7 3.8-15.3 3.8-22.2 0-9.1-4.9-33.5-19-55.9-39.6-21.8-20.1-45-49.3-45-84.6 0-35.3 28.7-64 64-64l2.9 0c16.7 0 32.8 6.3 45.1 17.5 12.3-11.2 28.4-17.5 45.1-17.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookHeart = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;