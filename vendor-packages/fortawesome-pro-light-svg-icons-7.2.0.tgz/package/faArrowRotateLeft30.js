'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrow-rotate-left-30';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e887';
var svgPathData = 'M256 0C397.4 0 512 114.6 512 256S397.4 512 256 512c-98.3 0-183.6-55.4-226.5-136.5-4.1-7.8-1.1-17.5 6.7-21.6s17.5-1.1 21.6 6.7C95.4 431.6 170.1 480 256 480 379.7 480 480 379.7 480 256S379.7 32 256 32c-62 0-121.2 25.5-163.8 70.6L27.6 171c-4.5 4.8-11.4 6.3-17.5 3.9S0 166.6 0 160L0 16C0 7.2 7.2 0 16 0S32 7.2 32 16l0 103.8 37-39.1C117.6 29.2 185.2 0 256 0zM176 160c30.9 0 56 25.1 56 56 0 15.7-6.5 29.8-16.9 40 10.4 10.2 16.9 24.3 16.9 40 0 30.9-25.1 56-56 56l-40 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l40 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-32 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l32 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-40 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l40 0zm160 0c30.9 0 56 25.1 56 56l0 80c0 30.9-25.1 56-56 56l-16 0c-30.9 0-56-25.1-56-56l0-80c0-30.9 25.1-56 56-56l16 0zm-16 32c-13.3 0-24 10.7-24 24l0 80c0 13.3 10.7 24 24 24l16 0c13.3 0 24-10.7 24-24l0-80c0-13.3-10.7-24-24-24l-16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateLeft30 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;