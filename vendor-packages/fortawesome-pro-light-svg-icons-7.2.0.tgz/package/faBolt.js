'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'bolt';
var width = 448;
var height = 512;
var aliases = [9889,"zap"];
var unicode = 'f0e7';
var svgPathData = 'M284.1 192L349.7 27.9c5.4-13.6 1-29.2-10.9-37.8s-28-8.1-39.3 1.3l-288 240C1.2 240-2.7 254.2 1.9 266.9S18.5 288 32 288l144.7 0-12.8 32-65.6 164.1c-5.4 13.6-.9 29.2 10.9 37.8s28 8.1 39.3-1.3l288-240c10.3-8.6 14.2-22.8 9.6-35.5S429.5 224 416 224l-144.7 0 12.8-32zm-80.8 78.1c-6-8.8-15.9-14.1-26.5-14.1L32 256 320 16 241.6 212.1c-3.9 9.9-2.7 21 3.2 29.8S260.6 256 271.3 256l144.7 0-288 240 78.4-196.1c3.9-9.9 2.7-21-3.2-29.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBolt = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;