'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrows-turn-right';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e4c0';
var svgPathData = 'M332.7-3.3c6.2-6.2 16.4-6.2 22.6 0l88 88c6.2 6.2 6.2 16.4 0 22.6l-88 88c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6L393.4 112 128 112c-53 0-96 43-96 96l0 32c0 8.8-7.2 16-16 16S0 248.8 0 240l0-32C0 137.3 57.3 80 128 80l265.4 0-60.7-60.7c-6.2-6.2-6.2-16.4 0-22.6zm-88 264c6.2-6.2 16.4-6.2 22.6 0l80 80c6.2 6.2 6.2 16.4 0 22.6l-80 80c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6L297.4 368 96 368c-35.3 0-64 28.7-64 64l0 32c0 8.8-7.2 16-16 16S0 472.8 0 464l0-32c0-53 43-96 96-96l201.4 0-52.7-52.7c-6.2-6.2-6.2-16.4 0-22.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsTurnRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;