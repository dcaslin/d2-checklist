'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'alarm-exclamation';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f843';
var svgPathData = 'M256 64c123.7 0 224 100.3 224 224 0 56.1-20.6 107.4-54.7 146.7l50 50c6.2 6.2 6.2 16.4 0 22.6s-16.4 6.2-22.6 0l-50-50C363.4 491.4 312.1 512 256 512s-107.4-20.6-146.7-54.7l-50 50c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l50-50C52.6 395.4 32 344.1 32 288 32 164.3 132.3 64 256 64zm0 32a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm0 320a24 24 0 1 1 0-48 24 24 0 1 1 0 48zm0-256c13.5 0 24.3 11.4 23.5 24.9l-7.6 136c-.5 8.5-7.5 15.1-16 15.1s-15.5-6.6-16-15.1l-7.6-136c-.8-13.5 10-24.9 23.5-24.9zM95.2 0c19.3 0 37.3 5.8 52.3 15.7 9.5 6.3 6.3 19.9-4.1 24.6l-.8 .4c-5.6 2.6-12.1 1.8-17.5-1.1-8.9-4.8-19.1-7.6-30-7.6-34.9 0-63.2 28.3-63.2 63.2 0 6.8 1.1 13.4 3.1 19.5 1.9 5.8 1.5 12.4-2.1 17.4l-.5 .7C26 142.3 12 143 7.6 132.5 2.7 121.1 0 108.5 0 95.2 0 42.6 42.6 0 95.2 0zM416.7 0c52.6 0 95.3 42.6 95.3 95.2 0 13.2-2.7 25.8-7.6 37.3-4.5 10.5-18.4 9.8-25 .4l-.5-.7c-3.5-5-4-11.6-2.1-17.4 2-6.2 3.1-12.7 3.1-19.5 0-34.9-28.3-63.2-63.3-63.2-10.9 0-21.1 2.7-30 7.6-5.4 2.9-11.9 3.7-17.5 1.1l-.7-.4c-10.4-4.7-13.7-18.3-4.1-24.6 15-9.9 33-15.7 52.3-15.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlarmExclamation = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;