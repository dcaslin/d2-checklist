'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'barn';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6c7';
var svgPathData = 'M250.5 35.6L78 104.6c-4.9 2-8.5 6.2-9.7 11.3l-31.8 140.1 12 0c8.8 0 16 7.2 16 16l0 176c0 17.7 14.3 32 32 32l48 0 0-160c0-17.7 14.3-32 32-32l160 0c17.7 0 32 14.3 32 32l0 160 48 0c17.7 0 32-14.3 32-32l0-176c0-8.8 7.2-16 16-16l12 0-31.8-140.1c-1.2-5.1-4.8-9.4-9.7-11.3l-172.5-69c-3.8-1.5-8.1-1.5-11.9 0zM176.5 480l137.4 0-137.4-137.4 0 137.4zm0 32l-80 0c-35.3 0-64-28.7-64-64l0-160-6 0C11.1 288-.3 273.7 3.1 258.7L37.2 108.8c3.5-15.4 14.3-28.1 29-33.9l172.5-69c11.4-4.6 24.2-4.6 35.7 0l172.5 69c14.6 5.9 25.5 18.5 29 33.9l34.1 149.8c3.4 15-8 29.3-23.4 29.3l-6 0 0 160c0 35.3-28.7 64-64 64l-240 0zm56-400l48 0c22.1 0 40 17.9 40 40l0 48c0 22.1-17.9 40-40 40l-48 0c-22.1 0-40-17.9-40-40l0-48c0-22.1 17.9-40 40-40zm-8 40l0 48c0 4.4 3.6 8 8 8l48 0c4.4 0 8-3.6 8-8l0-48c0-4.4-3.6-8-8-8l-48 0c-4.4 0-8 3.6-8 8zm112 305.4l0-137.4-137.4 0 137.4 137.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;