'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'almost-equal-to';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e818';
var svgPathData = 'M111.4 320c12.7 0 25.4 2.1 37.5 6.1l160.4 53.5 6.7 1.9c6.7 1.7 13.7 2.5 20.7 2.5 32.8 0 62.7-18.5 77.4-47.8l3.7-7.3c3.9-7.9 13.6-11.1 21.5-7.2s11.1 13.6 7.2 21.5l-3.7 7.3c-20.1 40.2-61.1 65.5-106 65.5-12.7 0-25.4-2.1-37.5-6.1L138.7 356.4c-8.8-2.9-18.1-4.4-27.3-4.4-32.8 0-62.8 18.5-77.4 47.8l-3.7 7.3c-4 7.9-13.6 11.1-21.5 7.2s-11.1-13.6-7.2-21.5l3.7-7.3 4-7.4c21.2-35.9 59.9-58.2 102-58.2zm0-224c12.7 0 25.4 2.1 37.5 6.1l160.4 53.5 6.7 1.9c6.7 1.7 13.7 2.5 20.7 2.5 32.8 0 62.7-18.5 77.4-47.8l3.7-7.3c3.9-7.9 13.6-11.1 21.5-7.2s11.1 13.6 7.2 21.5l-3.7 7.3c-20.1 40.1-61.1 65.5-106 65.5-12.7 0-25.4-2.1-37.5-6.1L138.7 132.4c-8.8-2.9-18.1-4.4-27.3-4.4-32.8 0-62.7 18.5-77.4 47.8l-3.7 7.3c-4 7.9-13.6 11.1-21.5 7.2s-11.1-13.6-7.2-21.5l3.7-7.3 4-7.4C30.6 118.3 69.3 96 111.4 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlmostEqualTo = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;