'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fal';
var iconName = 'arrows-rotate';
var width = 512;
var height = 512;
var aliases = [128472,"refresh","sync"];
var unicode = 'f021';
var svgPathData = 'M32.5 241.1C36 188.8 57.7 137.6 97.6 97.6 141.3 53.9 198.6 32 256 32 318 32 377.2 57.5 419.8 102.6L458.9 144 352 144c-8.8 0-16 7.2-16 16s7.2 16 16 16l144 0c8.8 0 16-7.2 16-16l0-144c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 103.8-37-39.1C394.4 29.2 326.8 0 256 0 190.5 0 125 25 75 75 29.3 120.6 4.5 179.2 .6 238.9 0 247.8 6.7 255.4 15.5 256s16.4-6.1 17-14.9zm447 29.9c-3.5 52.3-25.2 103.5-65.1 143.4-43.7 43.7-101 65.6-158.4 65.6-62 0-121.2-25.5-163.8-70.6L53.1 368 160 368c8.8 0 16-7.2 16-16s-7.2-16-16-16L16 336c-8.8 0-16 7.2-16 16L0 496c0 8.8 7.2 16 16 16s16-7.2 16-16l0-103.8 37 39.1c48.6 51.5 116.3 80.6 187 80.6 65.5 0 131-25 181-75 45.6-45.6 70.4-104.3 74.4-164 .6-8.8-6.1-16.4-14.9-17s-16.4 6.1-17 14.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsRotate = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;