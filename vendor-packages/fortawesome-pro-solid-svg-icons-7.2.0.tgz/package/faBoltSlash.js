'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bolt-slash';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0b8';
var svgPathData = 'M41-24.9c-9.4-9.4-24.6-9.4-33.9 0S-2.3-.3 7 9.1l528 528c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-152.5-152.5 84-70c10.3-8.6 14.2-22.8 9.6-35.5S493.5 224 480 224l-144.7 0 78.4-196.1c5.4-13.6 1-29.2-10.9-37.8s-28-8.1-39.3 1.3L196.5 130.6 41-24.9zm193.3 329l-72 180c-5.4 13.6-.9 29.2 10.9 37.8s28 8.1 39.3-1.3l130-108.3-108.2-108.2zM122.5 192.3l-47 39.1c-10.3 8.6-14.2 22.8-9.6 35.5S82.5 288 96 288l122.2 0-95.7-95.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoltSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;