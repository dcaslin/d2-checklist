'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bahai';
var width = 576;
var height = 512;
var aliases = ["haykal"];
var unicode = 'f666';
var svgPathData = 'M288.4-8c13.2 0 25 8.1 29.8 20.4l31.9 82 77.2-42.3c11.6-6.3 25.8-4.9 35.9 3.5s14 22.3 9.7 34.8l-28.2 83.3 86.3 17.2c12.9 2.6 23 12.8 25.3 25.8s-3.6 26.1-14.9 32.9l-75.2 45.7 55 68.6c8.3 10.3 9.3 24.6 2.7 36s-19.5 17.6-32.6 15.6l-87-13.3-2 88c-.3 13.2-8.6 24.8-21 29.4s-26.3 1-35-9l-58-66.1-58 66.1c-8.7 9.9-22.6 13.5-35 9s-20.8-16.2-21-29.4l-2-88-87 13.3c-13 2-26-4.2-32.6-15.6s-5.5-25.7 2.7-36l55-68.6-75.2-45.7c-11.3-6.8-17.2-19.9-14.9-32.9s12.3-23.2 25.3-25.8l86.3-17.2-28.2-83.3c-4.2-12.5-.4-26.3 9.7-34.8s24.4-9.9 35.9-3.5l77.1 42.3 31.9-82C263.3 .1 275.2-8 288.4-8zm0 120.2L273 151.6c-3.3 8.6-10.2 15.3-18.9 18.5s-18.2 2.4-26.3-2l-37-20.3 13.6 40c3 8.7 2 18.3-2.6 26.3s-12.4 13.6-21.5 15.4l-41.4 8.3 36.1 21.9c7.9 4.8 13.3 12.7 14.9 21.8s-.8 18.4-6.5 25.6l-26.4 33 41.8-6.4c9.1-1.4 18.4 1.2 25.4 7.1s11.2 14.6 11.4 23.8l.9 42.2 27.9-31.8c6.1-6.9 14.8-10.9 24.1-10.9s18 4 24.1 10.9l27.9 31.8 .9-42.2c.2-9.2 4.4-17.9 11.4-23.8s16.3-8.5 25.4-7.1l41.8 6.4-26.4-33c-5.8-7.2-8.2-16.5-6.6-25.6s7-17 14.9-21.8l36.1-21.9-41.4-8.3c-9-1.8-16.9-7.4-21.5-15.4s-5.5-17.6-2.6-26.3l13.6-40-37 20.3c-8.1 4.4-17.7 5.2-26.3 2s-15.5-9.9-18.9-18.5l-15.3-39.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBahai = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;