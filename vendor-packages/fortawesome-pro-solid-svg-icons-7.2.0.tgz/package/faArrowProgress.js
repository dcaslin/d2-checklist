'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrow-progress';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e5df';
var svgPathData = 'M230.8 33.8c9-3.7 19.3-1.7 26.2 5.2l40 40c9.4 9.4 9.4 24.6 0 33.9l-40 40c-6.9 6.9-17.2 8.9-26.2 5.2S216 145.7 216 136l0-8-104 0c-26.5 0-48 21.5-48 48s21.5 48 48 48l288 0c61.9 0 112 50.1 112 112 0 46.4-28.2 86.1-68.3 103.2-9.3 23.9-32.5 40.8-59.7 40.8-35.3 0-64-28.7-64-64s28.7-64 64-64c18.6 0 35.4 7.9 47 20.6 10.4-8.8 17-21.9 17-36.6 0-26.5-21.5-48-48-48l-288 0C50.1 288 0 237.9 0 176S50.1 64 112 64l104 0 0-8c0-9.7 5.8-18.5 14.8-22.2zM416 32a64 64 0 1 1 0 128 64 64 0 1 1 0-128zM151.4 448c-11.1 19.1-31.7 32-55.4 32-35.3 0-64-28.7-64-64s28.7-64 64-64c23.7 0 44.4 12.9 55.4 32l32.6 0 0-8c0-9.7 5.8-18.5 14.8-22.2s19.3-1.7 26.2 5.2l40 40c9.4 9.4 9.4 24.6 0 33.9l-40 40c-6.9 6.9-17.2 8.9-26.2 5.2S184 465.7 184 456l0-8-32.6 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowProgress = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;