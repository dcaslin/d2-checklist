'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bench-tree';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e2e7';
var svgPathData = 'M352 352c17.7 0 32 14.3 32 32s-14.3 32-32 32l0 64c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-64-192 0 0 64c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-64c-17.7 0-32-14.3-32-32s14.3-32 32-32l320 0zM512 0c53 0 96 43 96 96 0 5.1-.4 10.2-1.2 15.1 20.1 14.5 33.2 38.2 33.2 64.9 0 44.2-35.8 80-80 80l-16 0 0 224c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-224-16 0c-44.2 0-80-35.8-80-80 0-26.7 13.1-50.3 33.2-64.9-.8-4.9-1.2-10-1.2-15.1 0-53 43-96 96-96zM320 192c17.7 0 32 14.3 32 32l0 48c0 17.7-14.3 32-32 32L64 304c-17.7 0-32-14.3-32-32l0-48c0-17.7 14.3-32 32-32l256 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBenchTree = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;