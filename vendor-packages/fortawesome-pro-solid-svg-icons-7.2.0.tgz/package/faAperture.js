'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'aperture';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e2df';
var svgPathData = 'M256 0c.8 0 1.5 0 2.3 0 11.6 .1 18.1 12.7 12.3 22.7L177.5 184c-6.2 10.7-21.6 10.7-27.7 0L89 78.8C85.3 72.3 86.5 64 92.2 59.2 136.6 22.2 193.7 0 256 0zM0 256c0-47.5 12.9-91.9 35.4-130.1 5.9-10 20-9.3 25.8 .8L154.4 288c6.2 10.7-1.5 24-13.9 24L19 312c-7.5 0-14-5.2-15.3-12.6-2.4-14.1-3.7-28.6-3.7-43.4zM186 489.3c-3.7 6.5-11.5 9.6-18.5 7-57.1-21.1-104.7-61.9-134.3-114.3-5.7-10.1 2-22 13.5-22l186.3 0c12.3 0 20 13.3 13.9 24L186 489.3zM256 512c-.8 0-1.5 0-2.3 0-11.6-.1-18.1-12.7-12.3-22.7L334.5 328c6.2-10.7 21.6-10.7 27.7 0L423 433.2c3.7 6.5 2.5 14.7-3.2 19.5-44.4 37-101.5 59.2-163.8 59.2zM512 256c0 47.5-12.9 91.9-35.4 130.1-5.9 10-20 9.3-25.8-.8L357.6 224c-6.2-10.7 1.5-24 13.9-24L493 200c7.5 0 14 5.2 15.3 12.6 2.4 14.1 3.7 28.6 3.7 43.4zM326 22.7c3.7-6.5 11.5-9.6 18.5-7 57.1 21.1 104.7 61.9 134.3 114.3 5.7 10.1-2 22-13.5 22l-186.3 0c-12.3 0-20-13.3-13.9-24L326 22.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAperture = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;