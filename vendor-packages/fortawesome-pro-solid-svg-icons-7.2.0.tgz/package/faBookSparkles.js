'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'book-sparkles';
var width = 448;
var height = 512;
var aliases = ["book-spells"];
var unicode = 'f6b8';
var svgPathData = 'M384 512L96 512c-53 0-96-43-96-96L0 96C0 43 43 0 96 0L400 0c26.5 0 48 21.5 48 48l0 288c0 20.9-13.4 38.7-32 45.3l0 66.7c17.7 0 32 14.3 32 32s-14.3 32-32 32l-32 0zM96 384c-17.7 0-32 14.3-32 32s14.3 32 32 32l256 0 0-64-256 0zM259.2 195.2l-46.6 20c-7.8 3.3-7.8 14.3 0 17.6l46.6 20 20 46.6c3.3 7.8 14.3 7.8 17.6 0l20-46.6 46.6-20c7.8-3.3 7.8-14.3 0-17.6l-46.6-20-20-46.6c-3.3-7.8-14.3-7.8-17.6 0l-20 46.6zM150.5 83.1l-11.8 23.6-23.6 11.8c-7.9 3.9-7.9 15.2 0 19.1l23.6 11.8 11.8 23.6c3.9 7.9 15.2 7.9 19.1 0l11.8-23.6 23.6-11.8c7.9-3.9 7.9-15.2 0-19.1l-23.6-11.8-11.8-23.6c-3.9-7.9-15.2-7.9-19.1 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookSparkles = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;