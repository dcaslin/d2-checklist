'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'avocado';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e0aa';
var svgPathData = 'M459.4 255.3c-18.5 15.2-33.5 35.6-38.1 59.1-10.2 51.9-34 104.5-66.3 136.7-81.2 81.2-212.9 81.2-294.2 0s-81.2-212.9 0-294.2c32.3-32.3 84.9-56.1 136.7-66.3 23.5-4.6 43.9-19.6 59.1-38.1 26.4-32.1 66.4-52.6 111.3-52.6 79.5 0 144 64.5 144 144 0 44.8-20.5 84.9-52.6 111.3zM283.2 347.2c41.7-41.7 49.1-102.1 16.4-134.8s-93-25.3-134.8 16.4-49.1 102.1-16.4 134.8 93 25.3 134.8-16.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAvocado = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;