'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bicep';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e862';
var svgPathData = 'M216.1 0c30.9 0 56 25.1 56 56l0 16c0 48.6-39.4 88-88 88l-20.7 0 9.2 120.8 0 0 3.8 48.9c1 13.2 12.5 23.1 25.7 22.1 13.2-1 23.1-12.5 22.1-25.8l-5.7-74.4c35.4-17.7 75.3-27.6 117.6-27.6 57.5 0 110.7 18.4 154.1 49.6 14.7 10.6 22 27.4 22 43.9l-.1 116.6c0 29.5-22.9 53.9-52.2 55.8l-330.2 22c-.5 0-1.1 .1-1.6 .1-70.7 0-128-57.3-128-128 0-133.1 22.6-254.5 37-318.5 8.9-39.4 44.1-65.5 83.3-65.5l95.7 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBicep = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;