'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrows-repeat-1';
var width = 512;
var height = 512;
var aliases = ["repeat-1-alt"];
var unicode = 'f366';
var svgPathData = 'M480 96c0 8.5-3.4 16.6-9.4 22.6l-80 80c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L370.7 128 192 128c-70.7 0-128 57.3-128 128 0 17.7-14.3 32-32 32S0 273.7 0 256C0 150 86 64 192 64l178.7 0-25.4-25.4c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l80 80c6 6 9.4 14.1 9.4 22.6zM32 416c0-8.5 3.4-16.6 9.4-22.6l80-80c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3L141.3 384 320 384c70.7 0 128-57.3 128-128 0-17.7 14.3-32 32-32s32 14.3 32 32c0 106-86 192-192 192l-178.7 0 25.4 25.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0l-80-80c-6-6-9.4-14.1-9.4-22.6zM288 216l0 80c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-48c-10 0-19.4-6.4-22.8-16.4-4.2-12.6 2.6-26.2 15.2-30.4l24-8c7.3-2.4 15.4-1.2 21.6 3.3s10 11.8 10 19.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsRepeat1 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;