'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'angle-90';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e08d';
var svgPathData = 'M64 64c0-17.7-14.3-32-32-32S0 46.3 0 64L0 416c0 35.3 28.7 64 64 64l352 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L64 416 64 64zm94.3 96.8c11.5 4.2 24.6 .4 31.1-9.9 7.6-12.2 3-28.4-10.4-33.6-21.3-8.2-43.7-14.2-66.9-17.7l0 48.6c16 2.8 31.4 7.1 46.3 12.6zM329.1 290.6c-10.4 6.5-14.2 19.6-9.9 31.1 5.5 14.9 9.7 30.3 12.6 46.3l48.6 0c-3.5-23.2-9.5-45.6-17.7-66.9-5.2-13.4-21.4-18.1-33.6-10.4zm-22.7-42.4c11.6-7.3 14.9-22.8 6.3-33.5-14.1-17.4-30-33.3-47.4-47.4-10.7-8.6-26.2-5.4-33.5 6.3-6.8 10.9-3.8 25.1 6.1 33.3 12.8 10.7 24.7 22.5 35.3 35.3 8.2 9.9 22.4 12.8 33.3 6.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAngle90 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;