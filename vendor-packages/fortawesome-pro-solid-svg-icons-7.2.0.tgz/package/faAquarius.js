'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'aquarius';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e845';
var svgPathData = 'M401.7 291.4c9-4.5 19.6-4.5 28.6 0l128 64c15.8 7.9 22.2 27.1 14.3 42.9s-27.1 22.2-42.9 14.3L416 355.8 302.3 412.6c-9 4.5-19.6 4.5-28.6 0L160 355.8 46.3 412.6c-15.8 7.9-35 1.5-42.9-14.3s-1.5-35 14.3-42.9l128-64c9-4.5 19.6-4.5 28.6 0L288 348.2 401.7 291.4zm3.4-193.5c8.2-3 17.3-2.5 25.2 1.5l128 64c15.8 7.9 22.2 27.1 14.3 42.9s-27.1 22.2-42.9 14.3L416 163.8 302.3 220.6c-9 4.5-19.6 4.5-28.6 0L160 163.8 46.3 220.6c-15.8 7.9-35 1.5-42.9-14.3s-1.5-35 14.3-42.9l128-64 3.4-1.5c8.2-3 17.3-2.5 25.2 1.5l113.7 56.8 113.7-56.8 3.4-1.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAquarius = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;