'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'barn';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6c7';
var svgPathData = 'M1 252.4L41.6 103.4c4-14.7 14.8-26.7 29.1-32.2L238.8 6.6c11.1-4.3 23.4-4.3 34.5 0L441.3 71.3c14.3 5.5 25.1 17.4 29.1 32.2L511 252.4c.7 2.4 1 4.9 1 7.4 0 15.6-12.6 28.2-28.2 28.2l-3.8 0 0 160c0 35.3-28.7 64-64 64L96 512c-35.3 0-64-28.7-64-64l0-160-3.8 0c-15.6 0-28.2-12.6-28.2-28.2 0-2.5 .3-5 1-7.4zM208 136l0 48c0 13.3 10.7 24 24 24l48 0c13.3 0 24-10.7 24-24l0-48c0-13.3-10.7-24-24-24l-48 0c-13.3 0-24 10.7-24 24zM160 432c0 17.7 14.3 32 32 32L316.5 464 160 320.6 160 432zm35.5-144L352 431.4 352 320c0-17.7-14.3-32-32-32l-124.5 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;