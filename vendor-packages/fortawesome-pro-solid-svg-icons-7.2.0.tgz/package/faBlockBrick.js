'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'block-brick';
var width = 448;
var height = 512;
var aliases = ["wall-brick"];
var unicode = 'e3db';
var svgPathData = 'M128 32l0 80 192 0 0-80-192 0zM96 112l0-80-32 0C28.7 32 0 60.7 0 96l0 16 96 0zM0 144l0 96 208 0 0-96-208 0zM0 368l96 0 0-96-96 0 0 96zm0 32l0 16c0 35.3 28.7 64 64 64l144 0 0-80-208 0zm240 0l0 80 144 0c35.3 0 64-28.7 64-64l0-16-208 0zm208-32l0-96-96 0 0 96 96 0zm-128 0l0-96-192 0 0 96 192 0zM448 144l-208 0 0 96 208 0 0-96zm0-32l0-16c0-35.3-28.7-64-64-64l-32 0 0 80 96 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlockBrick = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;