'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'acorn';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f6ae';
var svgPathData = 'M399.6 240c-4.1 78.1-39 189.3-165.5 236.4-6.5 2.4-13.7 2.4-20.2 0-126.5-47.2-161.4-158.3-165.5-236.4l351.1 0zM228.8 9.6c8-10.6 23-12.8 33.6-4.8s12.7 23 4.8 33.6l-4.8 6.4c-4.4 5.9-7.9 12.4-10.3 19.2L352 64c53 0 96 43 96 96 0 17.7-14.3 32-32 32L32 192c-17.7 0-32-14.3-32-32 0-53 43-96 96-96l106.4 0C206 46.7 213.3 30.3 224 16l4.8-6.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAcorn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;