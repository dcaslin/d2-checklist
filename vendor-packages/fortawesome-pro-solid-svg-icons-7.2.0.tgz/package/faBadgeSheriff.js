'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'badge-sheriff';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f8a2';
var svgPathData = 'M304.4 16c0 15.1-7 28.6-17.9 37.4l32.8 58.3c5.7 10.1 16.3 16.3 27.9 16.3l69.8 0c2.3-13.6 10.4-26.1 23.3-33.6 23-13.3 52.3-5.4 65.6 17.6s5.4 52.3-17.6 65.6c-13 7.5-27.9 8.2-40.9 3.4L411 239c-6.5 10.4-6.5 23.5 0 33.9l36.3 58.1c13-4.9 28-4.1 40.9 3.4 23 13.3 30.8 42.6 17.6 65.6s-42.6 30.8-65.6 17.6c-12.9-7.4-21-20-23.3-33.6l-69.8 0c-11.6 0-22.2 6.2-27.9 16.3l-32.8 58.3c10.9 8.8 17.9 22.3 17.9 37.4 0 26.5-21.5 48-48 48s-48-21.5-48-48c0-15.1 7-28.6 17.9-37.4l-32.8-58.3c-5.7-10.1-16.3-16.3-27.9-16.3l-69.8 0c-2.3 13.6-10.4 26.1-23.3 33.6-23 13.3-52.3 5.4-65.6-17.6s-5.4-52.3 17.6-65.6c13-7.5 27.9-8.2 40.9-3.4L101.8 273c6.5-10.4 6.5-23.5 0-33.9L65.4 180.9c-13 4.9-28 4.1-40.9-3.3-23-13.3-30.8-42.6-17.6-65.6S49.5 81.2 72.5 94.4c12.9 7.4 21 20 23.3 33.6l69.8 0c11.6 0 22.2-6.2 27.9-16.3l32.8-58.3c-10.9-8.8-17.9-22.3-17.9-37.4 0-26.5 21.5-48 48-48s48 21.5 48 48zm-48 304a64 64 0 1 0 -.7-128 64 64 0 1 0 .7 128z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBadgeSheriff = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;