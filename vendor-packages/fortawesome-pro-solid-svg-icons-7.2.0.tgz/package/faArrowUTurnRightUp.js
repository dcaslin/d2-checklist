'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrow-u-turn-right-up';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e7ec';
var svgPathData = 'M396.3 7.2c12.6-10.3 31.1-9.5 42.8 2.2l112 112c12.5 12.5 12.5 32.8 0 45.2s-32.8 12.5-45.2 0l-57.4-57.4 0 210.8c0 102.7-80.7 186.6-182.1 191.8l-9.9 .2c-106 0-192-86-192-192l0-224 .2-3.3C66.3 76.6 79.9 64 96.5 64s30.2 12.6 31.8 28.7l.2 3.3 0 224c0 70.7 57.3 128 128 128l6.6-.2c67.6-3.4 121.4-59.4 121.4-127.8l0-210.8-57.4 57.4-2.4 2.2c-12.6 10.2-31.1 9.5-42.8-2.2s-12.4-30.2-2.2-42.8l2.2-2.4 112-112 2.4-2.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUTurnRightUp = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;