'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bell-school';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f5d5';
var svgPathData = 'M272 128a80 80 0 1 1 0 160 80 80 0 1 1 0-160zm0 288a208 208 0 1 0 0-416 208 208 0 1 0 0 416zm288-64c0-26.5-21.5-48-48-48s-48 21.5-48 48c0 17.8 9.6 33.3 24 41.6-.8 39-32.7 70.4-72 70.4l-2 0c1.3-5.1 2-10.5 2-16l0-28.3c-41 28-90.6 44.3-144 44.3s-103-16.3-144-44.3l0 28.3c0 35.3 28.7 64 64 64l224 0c65.7 0 119.1-52.9 120-118.4 14.4-8.3 24-23.8 24-41.6zM272 240a32 32 0 1 0 0-64 32 32 0 1 0 0 64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellSchool = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;