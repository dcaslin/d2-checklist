'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrow-rotate-right-30';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e889';
var svgPathData = 'M480 0c17.7 0 32 14.3 32 32l0 160c0 14.3-9.5 26.9-23.2 30.8s-28.4-1.7-36-13.9l-32-51.4-.1-.2-.1-.2C386.9 101.2 325.8 64 256 64 150 64 64 150 64 256s86 192 192 192c65.2 0 122.8-32.5 157.6-82.3 10.1-14.5 30.1-18 44.6-7.9s18 30.1 7.9 44.6C419.9 468.6 343 512 256 512 114.6 512 0 397.4 0 256S114.6 0 256 0c76.5 0 145.1 33.6 192 86.7L448 32c0-17.7 14.3-32 32-32zM180 160c33.1 0 60 26.9 60 60 0 13.5-4.5 26-12.1 36 7.6 10 12.1 22.5 12.1 36 0 33.1-26.9 60-60 60l-28 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l28 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-20 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l20 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-28 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l28 0zm164 0c30.9 0 56 25.1 56 56l0 80c0 30.9-25.1 56-56 56l-16 0c-30.9 0-56-25.1-56-56l0-80c0-30.9 25.1-56 56-56l16 0zm-16 48c-4.4 0-8 3.6-8 8l0 80c0 4.4 3.6 8 8 8l16 0c4.4 0 8-3.6 8-8l0-80c0-4.4-3.6-8-8-8l-16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateRight30 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;