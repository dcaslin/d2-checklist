'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bin-recycle';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e5f7';
var svgPathData = 'M0 96C0 78.3 14.3 64 32 64l512 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-2.9 0-23.8 261.8c-3 33-30.6 58.2-63.7 58.2l-331.1 0c-33.1 0-60.7-25.2-63.7-58.2L34.9 128 32 128C14.3 128 0 113.7 0 96zm288 96c2.1 0 4 1 5.2 2.8l22.6 33.1c7.3 10.6 21.6 13.6 32.5 6.8 11.6-7.2 14.8-22.6 7.1-33.9l-22.7-33.1C322.7 152.9 305.9 144 288 144s-34.7 8.9-44.8 23.7l-22.7 33.1c-7.7 11.3-4.5 26.7 7.1 33.9 10.9 6.8 25.3 3.8 32.5-6.8l22.7-33.1c1.2-1.7 3.1-2.8 5.2-2.8zm-84.7 74.6c-10.9-6.8-25.3-3.8-32.5 6.8l-17.2 25.2c-6.2 9.1-9.5 19.8-9.5 30.8 0 30.1 24.4 54.6 54.5 54.6l45.5 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-45.5 0c-3.6 0-6.5-2.9-6.5-6.6 0-1.3 .4-2.6 1.1-3.7l17.2-25.2c7.7-11.3 4.5-26.7-7.1-33.9zM308 360c0 13.3 10.7 24 24 24l45.4 0c30.1 0 54.6-24.4 54.6-54.6 0-11-3.3-21.7-9.5-30.8l-17.2-25.2c-7.3-10.6-21.6-13.6-32.5-6.8-11.6 7.2-14.8 22.6-7.1 33.9l17.2 25.2c.7 1.1 1.1 2.4 1.1 3.7 0 3.6-2.9 6.6-6.6 6.6L332 336c-13.3 0-24 10.7-24 24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinRecycle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;