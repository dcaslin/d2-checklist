'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'aeropress';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e82b';
var svgPathData = 'M272 128c26.5 0 48 21.5 48 48l0 224 40 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-40 0 0 16c0 26.5-21.5 48-48 48l-160 0c-26.5 0-48-21.5-48-48l0-16-40 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l40 0 0-224c0-26.5 21.5-48 48-48l160 0zM248 352a24 24 0 1 0 0 48 24 24 0 1 0 0-48zm0-80a24 24 0 1 0 0 48 24 24 0 1 0 0-48zm0-80a24 24 0 1 0 0 48 24 24 0 1 0 0-48zM312-16c13.3 0 24 10.7 24 24s-10.7 24-24 24l-24 0 0 48-192 0 0-48-24 0C58.7 32 48 21.3 48 8S58.7-16 72-16l240 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAeropress = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;