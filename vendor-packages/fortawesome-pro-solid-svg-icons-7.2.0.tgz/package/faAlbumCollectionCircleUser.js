'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'album-collection-circle-user';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e48f';
var svgPathData = 'M128 24c0 13.3 10.7 24 24 24l208 0c13.3 0 24-10.7 24-24S373.3 0 360 0L152 0c-13.3 0-24 10.7-24 24zM64 192c-13.9 0-27.1 6-36.3 16.6S14.5 233 16.5 246.8l32 224C51.9 494.4 72.1 512 96 512l180 0c-10.5-14.6-19-30.8-25.1-48.1-86-1.9-154.9-51.3-154.9-111.9 0-61.9 71.6-112 160-112 20.8 0 40.7 2.8 58.9 7.8 32.4-25 73-39.8 117.1-39.8 20.3 0 39.8 3.1 58.1 8.9-1.6-3-3.6-5.8-5.8-8.4-9.1-10.5-22.3-16.6-36.3-16.6L64 192zM241.2 378c2.2-19 7.1-37.1 14.4-54-21.9 .1-39.6 12.6-39.6 28 0 11.8 10.5 21.9 25.2 26zM104 96c-13.3 0-24 10.7-24 24s10.7 24 24 24l304 0c13.3 0 24-10.7 24-24s-10.7-24-24-24L104 96zM576 400a144 144 0 1 0 -288 0 144 144 0 1 0 288 0zm-66.3 80.7C489.5 500.1 462.2 512 432 512s-57.5-11.9-77.7-31.3c6.2-19 24-32.7 45.1-32.7l65.2 0c21 0 38.9 13.7 45.1 32.7zM384 368a48 48 0 1 1 96 0 48 48 0 1 1 -96 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlbumCollectionCircleUser = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;