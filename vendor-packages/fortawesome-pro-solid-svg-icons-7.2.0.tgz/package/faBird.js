'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bird';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e469';
var svgPathData = 'M0 192l0-3.6C0 172.7 12.7 160 28.4 160L224 160c17.7 0 32-14.3 32-32l0-32c0-53 43-96 96-96 47.5 0 86.9 34.5 94.6 79.7l57.6 34.6c4.8 2.9 7.8 8.1 7.8 13.7s-3 10.8-7.8 13.7L448 175.4 448 192c0 93.9-57.7 174.3-139.7 207.6l40.9 77.2 1 2.2c4.6 11.3 0 24.4-11 30.2s-24.4 2.2-31.2-7.9l-1.3-2.1-45.7-86.3c-12.1 2-24.5 3.1-37.1 3.1-1 0-2 0-3 0l32.2 60.8 1 2.2c4.6 11.3 0 24.4-11 30.2s-24.4 2.2-31.2-7.9l-1.3-2.1-48.6-91.9C68.5 380.5 0 294.3 0 192zm376-72a24 24 0 1 0 -48 0 24 24 0 1 0 48 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBird = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;