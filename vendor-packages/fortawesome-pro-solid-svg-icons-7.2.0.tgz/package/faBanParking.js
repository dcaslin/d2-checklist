'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'ban-parking';
var width = 512;
var height = 512;
var aliases = ["parking-circle-slash"];
var unicode = 'f616';
var svgPathData = 'M412.5 367.2L342.3 297c20.6-17.6 33.7-43.8 33.7-73 0-53-43-96-96-96l-72 0c-9.7 0-18.6 3.5-25.5 9.2L144.8 99.5c31.4-22.4 69.8-35.5 111.2-35.5 106 0 192 86 192 192 0 41.5-13.1 79.9-35.5 111.2zm-45.3 45.3c-31.4 22.4-69.8 35.5-111.2 35.5-106 0-192-86-192-192 0-41.5 13.1-79.9 35.5-111.2L168 213.3 168 352c0 17.7 14.3 32 32 32s32-14.3 32-32l0-32 42.7 0 92.5 92.5zM296.6 251.4L237.3 192 280 192c17.7 0 32 14.3 32 32 0 11.6-6.2 21.7-15.4 27.4zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanParking = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;