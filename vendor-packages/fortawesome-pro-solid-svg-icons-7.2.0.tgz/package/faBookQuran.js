'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'book-quran';
var width = 448;
var height = 512;
var aliases = ["quran"];
var unicode = 'f687';
var svgPathData = 'M64 512l288 0c53 0 96-43 96-96l0-320c0-53-43-96-96-96L48 0C21.5 0 0 21.5 0 48L0 336c0 20.9 13.4 38.7 32 45.3L32 448c-17.7 0-32 14.3-32 32s14.3 32 32 32l32 0zM352 384c17.7 0 32 14.3 32 32s-14.3 32-32 32l-256 0 0-64 256 0zM273.1 144.4c2.5-6.1 11.2-6.1 13.7 0l10.3 24.8 26.8 2.1c6.6 .5 9.2 8.7 4.2 13L307.8 201.9 314 228c1.5 6.4-5.5 11.5-11.1 8.1l-22.9-14-22.9 14c-5.6 3.4-12.6-1.6-11.1-8.1l6.2-26.1-20.4-17.5c-5-4.3-2.3-12.5 4.2-13l26.8-2.1 10.3-24.8zM100 192c0-68.5 55.5-124 124-124 23.8 0 46.1 6.7 65 18.4 4.8 2.9 6.9 8.8 5 14.1s-7.1 8.6-12.7 8c-3.1-.3-6.2-.5-9.4-.5-46.4 0-84 37.6-84 84s37.6 84 84 84c3.2 0 6.3-.2 9.4-.5 5.6-.6 10.8 2.7 12.7 8s-.3 11.2-5 14.1c-18.9 11.7-41.2 18.4-65 18.4-68.5 0-124-55.5-124-124z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookQuran = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;