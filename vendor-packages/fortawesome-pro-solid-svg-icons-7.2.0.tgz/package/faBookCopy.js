'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'book-copy';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0be';
var svgPathData = 'M320 384l224 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l0-66.7c18.6-6.6 32-24.4 32-45.3l0-160c0-26.5-21.5-48-48-48L320 0c-53 0-96 43-96 96l0 192c0 53 43 96 96 96zm-32-96c0-17.7 14.3-32 32-32l160 0 0 64-160 0c-17.7 0-32-14.3-32-32zM96 128c-53 0-96 43-96 96L0 416c0 53 43 96 96 96l224 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L96 448c-17.7 0-32-14.3-32-32s14.3-32 32-32l116.7 0c-22.8-25.5-36.7-59.1-36.7-96l0-160-80 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookCopy = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;