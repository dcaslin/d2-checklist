'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bolt-auto';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0b6';
var svgPathData = 'M339.6 22.7c11.8 9.1 15.7 25.2 9.4 38.7L274 224 384 224c13.5 0 25.6 8.5 30.2 21.3s.5 27-10 35.5l-256 208c-11.6 9.4-28.1 9.6-39.8 .4s-15.7-25.2-9.4-38.7L174 288 64 288c-13.5 0-25.6-8.5-30.2-21.3s-.5-27 10-35.5l256-208c11.6-9.4 28.1-9.6 39.8-.4zM464 288c9.1 0 17.4 5.1 21.5 13.3l88 176c5.9 11.9 1.1 26.3-10.7 32.2s-26.3 1.1-32.2-10.7l-13.4-26.7-106.3 0-13.4 26.7c-5.9 11.9-20.3 16.7-32.2 10.7s-16.7-20.3-10.7-32.2l88-176c4.1-8.1 12.4-13.3 21.5-13.3zM434.8 424l58.3 0-29.2-58.3-29.2 58.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoltAuto = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;