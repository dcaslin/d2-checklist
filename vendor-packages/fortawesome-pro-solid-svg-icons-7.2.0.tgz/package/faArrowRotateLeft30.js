'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrow-rotate-left-30';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e887';
var svgPathData = 'M256 0C397.4 0 512 114.6 512 256S397.4 512 256 512c-87 0-163.9-43.4-210.1-109.7-10.1-14.5-6.6-34.5 7.9-44.6s34.5-6.6 44.6 7.9c34.7 49.8 92.4 82.3 157.6 82.3 106 0 192-86 192-192S362 64 256 64c-69.8 0-130.9 37.2-164.6 93.1l-.1 .2-.1 .2-32 51.4c-7.5 12.1-22.2 17.8-36 13.9S0 206.3 0 192L0 32C0 14.3 14.3 0 32 0S64 14.3 64 32l0 54.7C110.9 33.6 179.5 0 256 0zM180 160c33.1 0 60 26.9 60 60 0 13.5-4.5 26-12.1 36 7.6 10 12.1 22.5 12.1 36 0 33.1-26.9 60-60 60l-28 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l28 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-20 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l20 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-28 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l28 0zm164 0c30.9 0 56 25.1 56 56l0 80c0 30.9-25.1 56-56 56l-16 0c-30.9 0-56-25.1-56-56l0-80c0-30.9 25.1-56 56-56l16 0zm-16 48c-4.4 0-8 3.6-8 8l0 80c0 4.4 3.6 8 8 8l16 0c4.4 0 8-3.6 8-8l0-80c0-4.4-3.6-8-8-8l-16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateLeft30 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;