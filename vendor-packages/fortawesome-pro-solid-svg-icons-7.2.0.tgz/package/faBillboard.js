'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'billboard';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e5cd';
var svgPathData = 'M168 64L96 64c-35.3 0-64 28.7-64 64l0 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l224 0 0 64c0 17.7 14.3 32 32 32s32-14.3 32-32l0-64 224 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l0-224c0-35.3-28.7-64-64-64l-72 0 0 80 16 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l16 0 0-80-144 0 0 80 16 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l16 0 0-80z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBillboard = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;