'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'blanket-fire';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e3da';
var svgPathData = 'M216 480c-63.6 0-115.6-49.5-119.7-112l-.3 0 0-248c0-48.6 39.4-88 88-88l272 0c48.6 0 88 39.4 88 88l0 52.2c-12 .3-23.8 3.9-34.1 11-7.9-7.9-15.9-15.6-24.2-23.1-23.8-21.4-60-21.5-83.9-.2-36.4 32.6-67.7 69.8-90.2 106.4-4.3 7-8.5 14.2-12.4 21.7L216 288c-39.8 0-72 32.2-72 72s32.2 72 72 72l62 0c4.1 16.8 10.2 32.9 18.1 48L216 480zm56-97.9l0 1.9-56 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l63.2 0c-4.5 15.3-7.2 30.8-7.2 46.1zM505.7 240.3L518 226.5c5.4-6.1 13.3-8.8 20.9-8.9 7.2 0 14.3 2.6 19.9 7.8 19.7 18.3 39.8 43.2 55 70.6 15.1 27.2 26.2 58.1 26.2 88.1 0 88.7-71.3 159.8-160 159.8-89.6 0-160-71.3-160-159.8 0-37.3 16-73.4 36.8-104.5 20.9-31.3 47.5-59 70.9-80.2 5.7-5.2 13.1-7.7 20.3-7.5s13.4 3.2 18.8 7.5c14.4 11.4 38.9 40.7 38.9 40.7zM544 432.2c0-36.5-37-73-54.8-88.4-5.4-4.7-13.1-4.7-18.5 0-17.7 15.4-54.8 51.9-54.8 88.4 0 35.3 28.7 64 64 64s64-28.7 64-64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlanketFire = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;