'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'axe-battle';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f6b3';
var svgPathData = 'M288 32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 480c0 17.7 14.3 32 32 32s32-14.3 32-32l0-480zM176 106.6C142.2 87.1 116.3 55.6 103.9 17.9 100.1 6.2 85.6 .6 76.8 9.2 29.4 55.7 0 120.4 0 192S29.4 328.3 76.8 374.8c8.8 8.6 23.3 3 27.2-8.7 12.4-37.7 38.3-69.2 72.1-88.7l0-170.8zM336 277.4c33.8 19.5 59.7 51 72.1 88.7 3.8 11.7 18.3 17.3 27.2 8.7 38.3-37.5 64.8-86.9 73.6-142.3L448 192 508.8 151.5c-8.8-55.3-35.3-104.8-73.6-142.3-8.8-8.6-23.3-3-27.2 8.7-12.3 37.7-38.3 69.2-72.1 88.7l0 170.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAxeBattle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;