'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'amp-guitar';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f8a1';
var svgPathData = 'M144 88l0 8 224 0 0-8c0-22.1-17.9-40-40-40L184 48c-22.1 0-40 17.9-40 40zM96 96l0-8c0-48.6 39.4-88 88-88L328 0c48.6 0 88 39.4 88 88l0 8 32 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 160c0-35.3 28.7-64 64-64l32 0zm24 96a24 24 0 1 0 -48 0 24 24 0 1 0 48 0zm72 24a24 24 0 1 0 0-48 24 24 0 1 0 0 48zm152-24a24 24 0 1 0 -48 0 24 24 0 1 0 48 0zm72 24a24 24 0 1 0 0-48 24 24 0 1 0 0 48zM112 304l288 0 0 64-288 0 0-64zM96 256c-17.7 0-32 14.3-32 32l0 96c0 17.7 14.3 32 32 32l320 0c17.7 0 32-14.3 32-32l0-96c0-17.7-14.3-32-32-32L96 256z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAmpGuitar = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;