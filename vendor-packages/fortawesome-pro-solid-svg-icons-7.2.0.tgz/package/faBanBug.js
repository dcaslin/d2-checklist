'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'ban-bug';
var width = 512;
var height = 512;
var aliases = ["debug"];
var unicode = 'f7f9';
var svgPathData = 'M256 448c-106 0-192-86-192-192 0-41.5 13.1-79.9 35.5-111.2L367.2 412.5C335.9 434.9 297.5 448 256 448zm98.4-138.8l18.2 2.6c13.1 1.9 25.3-7.2 27.2-20.4s-7.2-25.3-20.4-27.2l-43.4-6.2 0-4.1 43.4-6.2c13.1-1.9 22.2-14 20.4-27.2s-14-22.2-27.2-20.4L336 205.5c-.1-3.4-.4-6.8-1-10.1l27.7-13.9c11.9-5.9 16.7-20.3 10.7-32.2s-20.3-16.7-32.2-10.7l-27.7 13.9c-14.5-15-34.9-24.4-57.5-24.4-22.8 0-43.4 9.5-57.9 24.8L144.8 99.5c31.4-22.4 69.8-35.5 111.2-35.5 106 0 192 86 192 192 0 41.5-13.1 79.9-35.5 111.2l-58.1-58.1zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM148.8 261.9l-16.2 2.3c-13.1 1.9-22.2 14-20.4 27.2s14 22.2 27.2 20.4l36.6-5.2c.1 3.4 .4 6.8 1 10.1l-27.7 13.9c-11.9 5.9-16.7 20.3-10.7 32.2s20.3 16.7 32.2 10.7l27.7-13.9c14.5 15 34.9 24.4 57.5 24.4 4.7 0 9.2-.4 13.7-1.2L148.8 261.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanBug = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;