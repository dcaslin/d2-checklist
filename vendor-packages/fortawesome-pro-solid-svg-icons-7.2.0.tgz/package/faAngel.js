'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'angel';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f779';
var svgPathData = 'M391.7 85.5c-3.8-9.2-8.7-17.8-14.7-25.5 4.5-3.7 7-7.8 7-12 0-17.7-43-32-96-32s-96 14.3-96 32c0 4.2 2.5 8.3 7 12-5.9 7.8-10.9 16.3-14.7 25.5-15.3-10.5-24.3-23.5-24.3-37.5 0-35.3 57.3-64 128-64S416 12.7 416 48c0 14-9 27-24.3 37.5zM288 64a64 64 0 1 1 0 128 64 64 0 1 1 0-128zM81.5 406.9c3.7-22.3-2.8-48-19.3-63.6-28.5-27-46.3-65.3-46.3-107.6l0-63.4c0-42.1 34.1-76.3 76.3-76.3 22.6 0 44.1 10.1 58.6 27.4L215.5 201c-21 16.4-36.4 39.8-42.5 67.3L129.8 462.6c-3.9 17.4-1.8 34.5 4.7 49.4l-20.3 0c-26.3 0-46.4-23.6-42-49.6l9.3-55.5zm364.7 55.8L403 268.3c-6.1-27.5-21.5-50.9-42.5-67.3l64.6-77.5c14.5-17.4 36-27.4 58.6-27.4 42.1 0 76.3 34.1 76.3 76.3l0 63.4c0 42.4-17.8 80.6-46.3 107.6-16.4 15.6-23 41.2-19.3 63.6l9.3 55.5c4.3 26-15.7 49.6-42 49.6l-20.2 0c6.5-14.9 8.6-32 4.7-49.4zm-226.4-184c7.1-31.9 35.4-54.7 68.1-54.7s61 22.7 68.1 54.7l43.2 194.4c4.4 20-10.8 38.9-31.2 38.9l-160.2 0c-20.5 0-35.7-19-31.2-38.9l43.2-194.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAngel = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;