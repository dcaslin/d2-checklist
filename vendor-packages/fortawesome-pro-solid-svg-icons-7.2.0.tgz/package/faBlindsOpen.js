'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'blinds-open';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f8fc';
var svgPathData = 'M32 32C14.3 32 0 46.3 0 64S14.3 96 32 96l80 0 0 232c0 13.3 10.7 24 24 24s24-10.7 24-24l0-232 256 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 32zM416 224c17.7 0 32-14.3 32-32s-14.3-32-32-32l-208 0 0 64 208 0zM32 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l32 0 0-64-32 0zm0 192l32 0 0-64-32 0c-17.7 0-32 14.3-32 32s14.3 32 32 32zm384-64l-208 0 0 64 208 0c17.7 0 32-14.3 32-32s-14.3-32-32-32zM32 480l384 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 416c-17.7 0-32 14.3-32 32s14.3 32 32 32z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlindsOpen = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;