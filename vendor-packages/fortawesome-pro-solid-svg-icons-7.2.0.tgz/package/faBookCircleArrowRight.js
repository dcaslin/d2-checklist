'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'book-circle-arrow-right';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0bc';
var svgPathData = 'M432 208c16.6 0 32.7 2.1 48 6l0-166c0-26.5-21.5-48-48-48L128 0C75 0 32 43 32 96l0 320c0 53 43 96 96 96l148 0c-13.7-19-24-40.7-30-64l-118 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l112.7 0c8.1-98.6 90.7-176 191.3-176zM576 400a144 144 0 1 0 -288 0 144 144 0 1 0 288 0zM428.7 332.7c6.2-6.2 16.4-6.2 22.6 0l56 56c6.2 6.2 6.2 16.4 0 22.6l-56 56c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l28.7-28.7-89.4 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l89.4 0-28.7-28.7c-6.2-6.2-6.2-16.4 0-22.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookCircleArrowRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;