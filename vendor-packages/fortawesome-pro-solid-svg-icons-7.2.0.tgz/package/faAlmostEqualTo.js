'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'almost-equal-to';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e818';
var svgPathData = 'M108.4 288c10.9 0 21.7 1.6 32.2 4.8l185.8 57.2 3.3 .9c3.3 .8 6.7 1.1 10.1 1.1 20.8 0 38.9-14.1 44-34.3l1.4-5.4 .9-3.2c5.5-15.2 21.8-24.1 37.8-20.1 16.1 4 26.3 19.5 23.9 35.6l-.7 3.2-1.3 5.4c-12.2 48.7-55.9 82.8-106.1 82.8-8.2 0-16.3-.9-24.2-2.7l-7.9-2.1-185.8-57.2c-4.3-1.3-8.8-2-13.3-2-20.8 0-38.9 14.2-44 34.3l-1.4 5.4C58.8 408.9 41.4 419.3 24.3 415 7.1 410.7-3.3 393.4 1 376.2l1.3-5.4C14.5 322.1 58.2 288 108.4 288zm0-192c10.9 0 21.7 1.6 32.2 4.8l185.8 57.2 3.3 .9c3.3 .7 6.7 1.1 10.1 1.1 20.8 0 38.9-14.1 44-34.3l1.4-5.4 .9-3.2c5.5-15.2 21.8-24.1 37.8-20.1 16.1 4 26.3 19.5 23.9 35.6l-.7 3.2-1.3 5.4c-12.2 48.7-55.9 82.8-106.1 82.8-8.2 0-16.3-.9-24.2-2.7l-7.9-2.1-185.8-57.2c-4.3-1.3-8.8-2-13.3-2-20.8 0-38.9 14.2-44 34.3l-1.4 5.4C58.8 216.9 41.4 227.3 24.3 223 7.1 218.7-3.3 201.4 1 184.2l1.3-5.4C14.5 130.1 58.2 96 108.4 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlmostEqualTo = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;