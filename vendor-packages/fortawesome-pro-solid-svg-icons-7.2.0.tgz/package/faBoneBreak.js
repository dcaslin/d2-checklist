'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bone-break';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f5d8';
var svgPathData = 'M344-8l0 80c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-80c0-13.3 10.7-24 24-24s24 10.7 24 24zM201 39l48 48c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0L167 73c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0zM473 73l-48 48c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l48-48c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9zM189.3 201.4c.9 3.8 4.2 6.6 8.1 6.6l52 0c3.1 0 6 1.8 7.3 4.7L305.4 320c5.7 12.5 23.4 12.5 29.1 0l48.8-107.3c1.3-2.9 4.1-4.7 7.3-4.7l52 0c3.9 0 7.2-2.8 8.1-6.6 10.2-42.1 48.1-73.4 93.3-73.4 53 0 96 43 96 96 0 29.1-12.9 55.1-33.3 72.7-4.3 3.7-4.3 10.8 0 14.5 20.4 17.6 33.3 43.7 33.3 72.7 0 53-43 96-96 96-45.2 0-83.1-31.3-93.3-73.4-.9-3.8-4.2-6.6-8.1-6.6l-245.1 0c-3.9 0-7.2 2.8-8.1 6.6-10.2 42.1-48.1 73.4-93.3 73.4-53 0-96-43-96-96 0-29.1 12.9-55.1 33.3-72.7 4.3-3.7 4.3-10.8 0-14.5-20.4-17.6-33.3-43.7-33.3-72.7 0-53 43-96 96-96 45.2 0 83.1 31.3 93.3 73.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoneBreak = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;