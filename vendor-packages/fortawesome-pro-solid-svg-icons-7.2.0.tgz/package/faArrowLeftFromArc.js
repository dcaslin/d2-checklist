'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'arrow-left-from-arc';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e615';
var svgPathData = 'M448 256c0-106-86-192-192-192-17.7 0-32-14.3-32-32S238.3 0 256 0C397.4 0 512 114.6 512 256S397.4 512 256 512c-17.7 0-32-14.3-32-32s14.3-32 32-32c106 0 192-86 192-192zM121.4 121.4c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3L109.3 224 320 224c17.7 0 32 14.3 32 32s-14.3 32-32 32l-210.7 0 57.4 57.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0l-112-112c-12.5-12.5-12.5-32.8 0-45.3l112-112z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowLeftFromArc = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;