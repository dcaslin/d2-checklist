'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bee';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e0b2';
var svgPathData = 'M334 448c-25.8 28-52 49.8-63.7 59.1-4.1 3.2-9.1 4.9-14.3 4.9s-10.2-1.6-14.3-4.9C230 497.8 203.8 476 178 448l156 0zM256 319.9c26.9 35.8 63.5 63.7 105.9 80.1l-211.8 0c42.4-16.3 79.1-44.3 105.9-80.1zM311 7c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9L326.9 59c5.8 11.1 9.1 23.6 9.1 37l0 34.7c90.8 15.2 160 94.2 160 189.3l0 16c0 17.7-14.3 32-32 32l-16 0c-102.7 0-186.6-80.7-191.8-182.1L256 176c0 106-86 192-192 192l-16 0c-17.7 0-32-14.3-32-32l0-16c0-95.1 69.2-174.1 160-189.3L176 96c0-13.3 3.3-25.9 9.1-37L167 41 165.4 39.1c-7.7-9.4-7.1-23.3 1.7-32.1s22.7-9.3 32.1-1.7L201 7 219 25.1c11.1-5.8 23.6-9.1 37-9.1 13.3 0 25.9 3.3 36.9 9.1L311 7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBee = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;