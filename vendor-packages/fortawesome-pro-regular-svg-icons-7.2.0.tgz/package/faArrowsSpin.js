'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrows-spin';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e4bb';
var svgPathData = 'M280.2 488c0-13.3-10.7-24-24-24-52.8 0-105.6-20-146.1-60L145.2 369c6.9-6.9 8.9-17.2 5.2-26.2S138 328 128.3 328L24.2 328c-13.3 0-24 10.7-24 24l0 104c0 9.7 5.8 18.5 14.8 22.2s19.3 1.7 26.2-5.2l35-35c49.8 49.4 115 74 180 74 13.3 0 24-10.7 24-24zM256.2 0c-13.3 0-24 10.7-24 24s10.7 24 24 24c52.8 0 105.6 20 146.1 60L367.2 143c-6.9 6.9-8.9 17.2-5.2 26.2S374.5 184 384.2 184l104.1 0c13.3 0 24-10.7 24-24l0-104c0-9.7-5.8-18.5-14.8-22.2s-19.3-1.7-26.2 5.2l-35 35c-49.8-49.4-115-74-180-74zM24.2 280c13.3 0 24-10.7 24-24 0-52.8 20-105.6 60-146.1L143.2 145c6.9 6.9 17.2 8.9 26.2 5.2s14.8-12.5 14.8-22.2l0-104.1c0-13.3-10.7-24-24-24L56.2 0C46.5 0 37.8 5.8 34 14.8S32.4 34.1 39.2 41l35 35c-49.4 49.8-74 115-74 180 0 13.3 10.7 24 24 24zm488-24c0-13.3-10.7-24-24-24s-24 10.7-24 24c0 52.8-20 105.6-60 146.1L369.2 367c-6.9-6.9-17.2-8.9-26.2-5.2s-14.8 12.5-14.8 22.2l0 104.1c0 13.3 10.7 24 24 24l104 0c9.7 0 18.5-5.8 22.2-14.8s1.7-19.3-5.2-26.2l-35-35c49.4-49.8 74-115 74-180z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsSpin = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;