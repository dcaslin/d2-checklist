'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-up-triangle-square';
var width = 512;
var height = 512;
var aliases = ["sort-shapes-up"];
var unicode = 'f88a';
var svgPathData = 'M384 32c-9.9 0-19.1 5.2-24.2 13.7L275.6 186c-2.3 3.9-3.6 8.4-3.6 12.9 0 13.8 11.2 25.1 25.1 25.1l173.9 0c13.8 0 25.1-11.2 25.1-25.1 0-4.5-1.2-9-3.6-12.9L408.2 45.7C403.1 37.2 393.9 32 384 32zM336 432l0-96 96 0 0 96-96 0zM384 98.6l46.4 77.4-92.8 0 46.4-77.4zM288 432c0 26.5 21.5 48 48 48l96 0c26.5 0 48-21.5 48-48l0-96c0-26.5-21.5-48-48-48l-96 0c-26.5 0-48 21.5-48 48l0 96zM145 39c-9.4-9.4-24.6-9.4-33.9 0L23 127c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l47-47 0 342.1c0 13.3 10.7 24 24 24s24-10.7 24-24l0-342.1 47 47c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L145 39z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpTriangleSquare = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;