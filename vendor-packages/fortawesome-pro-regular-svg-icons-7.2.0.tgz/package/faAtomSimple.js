'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'atom-simple';
var width = 448;
var height = 512;
var aliases = ["atom-alt"];
var unicode = 'f5d3';
var svgPathData = 'M58.1 422.4c7.9 7.9 31.4 16.9 80.4 .6 13.2-4.4 27.2-10.4 41.6-17.9-18.9-14.4-37.7-30.8-55.8-48.9s-34.5-36.9-48.9-55.8c-7.5 14.4-13.5 28.4-17.9 41.6-16.3 49-7.3 72.5 .6 80.4zM45.3 256C-3.9 173.9-15 94.9 24.2 55.7S142.4 27.6 224.5 76.8c82.1-49.2 161.1-60.3 200.3-21.1S452.9 173.9 403.7 256c49.2 82.1 60.3 161.1 21.1 200.3s-118.2 28.1-200.3-21.1c-82.1 49.2-161.1 60.3-200.3 21.1S-3.9 338.1 45.3 256zm30.2-44.4c14.4-18.9 30.8-37.7 48.9-55.8s36.9-34.5 55.8-48.9c-14.4-7.5-28.4-13.5-41.6-17.9-49-16.3-72.5-7.3-80.4 .6S41.3 121 57.6 170C62 183.2 68 197.2 75.5 211.6zm149-77.7c-22.1 15.5-44.5 34.1-66.2 55.8s-40.3 44.1-55.8 66.2c15.5 22.1 34.1 44.5 55.8 66.2s44.1 40.3 66.2 55.8c22.1-15.5 44.5-34.1 66.2-55.8s40.3-44.1 55.8-66.2c-15.5-22.1-34.1-44.5-55.8-66.2s-44.1-40.3-66.2-55.8zm149 77.7c7.5-14.4 13.5-28.4 17.9-41.6 16.3-49 7.3-72.5-.6-80.4s-31.4-16.9-80.4-.6c-13.2 4.4-27.2 10.4-41.6 17.9 18.9 14.4 37.7 30.8 55.8 48.9s34.5 36.9 48.9 55.8zm0 88.7c-14.4 18.9-30.8 37.7-48.9 55.8s-36.9 34.5-55.8 48.9c14.4 7.5 28.4 13.5 41.6 17.9 49 16.3 72.5 7.3 80.4-.6s16.9-31.4 .6-80.4c-4.4-13.2-10.4-27.2-17.9-41.6zM191.5 256a32.5 32.5 0 1 1 65 0 32.5 32.5 0 1 1 -65 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAtomSimple = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;