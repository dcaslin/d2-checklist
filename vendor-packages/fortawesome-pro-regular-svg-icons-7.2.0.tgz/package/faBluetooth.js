'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bluetooth';
var width = 320;
var height = 512;
var aliases = [];
var unicode = 'f293';
var svgPathData = 'M150.1 2.1c8.6-3.9 18.7-2.4 25.7 3.9l136 120c5.3 4.7 8.2 11.4 8.1 18.4s-3.3 13.6-8.7 18.1L197.8 256 311.3 349.5c5.4 4.5 8.6 11.1 8.7 18.1s-2.8 13.8-8.1 18.4l-136 120c-7.1 6.2-17.1 7.8-25.7 3.9S136 497.4 136 488l0-181.1-96.7 79.7c-10.2 8.4-25.4 7-33.8-3.3s-7-25.4 3.3-33.8L122.2 256 8.7 162.5C-1.5 154.1-3 139 5.5 128.7S29 117 39.3 125.5L136 205.1 136 24c0-9.4 5.5-18 14.1-21.9zM184 306.9l0 128 75-66.2-75-61.8zm0-101.7l75-61.8-75-66.2 0 128z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBluetooth = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;