'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bolt-lightning';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e0b7';
var svgPathData = 'M77.2 48l-25.6 192 156.6 0c7.4 0 14.4 3.4 18.9 9.2s6.2 13.4 4.4 20.6l-23 91.8 114.5-169.7-146.8 0c-7.9 0-15.3-3.9-19.8-10.4s-5.4-14.9-2.6-22.2L197.1 48 77.2 48zM30.6 34.7C33.2 14.8 50.2 0 70.2 0L208.8 0c28.1 0 47.5 28.3 37.3 54.5l-34.8 89.5 126.8 0c32.1 0 51.1 35.8 33.2 62.4l-199.2 295c-6.5 9.7-19 13.2-29.7 8.5s-16.3-16.4-13.5-27.7l48.5-194.2-135 0C18.3 288-.3 266.7 2.9 242.7l27.7-208z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoltLightning = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;