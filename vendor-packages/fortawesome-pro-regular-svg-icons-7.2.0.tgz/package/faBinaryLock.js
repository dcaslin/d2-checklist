'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'binary-lock';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e33d';
var svgPathData = 'M392 24l0 152 32 0c4.3 0 8.3 1.1 11.8 3.1-28.8 6.5-53.9 22.6-71.8 44.9L312 224c-13.3 0-24-10.7-24-24s10.7-24 24-24l32 0 0-118.7-16.4 5.5C315 67 301.4 60.2 297.2 47.6s2.6-26.2 15.2-30.4l48-16C367.7-1.2 375.8 0 382 4.5S392 16.3 392 24zM320 288l17 0c-.7 5.2-1 10.6-1 16l0 24.4c-2.7 2.4-5.2 5-7.6 7.6l-8.4 0c-8.8 0-16 7.2-16 16l0 143.9c0 4.9 .4 9.7 1.1 14.3-28.1-6.7-49.1-32-49.1-62.2l0-96c0-35.3 28.7-64 64-64zM168 312l0 152 32 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L88 512c-13.3 0-24-10.7-24-24s10.7-24 24-24l32 0 0-118.7-16.4 5.5C91 355 77.4 348.2 73.2 335.6s2.6-26.2 15.2-30.4l48-16c7.3-2.4 15.4-1.2 21.6 3.3s10 11.8 10 19.5zM64 64C64 28.7 92.7 0 128 0l64 0c35.3 0 64 28.7 64 64l0 96c0 35.3-28.7 64-64 64l-64 0c-35.3 0-64-28.7-64-64l0-96zm64-16c-8.8 0-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16l64 0c8.8 0 16-7.2 16-16l0-96c0-8.8-7.2-16-16-16l-64 0zM496 304.1c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 47.9 64 0 0-47.9zM352 400c0-20.9 13.4-38.7 32-45.3l0-50.6c0-44.2 35.8-80 80-80s80 35.8 80 80l0 50.6c18.6 6.6 32 24.4 32 45.3l0 96c0 26.5-21.5 48-48 48l-128 0c-26.5 0-48-21.5-48-48l0-96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinaryLock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;