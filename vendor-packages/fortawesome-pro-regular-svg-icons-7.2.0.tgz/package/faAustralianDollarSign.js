'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'australian-dollar-sign';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e6fe';
var svgPathData = 'M408 16c13.3 0 24 10.7 24 24l0 24 16 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-53.1 0c-32.5 0-58.9 26.3-58.9 58.9 0 28.4 20.3 52.8 48.3 57.9l39.9 7.3c50.8 9.2 87.7 53.5 87.7 105.1 0 49.7-34 91.5-80 103.4l0 27.4c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-24-48 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l69.1 0c32.5 0 58.9-26.3 58.9-58.9 0-28.4-20.3-52.8-48.3-57.9L375.7 276c-50.8-9.2-87.7-53.5-87.7-105.1 0-55.3 42.1-100.9 96-106.3L384 40c0-13.3 10.7-24 24-24zM144 134.3L93.7 320 194.3 320 144 134.3zm88.8 328l-25.5-94.3-126.6 0-25.5 94.3c-3.5 12.8-16.6 20.4-29.4 16.9S5.4 462.5 8.8 449.7L110.7 73.4C114.8 58.4 128.4 48 144 48s29.2 10.4 33.3 25.4L279.2 449.7c3.5 12.8-4.1 26-16.9 29.4s-26-4.1-29.4-16.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAustralianDollarSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;