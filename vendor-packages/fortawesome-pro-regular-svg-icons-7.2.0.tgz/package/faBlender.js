'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'blender';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f517';
var svgPathData = 'M0 56C0 25.1 25.1 0 56 0l72 0 0 .1c1-.1 1.9-.1 2.9-.1L438.6 0c21 0 36.3 19.8 31 40.1L394.5 327.9c13 8.6 21.5 23.3 21.5 40.1l0 96c0 26.5-21.5 48-48 48l-224 0c-26.5 0-48-21.5-48-48l0-96c0-19.4 11.6-36.2 28.2-43.7L116.9 240 56 240c-30.9 0-56-25.1-56-56L0 56zm56-8c-4.4 0-8 3.6-8 8l0 128c0 4.4 3.6 8 8 8l56.7 0-12.5-144-44.2 0zm88 320l0 96 224 0 0-96-224 0zM363.6 256L312 256c-13.3 0-24-10.7-24-24s10.7-24 24-24l64.1 0 16.7-64-80.8 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l93.4 0 12.5-48-269.5 0 23.7 272 174.9 0 16.7-64zM256 392a24 24 0 1 1 0 48 24 24 0 1 1 0-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlender = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;