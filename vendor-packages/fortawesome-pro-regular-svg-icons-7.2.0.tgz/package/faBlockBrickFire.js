'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'block-brick-fire';
var width = 640;
var height = 512;
var aliases = ["firewall"];
var unicode = 'e3dc';
var svgPathData = 'M400 80l0 48-160 0 0-48 160 0zm48 48l0-48 32 0c8.8 0 16 7.2 16 16l0 32-48 0zM320 176l64.6 0c5.6-5.5 11.3-10.8 17.2-16.1 23.9-21.3 60.1-21.2 83.9 .2 8.3 7.5 16.3 15.1 24.2 23.1 10.3-7.1 22.2-10.7 34.1-11L544 96c0-35.3-28.7-64-64-64L160 32c-35.3 0-64 28.7-64 64l0 320c0 35.3 28.7 64 64 64l136.1 0c-7.9-15.1-14-31.2-18.1-48l-118 0c-8.8 0-16-7.2-16-16l0-32 128 0 0-1.9c0-15.3 2.7-30.8 7.2-46.1l-39.2 0 0-56 63.5 0c2.6-4.7 5.3-9.2 8.1-13.7 7-11.4 14.9-22.9 23.6-34.3l-15.1 0 0-56zm-48 0l0 56-128 0 0-56 128 0zM144 336l0-56 48 0 0 56-48 0zm0-208l0-32c0-8.8 7.2-16 16-16l32 0 0 48-48 0zM505.7 240.3s-24.5-29.4-38.9-40.7c-5.4-4.3-11.5-7.3-18.8-7.5s-14.6 2.3-20.3 7.5c-23.4 21.1-50 48.9-70.9 80.2-20.8 31.1-36.8 67.1-36.8 104.5 0 88.6 70.4 159.8 160 159.8 88.7 0 160-71.2 160-159.8 0-30-11-60.9-26.2-88.1-15.2-27.4-35.3-52.3-55-70.6-5.6-5.2-12.8-7.8-19.9-7.8-7.6 0-15.5 2.8-20.9 8.9l-12.3 13.8zM544 432.2c0 35.3-28.7 64-64 64s-64-28.7-64-64c0-36.5 37-73 54.8-88.4 5.4-4.7 13.1-4.7 18.5 0 17.7 15.4 54.8 51.9 54.8 88.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlockBrickFire = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;