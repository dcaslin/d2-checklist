'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrows-to-circle';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e4bd';
var svgPathData = 'M7.5 7c9.4-9.4 24.6-9.4 33.9 0l103 103 0-38.1c0-13.3 10.7-24 24-24s24 10.7 24 24l0 96c0 13.3-10.7 24-24 24l-96 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l38.1 0-103-103C-1.8 31.6-1.8 16.4 7.5 7zm192 249a56.5 56.5 0 1 1 113 0 56.5 56.5 0 1 1 -113 0zm306-215l-103 103 38.1 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-96 0c-13.3 0-24-10.7-24-24l0-96c0-13.3 10.7-24 24-24s24 10.7 24 24l0 38.1 103-103c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9zm0 464c-9.4 9.4-24.6 9.4-33.9 0l-103-103 0 38.1c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-96c0-13.3 10.7-24 24-24l96 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-38.1 0 103 103c9.4 9.4 9.4 24.6 0 33.9zM7.5 471l103-103-38.1 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l96 0c13.3 0 24 10.7 24 24l0 96c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-38.1-103 103c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsToCircle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;