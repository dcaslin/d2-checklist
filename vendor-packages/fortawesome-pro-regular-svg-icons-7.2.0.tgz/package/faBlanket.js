'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'blanket';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f498';
var svgPathData = 'M48 120c0-22.1 17.9-40 40-40l272 0c22.1 0 40 17.9 40 40l0 124.1c-7.5-2.7-15.6-4.1-24-4.1l-256 0c-27 0-51.9 8.9-72 24l0-144zM.3 368C4.4 430.5 56.4 480 120 480l304 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-304 0c-39.8 0-72-32.2-72-72s32.2-72 72-72l256 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-256 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l256 0c39.8 0 72-32.2 72-72l0-192c0-48.6-39.4-88-88-88L88 32C39.4 32 0 71.4 0 120l0 248 .3 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlanket = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;