'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'billboard';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e5cd';
var svgPathData = 'M384 32c13.3 0 24 10.7 24 24l0 8 72 0c35.3 0 64 28.7 64 64l0 240 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-240 0 0 72c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-72-240 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l8 0 0-240c0-35.3 28.7-64 64-64l72 0 0-8c0-13.3 10.7-24 24-24s24 10.7 24 24l0 8 144 0 0-8c0-13.3 10.7-24 24-24zm112 96c0-8.8-7.2-16-16-16l-72 0 0 32 16 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l16 0 0-32-144 0 0 32 16 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l16 0 0-32-72 0c-8.8 0-16 7.2-16 16l0 240 416 0 0-240z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBillboard = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;