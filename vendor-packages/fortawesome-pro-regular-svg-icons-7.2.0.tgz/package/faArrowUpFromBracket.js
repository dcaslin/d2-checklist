'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-up-from-bracket';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e09a';
var svgPathData = 'M241 7c-9.4-9.4-24.6-9.4-33.9 0L71 143c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l95-95 0 246.1c0 13.3 10.7 24 24 24s24-10.7 24-24l0-246.1 95 95c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L241 7zM48 344c0-13.3-10.7-24-24-24S0 330.7 0 344l0 72c0 53 43 96 96 96l256 0c53 0 96-43 96-96l0-72c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 72c0 26.5-21.5 48-48 48L96 464c-26.5 0-48-21.5-48-48l0-72z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpFromBracket = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;