'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'baseball';
var width = 512;
var height = 512;
var aliases = [129358,9918,"baseball-ball"];
var unicode = 'f433';
var svgPathData = 'M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM273 62.3l-.7 2.4c-3.9 11.5-15.9 18.5-28.1 15.7-12.9-2.9-21-15.8-18.1-28.8l.3-1.6c-91.3 13-163.4 85.1-176.4 176.4 .5-.1 1-.2 1.6-.3l2.4-.4c12.1-1.5 23.6 6.4 26.3 18.5 2.9 12.9-5.2 25.8-18.1 28.7l-13.4 2.7c9.3 99.1 88.2 178 187.3 187.3 .8-4.5 1.7-8.9 2.7-13.3l.7-2.4c3.9-11.5 15.9-18.5 28.1-15.7 12.9 2.9 21 15.8 18.1 28.7l-.3 1.5c91.3-13 163.5-85.1 176.4-176.4-.5 .1-1 .2-1.5 .3l-2.4 .4c-12.1 1.5-23.6-6.4-26.3-18.5-2.9-12.9 5.2-25.8 18.1-28.7l13.3-2.7c-9.3-99.2-88.2-178-187.4-187.3-.8 4.5-1.6 9-2.6 13.4zm90 212.6c11.2-7.1 26-3.7 33.1 7.5s3.7 26.1-7.5 33.1c-29.5 18.6-54.5 43.6-73 73-7.1 11.2-21.9 14.6-33.1 7.5s-14.6-21.9-7.5-33.1c22.4-35.6 52.5-65.7 88.1-88.1zM196.5 123.4c7.1-11.2 21.9-14.6 33.1-7.5s14.6 21.9 7.5 33.1c-22.4 35.6-52.5 65.7-88.1 88.1-11.2 7.1-26 3.7-33.1-7.5s-3.7-26.1 7.5-33.1c29.5-18.6 54.5-43.6 73-73z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBaseball = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;