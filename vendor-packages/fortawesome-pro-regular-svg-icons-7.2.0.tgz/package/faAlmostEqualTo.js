'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'almost-equal-to';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e818';
var svgPathData = 'M106 304c11 0 22.3 1.4 33.4 4.9l183.3 56.4 4.6 1.2c4.7 1 9.6 1.5 14.8 1.5 27.8 0 52-18.9 58.7-45.8 3.2-12.9 16.2-20.7 29.1-17.5s20.7 16.2 17.5 29.1c-12.1 48.3-55.5 82.2-105.2 82.2-8.3 0-16.7-.8-25.1-2.7l-8.4-2.2-183.3-56.4c-6-1.8-12.4-2.7-19.3-2.7-27.8 0-52 18.9-58.7 45.8-3.2 12.9-16.2 20.7-29.1 17.5S-2.5 399 .7 386.2C12.8 337.9 56.2 304 106 304zm0-208c11 0 22.3 1.4 33.4 4.9l183.3 56.4 4.6 1.2c4.7 1 9.6 1.5 14.8 1.5 27.8 0 52-18.9 58.7-45.8 3.2-12.9 16.2-20.7 29.1-17.5s20.7 16.2 17.5 29.1c-12.1 48.3-55.5 82.2-105.2 82.2-8.3 0-16.7-.8-25.1-2.7l-8.4-2.2-183.3-56.4c-6-1.8-12.4-2.7-19.3-2.8-27.8 0-52 18.9-58.7 45.8-3.2 12.9-16.2 20.7-29.1 17.5S-2.5 191 .7 178.2C12.8 129.9 56.2 96 106 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlmostEqualTo = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;