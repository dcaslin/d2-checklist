'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'block-brick';
var width = 448;
var height = 512;
var aliases = ["wall-brick"];
var unicode = 'e3db';
var svgPathData = 'M144 80l0 48 160 0 0-48-160 0zM96 128l0-48-32 0c-8.8 0-16 7.2-16 16l0 32 48 0zM48 176l0 56 152 0 0-56-152 0zm0 160l48 0 0-56-48 0 0 56zm0 48l0 32c0 8.8 7.2 16 16 16l136 0 0-48-152 0zm96-48l160 0 0-56-160 0 0 56zm208 0l48 0 0-56-48 0 0 56zm48 48l-152 0 0 48 136 0c8.8 0 16-7.2 16-16l0-32zm0-208l-152 0 0 56 152 0 0-56zm0-48l0-32c0-8.8-7.2-16-16-16l-32 0 0 48 48 0zM0 96C0 60.7 28.7 32 64 32l320 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBlockBrick = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;