'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'ampersand';
var width = 384;
var height = 512;
var aliases = [];
var unicode = '26';
var svgPathData = 'M96 110.3c0 15.7 5.9 30.7 16.5 42.2l34.6 37.5 45.6-26.1c19.3-11 31.3-31.6 31.3-53.9 0-34.3-27.8-62.1-62.1-62.1l-3.7 0C123.9 48 96 75.9 96 110.3zm120.5 95.3l-36 20.6 104.5 113.2 58.8-53.2c9.8-8.9 25-8.1 33.9 1.7s8.1 25-1.7 33.9l-58.5 52.9 60 65c9 9.7 8.4 24.9-1.4 33.9s-24.9 8.4-33.9-1.4l-60.3-65.4-26.5 23.9C220.6 462.5 175.1 480 128 480 57.3 480 0 422.7 0 352l0-2.3c0-46.8 25.1-89.9 65.7-113.1l38.7-22.1-27.1-29.4C58.4 164.7 48 138 48 110.3 48 49.4 97.4 0 158.3 0l3.7 0c60.8 0 110.1 49.3 110.1 110.1 0 39.5-21.2 76-55.5 95.6zM128 432c35.2 0 69.2-13.1 95.4-36.7l26.1-23.6-111.7-121-48.3 27.6C63.8 292.9 48 320.2 48 349.7l0 2.3c0 44.2 35.8 80 80 80z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAmpersand = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;