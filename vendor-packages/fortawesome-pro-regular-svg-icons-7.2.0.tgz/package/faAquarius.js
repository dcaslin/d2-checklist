'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'aquarius';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e845';
var svgPathData = 'M410.5 290c7.1-3 15.2-2.6 21.9 1.5l132 80c11.3 6.9 15 21.6 8.1 33-6.9 11.3-21.6 15-33 8.1L420 340.1 300.4 412.5c-7.6 4.6-17.2 4.6-24.9 0L156 340.1 36.4 412.5c-11.3 6.9-26.1 3.2-33-8.1s-3.2-26.1 8.1-33l132-80 2.9-1.5c7.1-3 15.2-2.6 21.9 1.5l119.6 72.4 119.6-72.4 2.9-1.5zm0-192c7.1-3 15.2-2.6 21.9 1.5l132 80c11.3 6.9 15 21.6 8.1 33s-21.6 15-33 8.1L420 148.1 300.4 220.5c-7.6 4.6-17.2 4.6-24.9 0L156 148.1 36.4 220.5c-11.3 6.9-26.1 3.2-33-8.1s-3.2-26.1 8.1-33l132-80 2.9-1.5c7.1-3 15.2-2.6 21.9 1.5L288 171.9 407.6 99.5 410.5 98z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAquarius = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;