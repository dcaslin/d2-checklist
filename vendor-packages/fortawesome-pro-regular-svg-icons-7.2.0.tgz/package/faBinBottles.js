'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bin-bottles';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e5f5';
var svgPathData = 'M128 32c-17.7 0-32 14.3-32 32l0 32c-35.3 0-64 28.7-64 64l0 16-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l12.6 0 21.9 230.1c3.1 32.8 30.7 57.9 63.7 57.9l331.6 0c33 0 60.6-25.1 63.7-57.9L539.4 224 552 224c13.3 0 24-10.7 24-24s-10.7-24-24-24l-8 0 0-16c0-35.3-28.7-64-64-64l0-32c0-17.7-14.3-32-32-32l-64 0c-17.7 0-32 14.3-32 32l0 32c-35.3 0-64 28.7-64 64 0-35.3-28.7-64-64-64l0-32c0-17.7-14.3-32-32-32l-64 0zM106.3 449.5L84.8 224 491.2 224 469.7 449.5c-.8 8.2-7.7 14.5-15.9 14.5l-331.6 0c-8.2 0-15.1-6.3-15.9-14.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinBottles = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;