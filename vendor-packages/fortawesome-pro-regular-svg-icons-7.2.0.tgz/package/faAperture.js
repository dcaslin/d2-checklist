'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'aperture';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e2df';
var svgPathData = 'M256 464l67-116 13.8-23.8c0-.1 .1-.1 .1-.2l11.5-20 56.3 97.5C366.9 440.1 314.2 464 256 464zM163.6 208l-56.3-97.5C145.1 71.9 197.8 48 256 48 137.5 253.3 186.3 168.7 163.6 208zm87.8-56l56.3-97.5c54.8 14 100.9 49.8 128.5 97.5-292.1 0-111.9 0-184.8 0zm104.1 68.3c-.1-.1-.1-.2-.2-.3l-11.5-20 112.6 0c5 17.8 7.6 36.6 7.6 56 0 37.9-10.1 73.4-27.8 104-53.5-92.7-80.4-139.3-80.7-139.8zM48 256c0-37.9 10.1-73.4 27.8-104 51.6 89.4 82.4 142.7 92.4 160L55.6 312c-5-17.8-7.6-36.6-7.6-56zM204.3 457.5c-54.8-14-100.9-49.8-128.5-97.5l184.8 0-56.3 97.5zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM216.7 212c4.3-7.4 12.1-11.9 20.6-12l37.3 0c8.5 .1 16.3 4.6 20.5 11.8l18.7 32.3c4.2 7.4 4.2 16.4 0 23.8l0 .1-18.5 32 0 .1c-4.3 7.4-12.2 11.9-20.7 11.9l-37 0c-8.6 0-16.5-4.6-20.8-12l-18.5-32c-4.3-7.4-4.3-16.6 0-24l18.5-32z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAperture = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;