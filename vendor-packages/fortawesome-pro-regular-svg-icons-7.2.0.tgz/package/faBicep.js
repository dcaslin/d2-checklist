'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bicep';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e862';
var svgPathData = 'M232.1 0c30.9 0 56 25.1 56 56l0 48c0 48.6-39.4 88-88 88l-2.2 0 5.2 67.9c39.1-22.8 84.6-35.9 133.1-35.9 63.5 0 121.8 22.4 167.3 59.8 10.2 8.4 11.7 23.5 3.3 33.8-8.4 10.2-23.5 11.7-33.8 3.3-37.3-30.6-84.9-48.9-136.9-48.9-48.4 0-92.9 15.9-128.9 42.7l2.1 27.6c1 13.2-8.9 24.7-22.1 25.8s-24.7-8.9-25.8-22.1L144.1 119.2c-1-13.2 8.9-24.7 22.1-25.8s24.7 8.9 25.8 22.1l2.2 28.4 5.9 0c22.1 0 40-17.9 40-40l0-48c0-4.4-3.6-8-8-8L120.4 48c-18 0-32.8 11.8-36.4 28.1-14 62.2-35.8 179.8-35.8 307.9 0 44 35.6 79.8 79.6 80l358.8-23.9c13.2-.9 24.6 9.1 25.5 22.3s-9.1 24.6-22.3 25.5l-360 24-.8 .1-.8 0C57.4 512 .1 454.7 .1 384 .1 250.9 22.7 129.5 37.1 65.5 46 26.1 81.2 0 120.4 0L232.1 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBicep = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;