'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-down-from-arc';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e614';
var svgPathData = 'M256 48c114.9 0 208 93.1 208 208 0 13.3 10.7 24 24 24s24-10.7 24-24C512 114.6 397.4 0 256 0S0 114.6 0 256c0 13.3 10.7 24 24 24s24-10.7 24-24C48 141.1 141.1 48 256 48zM377.6 392.3c9-9.7 8.5-24.9-1.3-33.9s-24.9-8.5-33.9 1.3L280 426.9 280 184c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 242.9-62.4-67.2c-9-9.7-24.2-10.3-33.9-1.3s-10.3 24.2-1.3 33.9l104 112c4.5 4.9 10.9 7.7 17.6 7.7s13-2.8 17.6-7.7l104-112z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownFromArc = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;