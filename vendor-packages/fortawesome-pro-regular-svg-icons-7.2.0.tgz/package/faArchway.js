'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'archway';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f557';
var svgPathData = 'M0 56C0 42.7 10.7 32 24 32l464 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-8 0 0 352 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-144 0c-13.3 0-24-10.7-24-24l0-104c0-35.3-28.7-64-64-64s-64 28.7-64 64l0 104c0 13.3-10.7 24-24 24L24 480c-13.3 0-24-10.7-24-24s10.7-24 24-24l8 0 0-352-8 0C10.7 80 0 69.3 0 56zM80 80l0 48 352 0 0-48-352 0zm352 96l-352 0 0 256 64 0 0-80c0-61.9 50.1-112 112-112s112 50.1 112 112l0 80 64 0 0-256z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArchway = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;