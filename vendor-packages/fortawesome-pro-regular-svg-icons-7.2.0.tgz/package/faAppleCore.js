'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'apple-core';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e08f';
var svgPathData = 'M192 112c-8.8 0-16-7.2-16-16l0-16c0-44.2 35.8-80 80-80l16 0c8.8 0 16 7.2 16 16l0 16c0 44.2-35.8 80-80 80l-16 0zM128 464c4.6 0 13.6-1.7 24.9-5.1 25.4-7.6 52.7-7.6 78.1 0 11.3 3.4 20.3 5.1 24.9 5.1 11.4 0 24.9-4 38.9-13.1-34.1-39.3-54.9-90.7-54.9-146.9 0-46 13.9-88.8 37.7-124.4-12.7 3-26.4 7.5-39 12.4-30 11.7-63.5 11.7-93.5 0-12.6-4.9-26.2-9.4-39-12.4 23.8 35.6 37.7 78.4 37.7 124.4 0 56.2-20.7 107.6-54.9 146.9 13.9 9.2 27.4 13.1 38.9 13.1zM304 128c6.7 0 13 .6 19.1 1.9 .7 .1 1.4 .3 2.1 .4 13.4 3 25.9 9.1 37.2 18.3 4 3.2 3.3 9.3-.9 12.3-44.5 31.9-73.5 84.1-73.5 143.1 0 57.4 27.5 108.4 70 140.5 3.7 2.8 4.5 8 1.6 11.5-29.2 35.1-66.4 55.9-103.6 55.9-11.9 0-26.5-3.4-38.8-7.1-16.4-4.9-34.1-4.9-50.5 0-12.2 3.7-26.8 7.1-38.8 7.1-37.2 0-74.5-20.8-103.6-55.9-2.9-3.5-2.1-8.8 1.6-11.5 42.5-32.1 70-83.1 70-140.5 0-59-29-111.2-73.5-143.1-4.2-3-4.8-9.1-.9-12.3 11.3-9.2 23.8-15.3 37.2-18.3 .7-.2 1.4-.3 2.1-.4 6.1-1.2 12.4-1.9 19.1-1.9 27.3 0 59.7 10.3 82.7 19.3 18.8 7.3 39.9 7.3 58.7 0 22.9-8.9 55.4-19.3 82.7-19.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAppleCore = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;