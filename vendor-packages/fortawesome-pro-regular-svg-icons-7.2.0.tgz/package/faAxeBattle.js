'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'axe-battle';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f6b3';
var svgPathData = 'M425.2-.1c46.1 40.6 77.4 97.6 85 161.8L480 192 510.2 222.2c-7.6 64.2-38.9 121.2-85 161.8-8.2 7.2-20.8 3.2-25.6-6.6-22.7-46.2-67-79.8-119.7-87.7L280 520c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-230.2c-52.7 7.9-97 41.6-119.7 87.7-4.8 9.8-17.4 13.8-25.6 6.6-53.2-46.9-86.8-115.6-86.8-192.1S33.6 46.8 86.8-.1c8.2-7.2 20.8-3.2 25.6 6.6 22.7 46.2 67 79.8 119.7 87.7L232 24c0-13.3 10.7-24 24-24s24 10.7 24 24l0 70.2c52.7-7.9 97-41.6 119.7-87.7 4.8-9.8 17.4-13.8 25.6-6.6zM280 142.6l0 98.7c56.8 6.5 106.6 35.9 140 78.6 18.5-23.6 31.9-51.3 38.8-81.4l-12.7-12.7c-18.7-18.7-18.7-49.1 0-67.9l12.7-12.7c-6.9-30.1-20.3-57.8-38.8-81.4-33.4 42.7-83.2 72.1-140 78.6zm-48 0c-56.8-6.5-106.6-35.9-140-78.6-27.6 35.3-44 79.7-44 128s16.4 92.7 44 128c33.4-42.7 83.2-72.1 140-78.6l0-98.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAxeBattle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;