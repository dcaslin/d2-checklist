'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-rotate-left-15';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e886';
var svgPathData = 'M75.1 75c100-100 262.1-100 362 0s100 262.1 0 362.1-262.1 100-362.1 0c-14.9-14.9-27.6-31.2-38.1-48.5-6.9-11.3-3.2-26.1 8.1-33s26.1-3.2 32.9 8.1c8.5 14 18.8 27.3 31 39.5 81.2 81.2 212.9 81.2 294.2 0s81.2-213 0-294.2-212.9-81.2-294.2 0L41 177c-6.9 6.9-17.2 8.9-26.2 5.2S0 169.7 0 160L0 24C0 10.7 10.7 0 24 0S48 10.7 48 24L48 102.1 75.1 75zm98.3 87.6c7.4-3.7 16.3-3.3 23.3 1.1s11.4 12.1 11.4 20.4l0 144c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-105.4c-11.3 4-24-.9-29.5-11.8-5.9-11.9-1.1-26.3 10.8-32.2l32-16zM336.1 160c13.3 0 24 10.7 24 24s-10.7 24-24 24l-48 0 0 24 20 0c33.1 0 60 26.9 60 60s-26.9 60-60 60l-44 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l44 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-44 0c-13.3 0-24-10.7-24-24l0-72c0-13.3 10.7-24 24-24l72 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateLeft15 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;