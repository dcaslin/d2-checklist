'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bath';
var width = 512;
var height = 512;
var aliases = [128705,"bathtub"];
var unicode = 'f2cd';
var svgPathData = 'M80 69.3c0-11.7 9.5-21.3 21.3-21.3 5.6 0 11 2.2 15 6.2l4.8 4.8c-5.8 11.1-9.1 23.7-9.1 37 0 23.9 10.5 45.4 27.2 60.1-5.3 9.2-4 21.1 3.9 28.9 9.4 9.4 24.6 9.4 33.9 0L281 81c9.4-9.4 9.4-24.6 0-33.9-7.8-7.8-19.7-9.1-28.9-3.9-14.7-16.7-36.1-27.2-60.1-27.2-13.4 0-25.9 3.3-37 9.1l-4.8-4.8C137.2 7.3 119.6 0 101.3 0 63 0 32 31 32 69.3l0 186.7-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l8 0 0 64c0 28.4 12.4 54 32 71.6L64 488c0 13.3 10.7 24 24 24s24-10.7 24-24l0-25.3c5.2 .9 10.5 1.3 16 1.3l256 0c5.5 0 10.8-.5 16-1.3l0 25.3c0 13.3 10.7 24 24 24s24-10.7 24-24l0-48.4c19.6-17.6 32-43.1 32-71.6l0-64 8 0c13.3 0 24-10.7 24-24s-10.7-24-24-24L80 256 80 69.3zm137.5 7.3l-44.8 44.8c-7.7-5.8-12.6-15.1-12.6-25.5 0-17.7 14.3-32 32-32 10.4 0 19.6 4.9 25.5 12.6zM80 304l352 0 0 64c0 26.5-21.5 48-48 48l-256 0c-26.5 0-48-21.5-48-48l0-64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBath = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;