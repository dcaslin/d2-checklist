'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'boombox';
var width = 576;
var height = 512;
var aliases = [128254];
var unicode = 'f8a5';
var svgPathData = 'M80 88l0 72 80 0c0-17.7 14.3-32 32-32s32 14.3 32 32l32 0c0-17.7 14.3-32 32-32s32 14.3 32 32l32 0c0-17.7 14.3-32 32-32s32 14.3 32 32l80 0 0-72c0-22.1-17.9-40-40-40L120 48C97.9 48 80 65.9 80 88zM32 168.6L32 88C32 39.4 71.4 0 120 0L456 0c48.6 0 88 39.4 88 88l0 80.6c19.1 11.1 32 31.7 32 55.4l0 192c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 224c0-23.7 12.9-44.4 32-55.4zM192 208L64 208c-8.8 0-16 7.2-16 16l0 192c0 8.8 7.2 16 16 16l448 0c8.8 0 16-7.2 16-16l0-192c0-8.8-7.2-16-16-16l-320 0zM176 352a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm0-112a80 80 0 1 1 0 160 80 80 0 1 1 0-160zm256 80a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm-112 0a80 80 0 1 1 160 0 80 80 0 1 1 -160 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBoombox = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;