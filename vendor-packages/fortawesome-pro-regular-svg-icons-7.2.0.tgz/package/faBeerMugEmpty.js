'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'beer-mug-empty';
var width = 576;
var height = 512;
var aliases = ["beer"];
var unicode = 'f0fc';
var svgPathData = 'M400 80l0 271.5c0 .3 0 .7 0 1l0 31.5c0 26.5-21.5 48-48 48l-192 0c-26.5 0-48-21.5-48-48l0-304 288 0zm48 304l0-17.2 97-48.5c19-9.5 31-28.9 31-50.1L576 152c0-30.9-25.1-56-56-56l-72 0 0-16c0-26.5-21.5-48-48-48L112 32C85.5 32 64 53.5 64 80l0 304c0 53 43 96 96 96l192 0c53 0 96-43 96-96zm75.6-108.6l-75.6 37.8 0-169.2 72 0c4.4 0 8 3.6 8 8l0 116.2c0 3-1.7 5.8-4.4 7.2zM180 128c-11 0-20 9-20 20l0 216c0 11 9 20 20 20s20-9 20-20l0-216c0-11-9-20-20-20zm76 0c-11 0-20 9-20 20l0 216c0 11 9 20 20 20s20-9 20-20l0-216c0-11-9-20-20-20zm96 20c0-11-9-20-20-20s-20 9-20 20l0 216c0 11 9 20 20 20s20-9 20-20l0-216z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBeerMugEmpty = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;