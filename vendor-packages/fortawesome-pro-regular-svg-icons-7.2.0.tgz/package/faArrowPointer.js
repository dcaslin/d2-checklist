'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-pointer';
var width = 448;
var height = 512;
var aliases = ["mouse-pointer"];
var unicode = 'f245';
var svgPathData = 'M102.4 4.8c-7.3-5.5-17-6.3-25.1-2.3S64 14.9 64 24l0 400c0 10.3 6.6 19.5 16.4 22.8s20.6-.1 26.8-8.4l96.7-129 94.6 189.3c5.9 11.9 20.3 16.7 32.2 10.7s16.7-20.3 10.7-32.2l-94.7-189.3 161.2 0c10.3 0 19.5-6.6 22.8-16.4s-.1-20.6-8.4-26.8L102.4 4.8zM112 352l0-280 224 168-128 0c-7.6 0-14.7 3.6-19.2 9.6L112 352z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowPointer = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;