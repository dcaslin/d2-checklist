'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bag-seedling';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e5f2';
var svgPathData = 'M59.9 150.1C52 181.9 48 214.4 48 247.2l0 17.7c0 32.7 4 65.3 11.9 97l5.5 22.1 317 0 5.5-22.1c7.9-31.7 11.9-64.3 11.9-97l0-17.7c0-32.7-4-65.3-11.9-97l-5.5-22.1-317 0-5.5 22.1zM395.5 48l-342.9 0 14.2 32 314.5 0 14.2-32zM51.7 464l344.6 0-12.8-32-319 0-12.8 32zM23 99.8L3.4 55.7C1.2 50.6 0 45.1 0 39.6 0 17.7 17.7 0 39.6 0L408.4 0c21.9 0 39.6 17.7 39.6 39.6 0 5.5-1.2 11-3.4 16.1l-19.6 44.2 9.7 38.7c8.9 35.5 13.4 72 13.4 108.7l0 17.7c0 36.6-4.5 73.1-13.4 108.7l-8.8 35.1 19.3 48.2c1.9 4.8 2.9 9.8 2.9 14.9 0 22.2-18 40.2-40.2 40.2L40.2 512C18 512 0 494 0 471.8 0 466.6 1 461.6 2.9 456.8l19.3-48.2-8.8-35.1C4.5 338 0 301.5 0 264.8l0-17.7C0 210.5 4.5 174 13.4 138.5L23 99.8zM112 160l2 0c47.3 0 88.4 26 110 64.5 21.6-38.5 62.7-64.5 110-64.5l2 0c8.8 0 16 7.2 16 16 0 59.2-45.9 107.6-104 111.7l0 40.3c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-40.3c-58.1-4.1-104-52.6-104-111.7 0-8.8 7.2-16 16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBagSeedling = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;