'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bin-bottles-recycle';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e5f6';
var svgPathData = 'M96 64c0-17.7 14.3-32 32-32l64 0c17.7 0 32 14.3 32 32l0 32c35.3 0 64 28.7 64 64 0-35.3 28.7-64 64-64l0-32c0-17.7 14.3-32 32-32l64 0c17.7 0 32 14.3 32 32l0 32c35.3 0 64 28.7 64 64l0 16 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-12.6 0-21.9 230.1c-3.1 32.8-30.7 57.9-63.7 57.9l-331.6 0c-33 0-60.6-25.1-63.7-57.9L36.6 224 24 224c-13.3 0-24-10.7-24-24s10.7-24 24-24l8 0 0-16c0-35.3 28.7-64 64-64l0-32zM84.8 224l21.5 225.5c.8 8.2 7.7 14.5 15.9 14.5l331.6 0c8.2 0 15.1-6.3 15.9-14.5L491.2 224 84.8 224zM288 288c-2.4 0-4.7 1.1-6.1 3.1l-15.7 21.5c-7.4 10.1-21.4 12.8-32.1 6.2-11.8-7.4-14.9-23.3-6.6-34.5l15.7-21.5C253.7 248.4 270.3 240 288 240s34.3 8.4 44.8 22.7l15.7 21.5c8.3 11.3 5.2 27.1-6.6 34.5-10.7 6.7-24.6 4-32.1-6.2l-15.7-21.5c-1.4-1.9-3.7-3.1-6.1-3.1zm-80.7 61.2c11.8 7.4 14.9 23.3 6.6 34.5l-4.8 6.5c-.8 1.1-1.2 2.3-1.2 3.6 0 3.4 2.7 6.1 6.1 6.1l29.9 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-29.9 0c-29.9 0-54.1-24.2-54.1-54.1 0-11.5 3.7-22.7 10.5-32l4.8-6.5c7.4-10.1 21.4-12.8 32.1-6.2zM308 424c0-13.3 10.7-24 24-24l29.9 0c3.4 0 6.1-2.7 6.1-6.1 0-1.3-.4-2.6-1.2-3.6l-4.8-6.5c-8.3-11.3-5.2-27.1 6.6-34.5 10.7-6.7 24.6-4 32.1 6.2l4.8 6.5c6.8 9.3 10.5 20.5 10.5 32 0 29.9-24.2 54.1-54.1 54.1L332 448c-13.3 0-24-10.7-24-24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBinBottlesRecycle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;