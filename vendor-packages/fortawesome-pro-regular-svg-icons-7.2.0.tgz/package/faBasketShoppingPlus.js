'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'basket-shopping-plus';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e653';
var svgPathData = 'M142 192l349.6 0-47.9 227.3c-1.6 7.4-8.1 12.7-15.7 12.7l-280.1 0c-7.6 0-14.1-5.3-15.7-12.7L84.4 192 142 192zm226.1-48l-160.1 0 45.2-48 1.9-2 33-35 33 35 1.9 2 45.2 48zM536 144l-102 0c-12.5-13.3-49.5-52.6-111.1-117.9L305.5 7.5C300.9 2.7 294.6 0 288 0s-12.9 2.7-17.5 7.5c-1.2 1.3-33.7 35.8-97.5 103.5L142 144 40 144c-13.3 0-24 10.7-24 24 0 11.6 8.3 21.3 19.3 23.5l50 237.6c6.2 29.6 32.4 50.8 62.6 50.8l280.1 0c30.3 0 56.4-21.2 62.6-50.8l50-237.6c11-2.2 19.3-11.9 19.3-23.5 0-13.3-10.7-24-24-24zM288 224c-13.3 0-24 10.7-24 24l0 32-32 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l32 0 0 32c0 13.3 10.7 24 24 24s24-10.7 24-24l0-32 32 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-32 0 0-32c0-13.3-10.7-24-24-24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBasketShoppingPlus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;