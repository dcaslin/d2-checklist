'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-u-turn-down-right';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e7e8';
var svgPathData = 'M505 367c9.4 9.4 9.4 24.6 0 33.9L385 521c-9.4 9.4-24.6 9.4-33.9 0-9.4-9.4-9.4-24.6 0-33.9l79-79-242.1 0C84.2 408 0 323.8 0 220S84.2 32 188 32l236 0 2.5 .1C438.6 33.4 448 43.6 448 56s-9.4 22.6-21.5 23.9L424 80 188 80C110.7 80 48 142.7 48 220s62.7 140 140 140l242.1 0-79-79-1.7-1.8c-7.7-9.4-7.1-23.3 1.7-32.1s22.7-9.3 32.1-1.7L385 247 505 367z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUTurnDownRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;