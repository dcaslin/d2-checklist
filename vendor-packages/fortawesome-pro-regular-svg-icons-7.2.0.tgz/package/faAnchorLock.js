'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'anchor-lock';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4ad';
var svgPathData = 'M328 88a40 40 0 1 1 -80 0 40 40 0 1 1 80 0zM288 0c-48.6 0-88 39.4-88 88 0 40.3 27.1 74.2 64 84.7l0 273.4C191.5 434.6 136 371.8 136 296l0-11.1 24.2 21.2c10 8.7 25.1 7.7 33.9-2.3s7.7-25.1-2.3-33.9l-64-56c-9-7.9-22.6-7.9-31.6 0l-64 56c-10 8.7-11 23.9-2.3 33.9s23.9 11 33.9 2.3L88 284.9 88 296c0 110.5 89.5 200 200 200 28.4 0 55.5-5.9 80-16.6l0-54.1c-16.8 10.4-35.7 17.6-56 20.8l0-273.4c36.9-10.4 64-44.4 64-84.7 0-48.6-39.4-88-88-88zM560 304.1l0 47.9-64 0 0-47.9c0-17.7 14.3-32 32-32s32 14.3 32 32zM416 400l0 96c0 26.5 21.5 48 48 48l128 0c26.5 0 48-21.5 48-48l0-96c0-20.9-13.4-38.7-32-45.3l0-50.6c0-44.2-35.8-80-80-80s-80 35.8-80 80l0 50.6c-18.6 6.6-32 24.4-32 45.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAnchorLock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;