'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrows-turn-to-dots';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e4c1';
var svgPathData = 'M271-9c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9l-47 47 94.1 0c53 0 96 43 96 96l0 32c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-32c0-26.5-21.5-48-48-48l-94.1 0 47 47c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-88-88c-9.4-9.4-9.4-24.6 0-33.9L271-9zM177 263l88 88c9.4 9.4 9.4 24.6 0 33.9l-88 88c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l47-47-94.1 0c-26.5 0-48 21.5-48 48l0 32c0 13.3-10.7 24-24 24S0 485.3 0 472l0-32c0-53 43-96 96-96l94.1 0-47-47c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0zM320 368a64 64 0 1 1 128 0 64 64 0 1 1 -128 0zM64 160a64 64 0 1 1 0-128 64 64 0 1 1 0 128z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsTurnToDots = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;