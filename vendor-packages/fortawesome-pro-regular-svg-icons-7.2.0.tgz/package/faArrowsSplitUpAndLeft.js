'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrows-split-up-and-left';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e4bc';
var svgPathData = 'M337.5-25c-9.4-9.4-24.6-9.4-33.9 0L199.5 79c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l63-63 0 242.1c-21.9-17.6-49.7-28.1-80-28.1l-134.1 0 63-63c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0L7.5 271c-9.4 9.4-9.4 24.6 0 33.9l104 104c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-63-63 134.1 0c44.2 0 80 35.8 80 80 0 2.1 .3 4.1 .8 6 7 64.1 61.3 114 127.2 114l32 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-32 0c-44.2 0-80-35.8-80-80l0-334.1 63 63c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L337.5-25z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsSplitUpAndLeft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;