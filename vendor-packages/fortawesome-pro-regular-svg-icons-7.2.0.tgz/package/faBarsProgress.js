'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bars-progress';
var width = 448;
var height = 512;
var aliases = ["tasks-alt"];
var unicode = 'f828';
var svgPathData = 'M158.1 80l-110.1 0 0 96 14.1 0 96-96zm-28.1 96l110.1 0 0-96-14.1 0-96 96zM288 176l112 0 0-96-112 0 0 96zM0 80C0 53.5 21.5 32 48 32l352 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48L48 224c-26.5 0-48-21.5-48-48L0 80zM400 336l-240 0 0 96 240 0 0-96zM48 336l0 96 64 0 0-96-64 0zm0-48l352 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48L48 480c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarsProgress = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;