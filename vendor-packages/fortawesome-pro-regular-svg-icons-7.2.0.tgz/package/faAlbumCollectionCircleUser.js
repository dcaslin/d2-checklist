'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'album-collection-circle-user';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e48f';
var svgPathData = 'M152.5 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l208 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-208 0zm-48 96c-13.3 0-24 10.7-24 24s10.7 24 24 24l304 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-304 0zM484.8 208.6C475.6 198 462.4 192 448.5 192l-384 0c-13.9 0-27.1 6-36.3 16.6S15 233 17 246.8l32 224C52.4 494.4 72.6 512 96.5 512l180 0c-10.5-14.6-19-30.7-25.1-48l-154.9 0-32-224 261.8 0c30.4-20.2 66.9-32 106.2-32 20.3 0 39.8 3.1 58.1 9-1.6-3-3.6-5.8-5.8-8.4zM256.5 272c-63.1 0-114.3 35.8-114.3 80 0 41 44.1 74.8 100.8 79.5-1.7-10.2-2.6-20.7-2.6-31.5 0-9.5 .7-18.8 2-27.8-10.7-3.6-18-11.3-18-20.2 0-11.7 12.9-21.4 29.3-22.3 7.9-20.2 19.2-38.7 33.1-54.8-9.7-1.9-19.9-2.9-30.4-2.9zm320 128a144 144 0 1 0 -288 0 144 144 0 1 0 288 0zm-66.3 80.7C490 500.1 462.7 512 432.5 512s-57.5-11.9-77.7-31.3c6.2-19 24-32.7 45.1-32.7l65.2 0c21 0 38.9 13.7 45.1 32.7zM384.5 368a48 48 0 1 1 96 0 48 48 0 1 1 -96 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlbumCollectionCircleUser = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;