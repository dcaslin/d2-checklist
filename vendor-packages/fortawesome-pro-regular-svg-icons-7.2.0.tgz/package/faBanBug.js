'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'ban-bug';
var width = 512;
var height = 512;
var aliases = ["debug"];
var unicode = 'f7f9';
var svgPathData = 'M256 464c-114.9 0-208-93.1-208-208 0-48.8 16.8-93.7 44.9-129.1L385.1 419.1C349.7 447.2 304.8 464 256 464zm85.2-156.7l31.4 4.5c13.1 1.9 25.3-7.2 27.2-20.4s-7.2-25.3-20.4-27.2l-43.4-6.2 0-4.1 43.4-6.2c13.1-1.9 22.2-14 20.4-27.2s-14-22.2-27.2-20.4L336 205.5c-.1-4.1-.6-8.1-1.3-12l37-20.5c11.6-6.4 15.8-21 9.3-32.6s-21-15.8-32.6-9.3l-36.1 20.1c-14.5-14.3-34.3-23.1-56.2-23.1-25.7 0-48.5 12.1-63.2 30.9l-66-66c35.5-28.1 80.3-44.9 129.1-44.9 114.9 0 208 93.1 208 208 0 48.8-16.8 93.7-44.9 129.1l-77.9-77.9zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM132.6 264.2c-13.1 1.9-22.2 14-20.4 27.2s14 22.2 27.2 20.4l36.6-5.2c.1 4.1 .6 8.1 1.3 12l-37 20.5c-11.6 6.4-15.8 21-9.3 32.6s21 15.8 32.6 9.3l36.1-20.1c14.4 14.3 34.3 23.1 56.2 23.1 7.9 0 15.6-1.2 22.9-3.3l-120.2-120.2-26.1 3.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanBug = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;