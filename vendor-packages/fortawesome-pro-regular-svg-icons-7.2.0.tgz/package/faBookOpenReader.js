'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'book-open-reader';
var width = 512;
var height = 512;
var aliases = ["book-reader"];
var unicode = 'f5da';
var svgPathData = 'M208 64a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm144 0a96 96 0 1 0 -192 0 96 96 0 1 0 192 0zM212.4 265.8l19.6 8.2 0 184.4C184.4 441 134 432 83.2 432l-35.2 0 0-192 35.2 0c44.4 0 88.3 8.8 129.2 25.8zM428.8 432c-50.8 0-101.2 9-148.8 26.4l0-184.4 19.6-8.2c41-17.1 84.9-25.8 129.2-25.8l35.2 0 0 192-35.2 0zM256 232l-25.1-10.5C184.1 202 133.9 192 83.2 192L48 192c-26.5 0-48 21.5-48 48L0 432c0 26.5 21.5 48 48 48l35.2 0c50.7 0 100.9 10 147.7 29.5l12.8 5.3c7.9 3.3 16.7 3.3 24.6 0l12.8-5.3c46.8-19.5 97-29.5 147.7-29.5l35.2 0c26.5 0 48-21.5 48-48l0-192c0-26.5-21.5-48-48-48l-35.2 0c-50.7 0-100.9 10-147.7 29.5L256 232z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookOpenReader = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;