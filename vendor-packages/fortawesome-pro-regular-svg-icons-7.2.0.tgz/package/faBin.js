'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bin';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e763';
var svgPathData = 'M24 64C10.7 64 0 74.7 0 88s10.7 24 24 24l9.5 0 25.3 277.8c3 33 30.6 58.2 63.7 58.2l331.1 0c33.1 0 60.7-25.2 63.7-58.2l25.3-277.8 9.5 0c13.3 0 24-10.7 24-24s-10.7-24-24-24L24 64zm470.3 48L469.5 385.4c-.7 8.2-7.7 14.6-15.9 14.6l-331.1 0c-8.3 0-15.2-6.3-15.9-14.6L81.7 112 494.3 112z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBin = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;