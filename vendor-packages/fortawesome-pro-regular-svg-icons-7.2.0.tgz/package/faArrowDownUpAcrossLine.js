'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-down-up-across-line';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e4af';
var svgPathData = 'M471 145c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L401 7c-9.4-9.4-24.6-9.4-33.9 0L263 111c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l63-63 0 150.1-336 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l80 0 0 150.1-63-63c-9.4-9.4-24.6-9.4-33.9 0S-2.3 391.6 7 401L111 505c9.4 9.4 24.6 9.4 33.9 0L249 401c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-63 63 0-150.1 336 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-80 0 0-150.1 63 63zM408 328l-48 0 0 160c0 13.3 10.7 24 24 24s24-10.7 24-24l0-160zM104 184l48 0 0-160c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 160z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownUpAcrossLine = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;