'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'bell-exclamation';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f848';
var svgPathData = 'M291.9 464c-9.9 28-36.6 48-67.9 48s-58-20-67.9-48l135.8 0zM224 0c13.3 0 24 10.7 24 24l0 9.7C329.4 45.3 392 115.4 392 200l0 14.4c0 37.7 10 74.7 29 107.3l21.8 37.5c3.4 5.8 5.2 12.3 5.2 19 0 20.9-16.9 37.8-37.8 37.8L37.8 416c-20.9 0-37.8-16.9-37.8-37.8 0-6.7 1.8-13.3 5.2-19L27 321.7c19-32.6 29-69.6 29-107.3L56 200c0-84.6 62.6-154.7 144-166.3l0-9.7c0-13.3 10.7-24 24-24zm0 80c-66.3 0-120 53.7-120 120l0 14.4c0 46.2-12.3 91.6-35.5 131.5l-12.9 22.1 336.9 0-12.9-22.1C356.3 306 344 260.6 344 214.4l0-14.4c0-66.3-53.7-120-120-120zm0 256a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm0-208c18.6 0 33 16.1 31 34.6l-7.1 64.1C246.5 238.8 236.2 248 224 248s-22.5-9.2-23.8-21.3L193 162.6c-2-18.5 12.4-34.6 31-34.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBellExclamation = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;