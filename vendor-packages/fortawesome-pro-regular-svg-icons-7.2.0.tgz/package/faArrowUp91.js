'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-up-9-1';
var width = 512;
var height = 512;
var aliases = ["sort-numeric-up-alt"];
var unicode = 'f887';
var svgPathData = 'M368.5 112a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm4.6 105.9c-7.8 10.7-5.4 25.7 5.3 33.5s25.7 5.4 33.5-5.3L457.1 184c15.2-20.9 23.4-46.1 23.4-72 0-44.2-35.8-80-80-80s-80 35.8-80 80c0 41.4 31.4 75.4 71.7 79.6l-19.1 26.3zM424.5 312c0-7.5-3.5-14.6-9.5-19.2s-13.8-6-21-3.9l-56 16c-12.7 3.6-20.1 16.9-16.5 29.7s16.9 20.1 29.7 16.5l25.4-7.3 0 88.2-32 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l112 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-32 0 0-120zM145.5 39c-9.4-9.4-24.6-9.4-33.9 0L7.5 143c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l63-63 0 342.1c0 13.3 10.7 24 24 24s24-10.7 24-24l0-342.1 63 63c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L145.5 39z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUp91 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;