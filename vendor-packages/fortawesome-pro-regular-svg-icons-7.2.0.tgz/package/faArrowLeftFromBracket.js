'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-left-from-bracket';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e668';
var svgPathData = 'M344 432c-13.3 0-24 10.7-24 24s10.7 24 24 24l72 0c53 0 96-43 96-96l0-256c0-53-43-96-96-96l-72 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l72 0c26.5 0 48 21.5 48 48l0 256c0 26.5-21.5 48-48 48l-72 0zM7 239c-9.4 9.4-9.4 24.6 0 33.9L143 409c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-95-95 246.1 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-246.1 0 95-95c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0L7 239z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowLeftFromBracket = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;