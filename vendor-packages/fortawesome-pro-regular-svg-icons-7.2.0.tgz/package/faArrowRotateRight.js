'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-rotate-right';
var width = 512;
var height = 512;
var aliases = [8635,"arrow-right-rotate","arrow-rotate-forward","redo"];
var unicode = 'f01e';
var svgPathData = 'M488.2 0c-13.3 0-24 10.7-24 24l0 78.1-27.1-27.1c-100-100-262.1-100-362 0s-100 262.1 0 362 262.1 100 362 0c14.9-14.9 27.6-31.2 38.1-48.5 6.9-11.3 3.2-26.1-8.1-33s-26.1-3.2-33 8.1c-8.5 14-18.8 27.3-31 39.4-81.2 81.2-212.9 81.2-294.2 0s-81.2-212.9 0-294.2 212.9-81.2 294.2 0l27.1 27.1-78.2 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l136.1 0c13.3 0 24-10.7 24-24l0-136c0-13.3-10.7-24-24-24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;