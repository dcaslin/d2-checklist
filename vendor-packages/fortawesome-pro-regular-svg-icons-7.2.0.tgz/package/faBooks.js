'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'books';
var width = 576;
var height = 512;
var aliases = [128218];
var unicode = 'f5db';
var svgPathData = 'M96.3 48l48 0c8.8 0 16 7.2 16 16l0 32-80 0 0-32c0-8.8 7.2-16 16-16zm-16 96l80 0 0 224-80 0 0-224zm128-78l0-2c0-35.3-28.7-64-64-64l-48 0c-35.3 0-64 28.7-64 64l0 384c0 35.3 28.7 64 64 64l48 0c15.1 0 29-5.3 40-14 11 8.8 24.9 14 40 14l48 0c35.3 0 64-28.7 64-64l0-164.4 48.6 181.2c9.1 34.1 44.2 54.4 78.4 45.3l46.4-12.4c34.1-9.1 54.4-44.2 45.3-78.4L455.4 48.3C446.3 14.2 411.2-6.1 377 3.1L330.7 15.5c-24.4 6.5-41.8 26.4-46.3 49.7-3.9-.8-8-1.1-12.1-1.1l-48 0c-5.5 0-10.9 .7-16 2zm0 62c0-8.8 7.2-16 16-16l48 0c8.8 0 16 7.2 16 16l0 320c0 8.8-7.2 16-16 16l-48 0c-8.8 0-16-7.2-16-16l0-320zm-48 320c0 8.8-7.2 16-16 16l-48 0c-8.8 0-16-7.2-16-16l0-32 80 0 0 32zM389.5 49.4c8.5-2.3 17.3 2.8 19.6 11.3l8.3 30.9-77.3 20.7-8.3-30.9c-2.3-8.5 2.8-17.3 11.3-19.6l46.4-12.4zm21 325.7l-58-216.4 77.3-20.7 58 216.4-77.3 20.7zm12.4 46.4l77.3-20.7 8.3 30.9c2.3 8.5-2.8 17.3-11.3 19.6l-46.4 12.4c-8.5 2.3-17.3-2.8-19.6-11.3l-8.3-30.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBooks = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;