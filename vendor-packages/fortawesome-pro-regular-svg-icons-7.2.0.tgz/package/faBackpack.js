'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'backpack';
var width = 448;
var height = 512;
var aliases = [127890];
var unicode = 'f5d4';
var svgPathData = 'M184 48l80 0c4.4 0 8 3.6 8 8l0 24-96 0 0-24c0-4.4 3.6-8 8-8zm-56 8l0 24C57.3 80 0 137.3 0 208L0 448c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-240c0-70.7-57.3-128-128-128l0-24c0-30.9-25.1-56-56-56L184 0c-30.9 0-56 25.1-56 56zM352 464l0-120c0-39.8-32.2-72-72-72l-112 0c-39.8 0-72 32.2-72 72l0 120-32 0c-8.8 0-16-7.2-16-16l0-240c0-44.2 35.8-80 80-80l192 0c44.2 0 80 35.8 80 80l0 240c0 8.8-7.2 16-16 16l-32 0zm-208 0l0-120c0-13.3 10.7-24 24-24l112 0c13.3 0 24 10.7 24 24l0 120-160 0zm8-288c-13.3 0-24 10.7-24 24s10.7 24 24 24l144 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-144 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBackpack = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;