'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'balloons';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e2e4';
var svgPathData = 'M160 332c6.9-5.2 13.5-10.7 20-16.5 10.8-9.7 25.1-23.6 39.3-40.4 29.8-35.4 52.7-76.3 52.7-115.1 0-61.9-50.1-112-112-112S48 98.1 48 160c0 38.7 22.9 79.7 52.7 115.1 14.2 16.9 28.5 30.8 39.3 40.4 6.4 5.8 13.1 11.3 20 16.5zm-59.9 77.8L128 368S0 272 0 160C0 71.6 71.6 0 160 0S320 71.6 320 160c0 112-128 208-128 208l27.9 41.8c2.7 4 4.1 8.8 4.1 13.6 0 13.6-11 24.6-24.6 24.6l-78.9 0c-13.6 0-24.6-11-24.6-24.6 0-4.8 1.4-9.6 4.1-13.6zM152 128c-13.3 0-24 10.7-24 24s-10.7 24-24 24-24-10.7-24-24c0-39.8 32.2-72 72-72 13.3 0 24 10.7 24 24s-10.7 24-24 24zM294 335.3c12.3-14.8 22.5-28.8 30.7-41.8 8.8 15.8 19.8 31.1 31.9 45.6 14.2 16.9 28.5 30.8 39.3 40.4 6.4 5.8 13.1 11.3 20 16.5 6.9-5.2 13.5-10.7 20-16.5 10.8-9.7 25.1-23.6 39.3-40.4 29.8-35.4 52.7-76.3 52.7-115.1 0-61.9-50.1-112-112-112-18.4 0-35.7 4.4-51.1 12.3-2.8-16.2-7.5-31.8-13.9-46.6 19.8-8.8 41.8-13.7 64.9-13.7 88.4 0 160 71.6 160 160 0 112-128 208-128 208l27.9 41.8c2.7 4 4.1 8.8 4.1 13.6 0 13.6-11 24.6-24.6 24.6l-78.9 0c-13.6 0-24.6-11-24.6-24.6 0-4.8 1.4-9.6 4.1-13.6L384 432s-52.2-39.2-90-96.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBalloons = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;