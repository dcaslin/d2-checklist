'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'badge-sheriff';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f8a2';
var svgPathData = 'M296.3 8c0 10.3-3.9 19.6-10.2 26.7l37.5 66.7c6.1 10.8 17.5 17.5 29.9 17.5l79.8 0c3-8.8 9.1-16.5 17.8-21.5 19.1-11 43.6-4.5 54.6 14.6s4.5 43.6-14.6 54.6c-8.7 5-18.4 6.4-27.5 4.6l-41.6 66.5c-7 11.1-7 25.2 0 36.3l41.6 66.5c9.1-1.8 18.9-.4 27.5 4.6 19.1 11 25.7 35.5 14.6 54.6s-35.5 25.7-54.6 14.6c-8.7-5-14.7-12.7-17.8-21.5l-79.8 0c-12.4 0-23.8 6.7-29.9 17.5l-37.5 66.7c6.3 7.1 10.2 16.4 10.2 26.7 0 22.1-17.9 40-40 40s-40-17.9-40-40c0-10.3 3.9-19.6 10.2-26.7L189 410.6c-6.1-10.8-17.5-17.5-29.9-17.5l-79.8 0c-3 8.8-9.1 16.5-17.8 21.5-19.1 11-43.6 4.5-54.6-14.6s-4.5-43.6 14.6-54.6c8.7-5 18.4-6.4 27.5-4.6l41.6-66.5c6.9-11.1 6.9-25.2 0-36.3L49 171.3c-9.1 1.8-18.9 .4-27.5-4.6-19.1-11-25.7-35.5-14.6-54.6S42.4 86.3 61.5 97.4c8.7 5 14.7 12.7 17.8 21.5l79.8 0c12.4 0 23.8-6.7 29.9-17.5l37.5-66.7c-6.3-7.1-10.2-16.4-10.2-26.7 0-22.1 17.9-40 40-40s40 17.9 40 40zm-40 71.6l-25.5 45.3c-14.6 25.9-42 41.9-71.7 41.9l-56.2 0 28.5 45.5c16.7 26.7 16.7 60.5 0 87.2l-28.5 45.5 56.2 0c29.7 0 57.1 16 71.7 41.9l25.5 45.3 25.5-45.3c14.6-25.9 42-41.9 71.7-41.9l56.2 0-28.5-45.5c-16.7-26.7-16.7-60.5 0-87.2l28.5-45.5-56.2 0c-29.7 0-57.1-16-71.7-41.9L256.3 79.6zM255.7 200a56 56 0 1 1 .6 112 56 56 0 1 1 -.6-112z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBadgeSheriff = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;