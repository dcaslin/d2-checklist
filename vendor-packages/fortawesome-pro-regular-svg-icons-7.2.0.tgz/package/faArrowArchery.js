'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-archery';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e839';
var svgPathData = 'M554.7-39.3c8.2-2 16.8 .4 22.8 6.3s8.3 14.6 6.3 22.8l-32 128c-2.1 8.4-8.5 15-16.9 17.3s-17.3 0-23.4-6.2l-31.1-31.1-301.4 301.4 12.7 50.8c2 8.2-.4 16.8-6.3 22.8l-64 64c-6.1 6.1-15 8.5-23.4 6.2s-14.8-8.9-16.9-17.3l-12.5-50-50-12.5c-8.4-2.1-15-8.5-17.3-16.9s0-17.3 6.2-23.4l64-64 2.3-2.1c5.8-4.4 13.3-6 20.4-4.2l50.8 12.7 301.4-301.4-31-31c-6.1-6.1-8.5-15-6.2-23.4s8.9-14.8 17.3-16.9l128-32zM71.4 427l22.9 5.7 3.1 1c7.1 2.8 12.5 8.9 14.3 16.5l5.7 22.9 24.4-24.4-9.2-36.8-36.8-9.2-24.4 24.4zm408-398l36.1 36.1 12-48.1-48.1 12z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowArchery = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;