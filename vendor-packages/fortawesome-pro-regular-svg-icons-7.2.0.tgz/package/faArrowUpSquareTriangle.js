'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-up-square-triangle';
var width = 512;
var height = 512;
var aliases = ["sort-shapes-up-alt"];
var unicode = 'f88b';
var svgPathData = 'M496 454.9c0-4.5-1.2-9-3.6-12.9L408.2 301.7c-5.1-8.5-14.3-13.7-24.2-13.7s-19.1 5.2-24.2 13.7L275.6 442c-2.3 3.9-3.6 8.4-3.6 12.9 0 13.8 11.2 25.1 25.1 25.1l173.9 0c13.8 0 25.1-11.2 25.1-25.1zM336 80l96 0 0 96-96 0 0-96zm94.4 352l-92.8 0 46.4-77.4 46.4 77.4zM288 80l0 96c0 26.5 21.5 48 48 48l96 0c26.5 0 48-21.5 48-48l0-96c0-26.5-21.5-48-48-48l-96 0c-26.5 0-48 21.5-48 48zM145 39c-9.4-9.4-24.6-9.4-33.9 0L23 127c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l47-47 0 342.1c0 13.3 10.7 24 24 24s24-10.7 24-24l0-342.1 47 47c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L145 39z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpSquareTriangle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;