'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-rotate-right-30';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e889';
var svgPathData = 'M488.1 0c13.3 0 24 10.7 24 24l0 136c0 9.7-5.8 18.5-14.8 22.2-9 3.7-19.3 1.6-26.2-5.2l-68.1-68.1c-81.2-81.2-212.9-81.2-294.2 0s-81.2 213 0 294.2c81.2 81.2 212.9 81.2 294.2 0 12.2-12.2 22.5-25.4 31-39.5 6.9-11.3 21.6-14.9 32.9-8.1 11.3 6.9 15 21.6 8.1 33-10.5 17.3-23.2 33.6-38.1 48.5-100 100-262.1 100-362.1 0S-25 174.9 75 75 337-25 437 75l27.1 27.1 0-78.1c0-13.2 10.8-24 24-24zm-308 160c33.1 0 60 26.9 60 60 0 13.5-4.5 26-12.1 36 7.6 10 12.1 22.5 12.1 36 0 33.1-26.9 60-60 60l-28 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l28 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-20 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l20 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-28 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l28 0zm164 0c30.9 0 56 25.1 56 56l0 80c0 30.9-25.1 56-56 56l-16 0c-30.9 0-56-25.1-56-56l0-80c0-30.9 25.1-56 56-56l16 0zm-16 48c-4.4 0-8 3.6-8 8l0 80c0 4.4 3.6 8 8 8l16 0c4.4 0 8-3.6 8-8l0-80c0-4.4-3.6-8-8-8l-16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateRight30 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;