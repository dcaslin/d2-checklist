'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-rotate-right-15';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e888';
var svgPathData = 'M488.1 0c13.3 0 24 10.7 24 24l0 136c0 9.7-5.8 18.5-14.8 22.2s-19.3 1.6-26.2-5.2l-68.1-68.1c-81.2-81.2-212.9-81.2-294.2 0s-81.2 213 0 294.2c81.2 81.2 212.9 81.2 294.2 0 12.2-12.2 22.5-25.4 31-39.5 6.9-11.3 21.6-14.9 32.9-8.1 11.3 6.9 15 21.6 8.1 33-10.5 17.3-23.2 33.6-38.1 48.5-100 100-262.1 100-362.1 0S-25 174.9 75 75 337-25 437 75l27.1 27.1 0-78.1c0-13.2 10.8-24 24-24zM173.4 162.5c7.4-3.7 16.3-3.3 23.3 1.1s11.4 12.1 11.4 20.4l0 144c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-105.4c-11.3 4-24-.9-29.5-11.8-5.9-11.8-1.1-26.3 10.8-32.2l32-16zM336.1 160c13.3 0 24 10.7 24 24s-10.7 24-24 24l-48 0 0 24 20 0c33.1 0 60 26.9 60 60s-26.9 60-60 60l-44 0c-13.2 0-24-10.7-24-24s10.8-24 24-24l44 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-44 0c-13.2 0-24-10.7-24-24l0-72c0-13.2 10.8-24 24-24l72 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateRight15 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;