'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'battery-bolt';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f376';
var svgPathData = 'M112 448c-44.2 0-80-35.8-80-80l0-224c0-44.2 35.8-80 80-80l191.5 0-52.6 48-138.9 0c-17.7 0-32 14.3-32 32l0 224c0 17.7 14.3 32 32 32l76.1 0c-5.6 15.9-5.4 32.8 0 48L112 448zM451.9 112c5.6-15.9 5.4-32.8 0-48L528 64c44.2 0 80 35.8 80 80l0 48c17.7 0 32 14.3 32 32l0 64c0 17.7-14.3 32-32 32l0 48c0 44.2-35.8 80-80 80l-191.5 0 52.6-48 138.9 0c17.7 0 32-14.3 32-32l0-224c0-17.7-14.3-32-32-32l-76.1 0zM397.5 68.2c9.2 6.3 12.9 18 8.9 28.4L354.8 232 440 232c9.9 0 18.8 6.1 22.4 15.3s1.1 19.7-6.2 26.4l-184 168c-8.2 7.5-20.5 8.4-29.7 2.1s-12.9-18-8.9-28.4L285.2 280 200 280c-9.9 0-18.8-6.1-22.4-15.3s-1.1-19.7 6.2-26.4l184-168c8.2-7.5 20.5-8.4 29.7-2.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBatteryBolt = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;