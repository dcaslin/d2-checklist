'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-up-from-water-pump';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4b6';
var svgPathData = 'M144 32c-26.5 0-48 21.5-48 48l0 176-16 0c-26.5 0-48 21.5-48 48l0 79.6c16.4-1.8 33.4 1.9 48 11.7l0-91.2 480 0 0 92 .1 .1c4.2 2.3 8.5 4.6 12.6 1.5 10.7-8.1 22.9-12.7 35.3-14.1l0-79.5c0-26.5-21.5-48-48-48l-56 0 0-142.1 47 47c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L497 39c-9.4-9.4-24.6-9.4-33.9 0l-88 88c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l47-47 0 142.1-136 0 0-176c0-26.5-21.5-48-48-48L144 32zM474.6 476.1c19 14.4 41.9 28.2 67.2 33.3 26.5 5.4 54.3 .8 80.7-19.1 10.6-8 12.7-23 4.7-33.6s-23-12.7-33.6-4.7c-14.9 11.2-28.6 13.1-42.3 10.3-14.9-3-30.9-11.9-47.8-24.6-38.4-29-90.5-29-129 0-24 18.1-40.7 26.3-54.5 26.3s-30.5-8.2-54.5-26.3c-38.4-29-90.5-29-129 0-21.6 16.3-41.3 25.8-58.9 25.7-9.6-.1-19.9-3-31.2-11.5-10.6-8-25.6-5.9-33.6 4.7S7 482.3 17.6 490.3c19.1 14.4 39.4 21 59.8 21.1 33.9 .2 64.3-17.4 88.1-35.3 21.3-16.1 49.9-16.1 71.2 0 24.2 18.3 52.3 35.9 83.4 35.9s59.1-17.7 83.4-35.9c21.3-16.1 49.9-16.1 71.2 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUpFromWaterPump = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;