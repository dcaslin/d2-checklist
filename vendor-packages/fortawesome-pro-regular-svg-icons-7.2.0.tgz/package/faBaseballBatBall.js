'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'baseball-bat-ball';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f432';
var svgPathData = 'M445.5-14.9c31.4-25.6 77.8-23.8 107.1 5.5l32.8 32.8 5.5 6.1c23.9 29.3 23.9 71.7 0 101l-5.5 6.1-176.1 176.1c-5.2 5.2-10.9 9.9-16.9 14.1l-6.2 4-139.7 83.8c-5 3-9.7 6.7-13.8 10.8l-97.3 97.3c1.8 7.8-.2 16.3-6.3 22.3-8.8 8.8-22.7 9.3-32.1 1.7l-1.8-1.7-64-64-1.7-1.8c-7.7-9.4-7.1-23.3 1.7-32.1 6.1-6.1 14.5-8.1 22.3-6.3l97.3-97.3 3-3.2c2.9-3.3 5.5-6.9 7.8-10.7l83.8-139.8c5-8.4 11.1-16.2 18-23.1l176.1-176.1 6.1-5.5zM496 544a80 80 0 1 1 0-160 80 80 0 1 1 0 160zm0-112a32 32 0 1 0 0 64 32 32 0 1 0 0-64zM89.9 472L104 486.1 182.1 408 168 393.9 89.9 472zM518.6 24.6c-12.5-12.5-32.8-12.5-45.2 0L297.3 200.6c-4.2 4.2-7.8 8.8-10.8 13.8L202.7 354.2c-.8 1.3-1.7 2.7-2.5 4l17.7 17.7c1.3-.9 2.6-1.7 4-2.5l139.8-83.8 3.7-2.4c3.6-2.5 7-5.3 10.2-8.4L551.4 102.6c11.7-11.7 12.4-30.2 2.2-42.8l-2.2-2.4-32.8-32.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBaseballBatBall = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;