'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'alarm-minus';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e803';
var svgPathData = 'M256 64c123.7 0 224 100.3 224 224 0 53.2-18.5 102.1-49.5 140.5l42.5 42.5 1.7 1.8c7.7 9.4 7.1 23.3-1.7 32.1s-22.7 9.3-32.1 1.7l-1.8-1.7-42.5-42.5C358.1 493.5 309.2 512 256 512s-102.1-18.5-140.5-49.5L73 505c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l42.5-42.5C50.5 390.1 32 341.2 32 288 32 164.3 132.3 64 256 64zm0 48a176 176 0 1 0 0 352 176 176 0 1 0 0-352zm72 152c13.3 0 24 10.7 24 24s-10.7 24-24 24l-144 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l144 0zM100.2 .1c17.5 .9 33.7 6.5 47.4 15.5 9.5 6.3 6.3 19.9-4.1 24.6-6.1 2.8-12 5.8-17.8 8.9-4.9 2.7-10.9 2.6-16.2 .9-4.5-1.4-9.2-2.2-14.2-2.2-26.1 0-47.2 21.2-47.2 47.2 0 2 .1 4 .4 5.9 .7 5.6-.3 11.4-3.8 15.8-4.2 5.2-8.2 10.5-12 16-6.5 9.4-20.5 10.1-25-.4-4.3-10-6.9-20.9-7.4-32.4L0 95.2C0 42.6 42.6 0 95.2 0l4.9 .1zM416.7 0C469.4 0 512 42.6 512 95.2l-.1 4.9c-.6 11.4-3.2 22.3-7.4 32.4-4.5 10.5-18.4 9.8-25 .4-3.8-5.5-7.8-10.8-12-16-3.5-4.4-4.5-10.2-3.8-15.8 .2-1.9 .4-3.9 .4-5.9 0-26.1-21.2-47.2-47.3-47.2-4.9 0-9.7 .8-14.2 2.2-5.4 1.7-11.3 1.8-16.3-.9-5.8-3.2-11.7-6.2-17.8-8.9-10.4-4.7-13.7-18.3-4.1-24.6 13.7-9.1 30-14.6 47.4-15.5l4.9-.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlarmMinus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;