'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'backward';
var width = 576;
var height = 512;
var aliases = [9194];
var unicode = 'f04a';
var svgPathData = 'M51.6 256L224 90.7 224 421.3 51.6 256zM247.7 35.2c-14.7-6.3-31.8-3.2-43.4 7.9l-192 184C4.5 234.7 0 245.1 0 256s4.5 21.3 12.3 28.9l192 184c11.6 11.1 28.6 14.2 43.4 7.9S272 456 272 440l0-136.3 172.3 165.1c11.6 11.1 28.6 14.2 43.4 7.9S512 456 512 440l0-368c0-16-9.6-30.5-24.3-36.8s-31.8-3.2-43.4 7.9L272 208.3 272 72c0-16-9.6-30.5-24.3-36.8zM464 421.3L291.6 256 464 90.7 464 421.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBackward = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;