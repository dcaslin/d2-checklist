'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-u-turn-down-left';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e7e7';
var svgPathData = 'M7.1 367c-9.4 9.4-9.4 24.6 0 33.9l120 120c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L82 408 324 408c103.8 0 188-84.2 188-188S427.8 32 324 32l-236 0-2.5 .1C73.5 33.4 64 43.6 64 56s9.4 22.6 21.5 23.9L88 80 324 80c77.3 0 140 62.7 140 140S401.3 360 324 360l-242.1 0 79-79 1.7-1.8c7.7-9.4 7.1-23.3-1.7-32.1s-22.7-9.3-32.1-1.7l-1.8 1.7-120 120z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowUTurnDownLeft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;