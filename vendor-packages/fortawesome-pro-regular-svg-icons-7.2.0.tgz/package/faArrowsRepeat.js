'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrows-repeat';
var width = 512;
var height = 512;
var aliases = ["repeat-alt"];
var unicode = 'f364';
var svgPathData = 'M473 113c9.4-9.4 9.4-24.6 0-33.9L385-9c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l47 47-206.1 0C86 72 0 158 0 264 0 277.3 10.7 288 24 288s24-10.7 24-24c0-79.5 64.5-144 144-144l206.1 0-47 47c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l88-88zM39 399c-4.5 4.5-7 10.6-7 17s2.5 12.5 7 17l88 88c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-47-47 206.1 0c106 0 192-86 192-192 0-13.3-10.7-24-24-24s-24 10.7-24 24c0 79.5-64.5 144-144 144l-206.1 0 47-47c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0L39 399z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowsRepeat = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;