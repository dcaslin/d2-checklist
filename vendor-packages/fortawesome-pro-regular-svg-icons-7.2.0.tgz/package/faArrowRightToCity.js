'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-right-to-city';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4b3';
var svgPathData = 'M320 64c0-8.8 7.2-16 16-16l128 0c8.8 0 16 7.2 16 16l0 56c0 13.3 10.7 24 24 24l72 0c8.8 0 16 7.2 16 16l0 288c0 8.8-7.2 16-16 16l-240 0c-8.8 0-16-7.2-16-16l0-384zM336 0c-35.3 0-64 28.7-64 64l0 384c0 35.3 28.7 64 64 64l240 0c35.3 0 64-28.7 64-64l0-288c0-23.7-12.9-44.4-32-55.4L608 24c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 72-32 0 0-32c0-35.3-28.7-64-64-64L336 0zm32 112l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm16 80c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM368 304l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zM496 192c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM480 304l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zM153 175c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l23 23-86.1 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l86.1 0-23 23c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l64-64c9.4-9.4 9.4-24.6 0-33.9l-64-64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRightToCity = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;