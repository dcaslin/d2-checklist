'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'arrow-rotate-left-30';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e887';
var svgPathData = 'M75.1 75c100-100 262.1-100 362 0s100 262.1 0 362.1-262.1 100-362.1 0c-14.9-14.9-27.6-31.2-38.1-48.5-6.9-11.3-3.2-26.1 8.1-33s26.1-3.2 32.9 8.1c8.5 14 18.8 27.3 31 39.5 81.2 81.2 212.9 81.2 294.2 0s81.2-213 0-294.2-212.9-81.2-294.2 0L41 177c-6.9 6.9-17.2 8.9-26.2 5.2S0 169.7 0 160L0 24C0 10.7 10.7 0 24 0S48 10.7 48 24L48 102.1 75.1 75zm105 85c33.1 0 60 26.9 60 60 0 13.5-4.5 26-12.1 36 7.6 10 12.1 22.5 12.1 36 0 33.1-26.9 60-60 60l-28 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l28 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-20 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l20 0c6.6 0 12-5.4 12-12s-5.4-12-12-12l-28 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l28 0zm164 0c30.9 0 56 25.1 56 56l0 80c0 30.9-25.1 56-56 56l-16 0c-30.9 0-56-25.1-56-56l0-80c0-30.9 25.1-56 56-56l16 0zm-16 48c-4.4 0-8 3.6-8 8l0 80c0 4.4 3.6 8 8 8l16 0c4.4 0 8-3.6 8-8l0-80c0-4.4-3.6-8-8-8l-16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowRotateLeft30 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;