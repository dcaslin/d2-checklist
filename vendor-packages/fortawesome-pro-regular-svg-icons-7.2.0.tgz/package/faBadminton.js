'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'badminton';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e33a';
var svgPathData = 'M480.1 380c28.2 0 52.4 20.1 57.6 47.8l18.1 96.5 .3 4c-.2 9.3-6.8 17.5-16.3 19.3-9.5 1.8-18.7-3.5-22.2-12.1l-1.2-3.9-6.7-35.7-9.7 0 0 32c0 11-9 20-20 20-11 0-20-9-20-20l0-32-9.7 0-6.7 35.7c-2 10.8-12.5 18-23.3 16-10.9-2-18-12.5-16-23.3l18.1-96.5 1.2-5.1c7-25 30-42.7 56.4-42.7zM404.7-7.8C443-6.2 479.8 8 507.9 36.1l5.4 5.7C539.6 71.1 552 108.6 552.1 147l-.2 9.7c-2.6 48.9-24.8 99.1-64.3 138.6-68 68-171.2 86.2-240.9 36l-70.1 70.1c8.9 16.7 7.2 37.6-5.1 52.8l-3.3 3.7-54.1 54.1c-17.6 17.6-45.4 18.6-64.2 3.3l-3.7-3.3-14.1-14.1c-18.7-18.7-18.7-49.1 0-67.9l54.1-54.1 3.7-3.3c15.1-12.3 36-14.1 52.8-5.2l70.1-70.1c-17.8-24.9-27.1-54.4-28.4-84.8l-.2-7.7c0-51.9 22.4-106.2 64.6-148.4S345.1-8 397-8l7.7 .2zM66 464L80.1 478.1 134.1 424 120.1 409.9 66 464zM397 40c-38.3 0-80.6 16.7-114.4 50.5S232 166.7 232.1 205l.1 5.6c1.2 27.8 11.3 52.8 29.9 71.4 44.4 44.4 129.9 41.1 191.4-20.5 31.7-31.7 48.4-70.9 50.3-107.2l.2-7.2c0-28.1-9-53.7-26.4-73.2L474 70.1c-18.6-18.6-43.6-28.7-71.4-29.9L397 40z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBadminton = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;