'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'books-medical';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f7e8';
var svgPathData = 'M128 48l48 0c8.8 0 16 7.2 16 16l0 32-80 0 0-32c0-8.8 7.2-16 16-16zm-16 96l80 0 0 224-80 0 0-224zM240 66l0-2c0-35.3-28.7-64-64-64L128 0C92.7 0 64 28.7 64 64l0 384c0 35.3 28.7 64 64 64l48 0c15.1 0 29-5.3 40-14 11 8.8 24.9 14 40 14l48 0c11.1 0 21.6-2.8 30.7-7.8-8.7-13.4-15.8-28-20.9-43.5-2.7 2.1-6.1 3.3-9.8 3.3l-48 0c-8.8 0-16-7.2-16-16l0-320c0-8.8 7.2-16 16-16l48 0c8.8 0 16 7.2 16 16l0 195.1c17-39 46.7-71.2 83.8-91.6l-19.5-72.9 77.3-20.7 18.9 70.6c5.1-.4 10.3-.6 15.6-.6 11.9 0 23.5 1.1 34.8 3.1L487.2 48.3C478 14.2 442.9-6.1 408.8 3.1L362.4 15.5c-24.4 6.5-41.8 26.4-46.3 49.7-3.9-.8-8-1.1-12.1-1.1l-48 0c-5.5 0-10.9 .7-16 2zM192 448c0 8.8-7.2 16-16 16l-48 0c-8.8 0-16-7.2-16-16l0-32 80 0 0 32zM421.2 49.4c8.5-2.3 17.3 2.8 19.6 11.3l8.3 30.9-77.3 20.7-8.3-30.9c-2.3-8.5 2.8-17.3 11.3-19.6l46.4-12.4zM496 544a144 144 0 1 0 0-288 144 144 0 1 0 0 288zM485.3 320l21.3 0c8.8 0 16 7.2 16 16l0 37.3 37.3 0c8.8 0 16 7.2 16 16l0 21.3c0 8.8-7.2 16-16 16l-37.3 0 0 37.3c0 8.8-7.2 16-16 16l-21.3 0c-8.8 0-16-7.2-16-16l0-37.3-37.3 0c-8.8 0-16-7.2-16-16l0-21.3c0-8.8 7.2-16 16-16l37.3 0 0-37.3c0-8.8 7.2-16 16-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBooksMedical = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;