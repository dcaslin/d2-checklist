'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'ban-parking';
var width = 512;
var height = 512;
var aliases = ["parking-circle-slash"];
var unicode = 'f616';
var svgPathData = 'M419.1 385.1L336 302c24.2-17.4 40-45.9 40-78 0-53-43-96-96-96l-80 0c-10.4 0-19.6 4.9-25.5 12.6L126.9 92.9c35.5-28.1 80.3-44.9 129.1-44.9 114.9 0 208 93.1 208 208 0 48.8-16.8 93.7-44.9 129.1zm-33.9 33.9c-35.5 28.1-80.3 44.9-129.1 44.9-114.9 0-208-93.1-208-208 0-48.8 16.8-93.7 44.9-129.1L168 201.9 168 360c0 13.3 10.7 24 24 24s24-10.7 24-24l0-40 64 0c2 0 3.9-.1 5.9-.2l99.2 99.2zM301.1 267.1l-85.1-85.1 0-6.1 64 0c26.5 0 48 21.5 48 48 0 18.9-11 35.3-26.9 43.1zM216 249.9l22.1 22.1-22.1 0 0-22.1zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanParking = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;