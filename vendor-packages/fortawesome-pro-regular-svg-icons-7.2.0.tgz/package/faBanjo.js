'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'banjo';
var width = 512;
var height = 512;
var aliases = [129685];
var unicode = 'f8a3';
var svgPathData = 'M465 7c-9.4-9.4-24.6-9.4-33.9 0L383 55c-2.4 2.4-4.3 5.3-5.5 8.5l-22.2 59.1-62.7 62.7c-22-16.5-48.1-27.7-76.6-31.7 0-13.7-9.6-25.7-24-25.7s-24 12-24 25.7c-28.5 4.1-54.6 15.3-76.6 31.7-9.7-9.7-25-11.4-35.2-1.2s-8.5 25.5 1.2 35.2C41 241.4 29.8 267.5 25.7 296 12 296 0 305.6 0 320s12 24 25.7 24c4.1 28.5 15.3 54.6 31.7 76.6-9.7 9.7-11.4 25-1.2 35.2s25.5 8.5 35.2-1.2c22 16.5 48.2 27.7 76.6 31.7 0 13.7 9.6 25.7 24 25.7s24-12 24-25.7c28.5-4.1 54.6-15.3 76.6-31.7 9.7 9.7 25 11.4 35.2 1.2s8.5-25.5-1.2-35.2c16.5-22 27.7-48.2 31.7-76.6 13.7 0 25.7-9.6 25.7-24s-12-24-25.7-24c-4.1-28.5-15.3-54.6-31.7-76.6l62.7-62.7 59.1-22.2c3.2-1.2 6.1-3.1 8.5-5.5l48-48c9.4-9.4 9.4-24.6 0-33.9L465 7zM119 311c-9.4 9.4-9.4 24.6 0 33.9l48 48c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-48-48c-9.4-9.4-24.6-9.4-33.9 0zm73-119a128 128 0 1 1 0 256 128 128 0 1 1 0-256z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBanjo = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;